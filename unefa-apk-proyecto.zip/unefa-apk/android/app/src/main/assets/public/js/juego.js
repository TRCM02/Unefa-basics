/*
 * ============================================================
 *  BASICS EN LA UNEFA  ·  juego 3D de terror escolar (three.js r128)
 * ============================================================
 *  Orden del archivo:
 *   1. Utilidades, renderizador, escena y cámara
 *   2. Texturas procedurales y construcción del edificio (nivel 1)
 *   3. Luces, enemigos (Ysea, Laurimar, Peña, Rosales) y audio
 *   4. Lógica del juego: cuadernos, escritura, cortes de pelo, muerte/victoria
 *   5. Niveles 2-4 (Terreno, Speed Run, Aula), ítems, NPC y ajustes
 *   6. Profe Odalys, barbería y bucle principal
 *  Los efectos de pelo (corte) y la hoja de cuaderno están marcados con
 *  "Corte de pelo" y "Cuaderno" en los comentarios.
 * ============================================================
 */
const $c={},$=id=>$c[id]||($c[id]=document.getElementById(id));
let lpw=-1,
  lpl=-1,
  ldq=-1,
  lia='',
  lpe='',
  lhr='',
  nzO=0,
  fcnt=0,
  lhw=null;
var COL=[],
  POST=false,
  composer=null,
  GP=null,
  RL=[],
  pr0=1,
  EX=.66;
const R=new THREE.WebGLRenderer({canvas:$('c'),antialias:true,powerPreference:'high-performance'});
R.outputEncoding=THREE.sRGBEncoding;
R.toneMapping=THREE.ACESFilmicToneMapping;
R.toneMappingExposure=.08;
R.shadowMap.enabled=true;
R.shadowMap.type=THREE.PCFSoftShadowMap;
R.setPixelRatio(matchMedia('(pointer:coarse)').matches?1:Math.min(devicePixelRatio,2));
const rp0=R.getPixelRatio();
$('c').addEventListener('webglcontextlost',e=>e.preventDefault());
$('c').addEventListener('webglcontextrestored',()=>location.reload());
const S=new THREE.Scene();
S.background=new THREE.Color(0x020403);
S.fog=new THREE.FogExp2(0x14233f,.02);
const cam=new THREE.PerspectiveCamera(72,1,.1,70);
function rs(){
  R.setSize(innerWidth,innerHeight,false);
  cam.aspect=innerWidth/innerHeight;
  cam.fov=cam.aspect<1?100:72;
  cam.updateProjectionMatrix();
  if(composer)composer.setSize(innerWidth,innerHeight);
  if(GP)GP.uniforms.px.value.set(1/innerWidth,1/innerHeight)
}
addEventListener('resize',rs);
rs();
try{
  if(matchMedia('(pointer:coarse)').matches)throw 0;
  const co=matchMedia('(pointer:coarse)').matches,pr=co?Math.min(Math.max(devicePixelRatio,1),1.6):Math.min(Math.max(devicePixelRatio,1.5),2);
  const rt=new THREE.WebGLMultisampleRenderTarget(innerWidth*pr,innerHeight*pr,{type:THREE.HalfFloatType,format:THREE.RGBAFormat,minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter});
  rt.samples=co?2:4;
  composer=new THREE.EffectComposer(R,rt);
  pr0=pr;
  composer.setPixelRatio(pr);
  composer.setSize(innerWidth,innerHeight);
  composer.addPass(new THREE.RenderPass(S,cam));
  composer.addPass(new THREE.UnrealBloomPass(new THREE.Vector2(innerWidth/2,innerHeight/2),co?.15:.2,.5,.9));
  GP=new THREE.ShaderPass({uniforms:{tDiffuse:{value:null},t:{value:0},cm:{value:0},gl:{value:0},ex:{value:1},px:{value:new THREE.Vector2(1/innerWidth,1/innerHeight)}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:`uniform sampler2D tDiffuse;uniform float t,cm,gl,ex;uniform vec2 px;varying vec2 vUv;vec3 aces(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}float hs(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}
void main(){vec2 uv=vUv,d=uv-.5;float r=dot(d,d);
float ab=gl*.012;
vec3 c=ab>0.?vec3(texture2D(tDiffuse,uv+d*ab).r,texture2D(tDiffuse,uv).g,texture2D(tDiffuse,uv-d*ab).b):texture2D(tDiffuse,uv).rgb;
if(gl>0.)c=texture2D(tDiffuse,uv+vec2((hs(vec2(floor(uv.y*40.),t))-.5)*gl*.25,0.)).rgb;
vec3 b=(texture2D(tDiffuse,uv+vec2(px.x,0.)).rgb+texture2D(tDiffuse,uv-vec2(px.x,0.)).rgb+texture2D(tDiffuse,uv+vec2(0.,px.y)).rgb+texture2D(tDiffuse,uv-vec2(0.,px.y)).rgb)*.25;c=max(c+(c-b)*(.34+cm*.3),0.);
c=aces(c*ex*(.82-cm*.08));c=pow(c,vec3(.4545*(1.-.1*cm)));
float l=dot(c,vec3(.299,.587,.114));c=mix(c,vec3(l*.95,l*1.02,l*.97),.1+cm*.3);c*=vec3(1.04,1.0,.97);
c=max((c-.5)*(1.+.06*cm)+.5,0.);c+=(1.-c)*.07*(1.-cm);c*=1.-r*(.4-.2*cm);c*=1.-cm*.015*step(.5,fract(gl_FragCoord.y*.5));
c+=(hs(uv*vec2(1920.,1080.)+t)-.5)*(.0012+cm*.004);gl_FragColor=vec4(c,1.);}`});
  composer.addPass(GP);
  POST=true
}catch(e){
  POST=false;
  composer=null
}

/* ---------- texturas procedurales ---------- */
const TS=matchMedia('(pointer:coarse)').matches?1.5:((navigator.deviceMemory||8)>=8?3:2);
function tex(w,h,fn,rx=1,ry=1,sc){
  sc=Math.min(sc||TS,(R.capabilities.maxTextureSize||4096)/Math.max(w,h));
  const c=document.createElement('canvas');
  c.width=Math.round(w*sc);
  c.height=Math.round(h*sc);
  const cg=c.getContext('2d');
  cg.scale(c.width/w,c.height/h);
  cg.imageSmoothingQuality='high';
  fn(cg,w,h);
  const t=new THREE.CanvasTexture(c);
  t.wrapS=t.wrapT=THREE.RepeatWrapping;
  t.repeat.set(rx,ry);
  t.encoding=THREE.sRGBEncoding;
  t.anisotropy=Math.min(matchMedia('(pointer:coarse)').matches?4:16,R.capabilities.getMaxAnisotropy());
  return t
}
function grime(g,w,h,n,a){
  for(let i=0;i<n;i++){
    g.fillStyle=`rgba(0,0,0,${Math.random()*a*.6})`;
    g.fillRect(Math.random()*w,Math.random()*h,Math.random()*28+2,Math.random()*28+2)
  }
}
const floorT=tex(512,512,(g,w,h)=>{
  for(let y=0;y<4;y++)for(let x=0;x<4;x++){
    const v=(118+((x+y)%2)*26+Math.random()*10)|0;
    g.fillStyle=`rgb(${v-25},${v-12},${v-30})`;
    g.fillRect(x*128,y*128,128,128);
    g.strokeStyle='#1c1c18';
    g.lineWidth=4;
    g.strokeRect(x*128,y*128,128,128)
  }
  grime(g,w,h,60,.06)
},12,12);
const wallT=tex(512,512,(g,w,h)=>{
  g.fillStyle='#8f8c7a';
  g.fillRect(0,0,w,h);
  g.fillStyle='#2b4170';
  g.fillRect(0,h*.52,w,h*.48);
  g.fillStyle='#5a8aa6';
  g.fillRect(0,h*.5,w,10);
  g.fillStyle='#0a0f18';
  g.fillRect(0,h-18,w,18);
  const gr=g.createLinearGradient(0,0,0,h);
  gr.addColorStop(0,'rgba(0,0,0,.3)');
  gr.addColorStop(.3,'rgba(0,0,0,0)');
  gr.addColorStop(1,'rgba(0,0,0,.28)');
  g.fillStyle=gr;
  g.fillRect(0,0,w,h);
  for(let i=0;i<40;i++){
    g.fillStyle=`rgba(40,30,10,${Math.random()*.07})`;
    g.fillRect(Math.random()*w,Math.random()*h,2,Math.random()*60)
  }
  grime(g,w,h,20,.05)
});
(function(){
  const g=wallT.image.getContext('2d'),w=512,h=512;
  for(let i=0;i<5000;i++){
    g.fillStyle=Math.random()<.5?'rgba(255,255,255,.035)':'rgba(0,0,0,.045)';
    g.fillRect(Math.random()*w,Math.random()*h,1+Math.random()*2,1+Math.random()*2)
  }
  for(let i=0;i<26;i++){
    const x=Math.random()*w,l=40+Math.random()*120,gr=g.createLinearGradient(0,0,0,l);
    gr.addColorStop(0,'rgba(80,60,30,.10)');
    gr.addColorStop(1,'rgba(80,60,30,0)');
    g.fillStyle=gr;
    g.fillRect(x,0,2+Math.random()*3,l)
  }
  for(let i=0;i<14;i++){
    g.fillStyle='rgba(255,255,255,.06)';
    g.fillRect(Math.random()*w,h*.56+Math.random()*h*.38,20+Math.random()*50,1.5)
  }
  const lg=g.createLinearGradient(0,h*.52,0,h);
  lg.addColorStop(0,'rgba(255,255,255,.07)');
  lg.addColorStop(1,'rgba(0,0,0,.18)');
  g.fillStyle=lg;
  g.fillRect(0,h*.52,w,h*.48-18);
  g.fillStyle='rgba(255,255,255,.28)';
  g.fillRect(0,h*.5,w,2);
  g.fillStyle='rgba(0,0,0,.4)';
  g.fillRect(0,h*.5+10,w,3);
  g.fillStyle='rgba(255,255,255,.18)';
  g.fillRect(0,h-19,w,2);
  g.fillStyle='rgba(0,0,0,.14)';
  g.fillRect(0,0,2,h);
  wallT.needsUpdate=true
})();
const ceilT=tex(256,256,(g,w,h)=>{
  g.fillStyle='#b9b9ae';
  g.fillRect(0,0,w,h);
  g.strokeStyle='#777';
  g.lineWidth=3;
  g.strokeRect(0,0,w,h);
  grime(g,w,h,15,.05)
},30,30);
const floorR=tex(256,256,(g,w,h)=>{
  g.fillStyle='#555';
  g.fillRect(0,0,w,h);
  for(let i=0;i<500;i++){
    g.fillStyle='rgba('+(Math.random()<.5?'20,20,20':'200,200,200')+','+Math.random()*.25+')';
    g.fillRect(Math.random()*w,Math.random()*h,Math.random()*40,Math.random()*3)
  }
},12,12);
const floorM=new THREE.MeshStandardMaterial({map:floorT,bumpMap:floorT,bumpScale:.06,roughness:.75,roughnessMap:floorR,metalness:.15,envMapIntensity:1.2});
const wallM=new THREE.MeshStandardMaterial({map:wallT,bumpMap:wallT,bumpScale:.08,roughness:.75});
const ceilM=new THREE.MeshStandardMaterial({map:ceilT,roughness:.95});
const metalM=new THREE.MeshStandardMaterial({color:0x4a5048,roughness:.4,metalness:.8});
const darkM=new THREE.MeshStandardMaterial({color:0x1b1d1a,roughness:.7,metalness:.2});
function B(x,y,z,w,h,d,m,cs=true){
  if(y-h/2<.9&&h>=.6)COL.push([x-w/2,x+w/2,z-d/2,z+d/2]);
  const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);
  o.position.set(x,y,z);
  o.castShadow=cs;
  o.receiveShadow=true;
  o.userData.bx=1;
  S.add(o);
  return o
}
const SGC={};
function sign(txt,w,h,col,bg,x,y,z,ry=0,em=.3){
  bg=bg.replace(/#1d4a28|#14301c|#12301c/,'#0c35a8');
  const sk=txt+'|'+w+'|'+h+'|'+col+'|'+bg;
  const t=SGC[sk]||(SGC[sk]=tex(640,Math.max(80,Math.round(640*h/w)),(g,W,H)=>{
    g.fillStyle=bg;
    g.fillRect(0,0,W,H);
    g.strokeStyle=col;
    g.lineWidth=6;
    g.strokeRect(8,8,W-16,H-16);
    g.fillStyle=col;
    let fs=H*.46;
    g.font='bold '+fs+'px Georgia';
    while(g.measureText(txt).width>W-48&&fs>10){
      fs-=2;
      g.font='bold '+fs+'px Georgia'
    }
    g.textAlign='center';
    g.textBaseline='middle';
    g.fillText(txt,W/2,H/2+fs*.04)
  }));
  const m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:t,roughness:.6,emissive:0xffffff,emissiveMap:t,emissiveIntensity:em*.85}));
  m.position.set(x,y,z);
  m.rotation.y=ry;
  S.add(m);
  return m
}
let FLT;

function flag(w,x,y,z,ry){
  const t=FLT||(FLT=tex(512,340,(g,W,H)=>{
    g.fillStyle='#ffcc00';
    g.fillRect(0,0,W,H/3);

    g.fillStyle='#00247d';
    g.fillRect(0,H/3,W,H/3);

    g.fillStyle='#cf142b';
    g.fillRect(0,2*H/3,W,H/3);

    g.fillStyle='#fff';
    g.font='34px serif';
    g.textAlign='center';
    g.textBaseline='middle';

    // Configuración de las estrellas
    const centroX = W / 2;
    const centroY = H / 2 + 80;

    const radioX = 120;
    const radioY = 120;

    const anguloInicial = 1.1 * Math.PI;
    const amplitud = 0.8 * Math.PI;

    for(let i=0; i<8; i++){
      const a = anguloInicial + amplitud * i / 7;

      g.fillText(
        '★',
        centroX + Math.cos(a) * radioX,
        centroY + Math.sin(a) * radioY
      );
    }

    // Se mantiene dentro del dibujo de la bandera
    grime(g,W,H,60,.1);
  }));

  const m=new THREE.Mesh(
    new THREE.PlaneGeometry(w,w*.66),
    new THREE.MeshStandardMaterial({map:t,roughness:.8})
  );

  m.position.set(x,y,z);
  m.rotation.y=ry;
  S.add(m);
}


/* ---------- edificio ---------- */
const FL=new THREE.Mesh(new THREE.PlaneGeometry(60,60),floorM);
FL.rotation.x=-Math.PI/2;
FL.receiveShadow=true;
S.add(FL);
const CE=new THREE.Mesh(new THREE.PlaneGeometry(60,60),ceilM);
CE.rotation.x=Math.PI/2;
CE.position.y=3;
S.add(CE);
// oficina
B(0,1.5,3,8,3,.2,wallM);
B(-4,1.5,0,.2,3,6,wallM);
B(4,1.5,0,.2,3,6,wallM);
B(-3.375,1.5,-3,1.25,3,.2,wallM);
B(0,1.5,-3,2.5,3,.2,wallM);
B(3.375,1.5,-3,1.25,3,.2,wallM);
B(-2,2.75,-3,1.5,.5,.2,wallM);
B(2,2.75,-3,1.5,.5,.2,wallM);
// pasillos
[-2.75,2.75].forEach(x=>{
  B(x,1.5,-7.75,.2,3,.5,wallM);
  B(x,1.5,-4.25,.2,3,2.5,wallM)
});
// aula magna
B(-4.875,1.5,-8,4.25,3,.2,wallM);
B(4.875,1.5,-8,4.25,3,.2,wallM);
B(-4.3,1.5,-18,5.6,3,.2,wallM);
B(4.3,1.5,-18,5.6,3,.2,wallM);
B(0,2.75,-18,3,.5,.2,wallM);
B(-3.25,1.5,-26,3.5,3,.2,wallM);
B(3.25,1.5,-26,3.5,3,.2,wallM);
B(0,1.5,-30,40,3,.2,wallM);
[-1,1].forEach(s=>{
  B(s*20,1.5,-28,.2,3,4,wallM);
  B(s*20,1.5,-19,.2,3,10,wallM);
  B(s*20,1.5,-10,.2,3,4,wallM);
  B(s*20,1.5,-6,.2,3,4,wallM);
  B(s*5.875,1.5,-4,6.25,3,.2,wallM);
  B(s*15.5,1.5,-4,9,3,.2,wallM);
  B(s*10,1.5,-26,10,3,.2,wallM);
  B(s*15,1.5,-22,.2,3,8,wallM);
  B(s*30,1.5,-13,.2,3,10,wallM);
  B(s*30,1.5,-25,.2,3,10,wallM);
  B(s*30,1.5,-19,.2,3,2,wallM);
  B(s*25,1.5,-8,10,3,.2,wallM);
  B(s*25,1.5,-18,10,3,.2,wallM);
  B(s*25,1.5,-20,10,3,.2,wallM);
  B(s*25,1.5,-30,10,3,.2,wallM);
  B(s*5,1.5,0,.2,3,8,wallM);
  B(s*20,1.5,0,.2,3,8,wallM);
  B(s*12.5,1.5,4,15,3,.2,wallM)
});
sign('PASILLO OESTE',3,.55,'#fff','#0c35a8',-19.85,2.3,-19,Math.PI/2,.3);
sign('PASILLO ESTE',3,.55,'#fff','#0c35a8',19.85,2.3,-19,-Math.PI/2,.3);
sign('PASILLO TRASERO',3.4,.55,'#fff','#0c35a8',0,2.3,-29.85,0,.3);
sign('PASILLO NORTE',3,.55,'#fff','#0c35a8',-6,2.3,-4.1,Math.PI,.3);
sign('PASILLO NORTE',3,.55,'#fff','#0c35a8',6,2.3,-4.1,Math.PI,.3);
[[-17.5,-20],[17.5,-20],[0,-28],[-9,-6],[9,-6]].forEach(p=>{
  const l=new THREE.PointLight(0xdde8ff,.9,12,1.4);
  l.position.set(p[0],2.6,p[1]);
  S.add(l)
});
[-5,5].forEach(x=>B(x,1.5,-22,.2,3,8,wallM));
[-7,7].forEach(x=>{
  B(x,1.5,-9.5,.2,3,3,wallM);
  B(x,1.5,-16,.2,3,4,wallM)
});
// laboratorio y cancha
[-1,1].forEach(s=>{
  B(s*11,1.5,-8,8,3,.2,wallM);
  B(s*11,1.5,-18,8,3,.2,wallM);
  B(s*15,1.5,-16,.2,3,4,wallM);
  B(s*15,1.5,-10,.2,3,4,wallM)
});
// puertas
const slabT=tex(256,256,(g,w,h)=>{
  g.fillStyle='#133a9e';
  g.fillRect(0,0,w,h);
  for(let i=0;i<w;i+=32){
    g.fillStyle='rgba(255,255,255,.06)';
    g.fillRect(i,0,3,h)
  }
  for(let i=0;i<h;i+=32){
    g.fillStyle=i%64?'#f2c230':'#111';
    g.fillRect(0,h-26,w,26);
    g.fillRect(i,h-26,32,26)
  }
  g.fillStyle='#f2c230';
  g.font='bold 34px Georgia';
  g.textAlign='center';
  g.fillText('UNEFA',w/2,h/2);
  grime(g,w,h,100,.15)
});
const slabM=new THREE.MeshStandardMaterial({map:slabT,roughness:.45,metalness:.7});
const D={L:{c:false,m:B(-2,4.4,-3,1.5,2.8,.12,slabM)},R:{c:false,m:B(2,4.4,-3,1.5,2.8,.12,slabM)}};
// mobiliario oficina
const woodM=new THREE.MeshStandardMaterial({color:0x5a3b22,roughness:.55,metalness:.05});
B(0,.8,-1.7,3,.1,1,woodM);
[-1.4,1.4].forEach(x=>B(x,.4,-1.7,.1,.8,.9,woodM));
B(0,.45,-2.1,2.8,.7,.05,woodM);
B(0,1.2,-1.85,1.1,.7,.14,darkM);
const scrT=tex(1024,606,(g,w,h)=>drawEnroll(g,w,h));
const scr=new THREE.Mesh(new THREE.PlaneGeometry(.98,.58),new THREE.MeshBasicMaterial({map:scrT,color:new THREE.Color(.95,.95,.95)}));
scr.position.set(0,1.2,-1.77);
scr.rotation.y=0;
S.add(scr);
B(0,.92,-1.85,.3,.15,.2,darkM);
const fan=new THREE.Group();
fan.position.set(1.15,1.12,-1.6);
S.add(fan);
const fb=new THREE.Mesh(new THREE.CylinderGeometry(.05,.12,.3,12),metalM);
fb.position.y=-.25;
fan.add(fb);
const blades=new THREE.Group();
for(let i=0;i<3;i++){
  const b=new THREE.Mesh(new THREE.BoxGeometry(.32,.02,.09),metalM);
  b.rotation.y=i*Math.PI*2/3;
  b.position.set(Math.cos(i*Math.PI*2/3)*.17,0,-Math.sin(i*Math.PI*2/3)*.17);
  blades.add(b)
}
blades.rotation.x=Math.PI/2;
fan.add(blades);
const mug=new THREE.Mesh(new THREE.CylinderGeometry(.06,.05,.1,16),new THREE.MeshStandardMaterial({color:0xf2c230,roughness:.3}));
mug.position.set(-1.1,.9,-1.6);
S.add(mug);
plq(2.3,1.08,1024,480,0,2.1,-2.885,0,drawExc,.1);
flag(1.4,0,1.9,2.88,Math.PI);
flag(1.1,-3.88,1.7,-.5,Math.PI/2);
plq(1.2,1.6,768,1024,3.88,1.6,-1.3,-Math.PI/2,drawBarber,.12);
// aula magna
const chM=new THREE.MeshStandardMaterial({color:0x1d3a6a,roughness:.5});
for(let r=0;r<3;r++)for(let i=-3;i<=3;i++){
  if(!i)continue;
  B(i*1.3,.28,-10-r*1.4,.6,.1,.55,chM,false);
  B(i*1.3,.55,-10.25-r*1.4,.6,.5,.08,chM,false);
  B(i*1.3,.14,-10-r*1.4,.08,.28,.08,metalM,false)
}
B(-5.5,.55,-16.8,2.4,1.1,.8,woodM);
B(-5.5,1.12,-16.8,2.6,.06,.9,darkM);
const lgo=new THREE.Mesh(new THREE.CircleGeometry(2.2,48),new THREE.MeshStandardMaterial({map:tex(512,512,(g,W,H)=>{
  g.fillStyle='#0c35a8';
  g.beginPath();
  g.arc(W/2,H/2,W/2,0,7);
  g.fill();
  g.strokeStyle='#46c2ff';
  g.lineWidth=14;
  g.beginPath();
  g.arc(W/2,H/2,W/2-24,0,7);
  g.stroke();
  g.fillStyle='#fff';
  g.font='bold 120px Georgia';
  g.textAlign='center';
  g.textBaseline='middle';
  g.fillText('UNEFA',W/2,H/2)
}),roughness:.3}));
lgo.rotation.x=-Math.PI/2;
lgo.position.set(0,.015,-13);
lgo.receiveShadow=true;
S.add(lgo);
B(0,.4,-22.4,3,.8,1.1,woodM);
B(0,.85,-22.4,3.1,.06,1.2,darkM);
B(0,1.2,-22.7,1.1,.65,.1,darkM);
const cs=new THREE.Mesh(new THREE.PlaneGeometry(.98,.55),new THREE.MeshBasicMaterial({color:new THREE.Color(.6,1.3,2.2)}));
cs.position.set(0,1.2,-22.64);
S.add(cs);
[-3.2,3.2].forEach(x=>B(x,1.2,-25.7,2.6,2.4,.4,woodM));
[-4.5,4.5].forEach(x=>B(x,.6,-20,.6,1.2,.8,metalM));
B(0,.45,-21.2,.6,.9,.6,chM,false);
sign('COORDINACIÓN ACADÉMICA',3.4,.55,'#fff','#0c35a8',0,2.5,-25.85,0,.5);
flag(1.2,4.8,1.6,-22,-Math.PI/2);
const cLt=new THREE.PointLight(0xfff2e0,2.2,16,1.4);
cLt.userData.b=2.2;
RL.push(cLt);
cLt.position.set(0,2.7,-22);
S.add(cLt);
sign('LOBBY · UNEFA',3,.55,'#46c2ff','#0c35a8',-4.6,2.4,-17.88,0,.6);
flag(1.6,-6,1.5,-17.88,0);
flag(1.6,6,1.5,-17.88,0);
// laboratorio
const scM=new THREE.MeshBasicMaterial({color:0x46c2ff});
for(let k=0;k<3;k++){
  B(-14.4,.45,-10.5-k*2.6,.9,.9,2,woodM);
  B(-14.6,1.1,-10.5-k*2.6,.1,.45,.7,darkM);
  const s=new THREE.Mesh(new THREE.PlaneGeometry(.62,.36),scM);
  s.position.set(-14.54,1.1,-10.5-k*2.6);
  s.rotation.y=Math.PI/2;
  S.add(s)
}
for(let r=0;r<3;r++)for(let c=0;c<3;c++){
  const x=-12.5+c*1.5,z=-10.5-r*1.7;
  B(x,.7,z,.7,.05,.5,woodM,false);
  B(x,.35,z+.05,.05,.7,.05,metalM,false);
  B(x,.4,z+.5,.45,.05,.4,chM,false);
  B(x,.65,z+.7,.45,.5,.05,chM,false)
}
B(-11,1.5,-17.85,4.6,1.3,.05,new THREE.MeshStandardMaterial({color:0xe8eef8,roughness:.3}));
sign('SALÓN 204 · INGENIERÍA',4.4,.6,'#fff','#0c35a8',-11,2.5,-17.88,0,.5);
// cancha
const courtT=tex(512,512,(g,w,h)=>{
  for(let y=0;y<8;y++)for(let x=0;x<8;x++){
    g.fillStyle=(x+y)%2?'#9aa3b4':'#667391';
    g.fillRect(x*64,y*64,64,64)
  }
  grime(g,w,h,200,.12)
});
const court=new THREE.Mesh(new THREE.PlaneGeometry(7.6,9.6),new THREE.MeshStandardMaterial({map:courtT,roughness:.5}));
court.rotation.x=-Math.PI/2;
court.position.set(11,.02,-13);
court.receiveShadow=true;
S.add(court);
B(14.3,.55,-13,.9,1.1,6,metalM);
B(14.3,1.12,-13,1,.06,6.1,new THREE.MeshStandardMaterial({color:0xcfd8e8,roughness:.3,metalness:.4}));
for(let r=0;r<2;r++)for(let c=0;c<2;c++){
  const x=8+c*3.4,z=-10.5-r*2.6;
  B(x,.75,z,2.2,.06,.8,woodM,false);
  B(x,.4,z-.65,2.2,.05,.3,chM,false);
  B(x,.4,z+.65,2.2,.05,.3,chM,false);
  [-1,1].forEach(s=>B(x+s,.37,z,.08,.75,.7,metalM,false))
}
sign('COMEDOR ESTUDIANTIL',4.4,.6,'#fff','#0c35a8',11,2.5,-17.88,0,.5);

/* ---------- detalles ---------- */
const lkM=new THREE.MeshStandardMaterial({color:0x2d3a4a,roughness:.4,metalness:.6}),
  redM=new THREE.MeshStandardMaterial({color:0xaa1111,roughness:.35,metalness:.4}),
  potM=new THREE.MeshStandardMaterial({color:0x6b3a24,roughness:.7}),
  leafM=new THREE.MeshStandardMaterial({color:0x1d5a2a,roughness:.8}),
  papM=new THREE.MeshStandardMaterial({color:0xeeeeea,roughness:.9}),
  rugM=new THREE.MeshStandardMaterial({color:0x4a1418,roughness:.95});
function cy(x,y,z,rt,rb,h,m,rz){
  const o=new THREE.Mesh(new THREE.CylinderGeometry(rt,rb,h,16),m);
  o.position.set(x,y,z);
  if(rz)o.rotation.z=rz;
  o.castShadow=true;
  S.add(o);
  return o
}
for(let i=0;i<2;i++)[-1,1].forEach(s=>{
  B(s*2.5,.95,-4.3-i*.5,.32,1.9,.46,lkM,false);
  B(s*2.34,1.3,-4.3-i*.5,.01,.12,.06,metalM,false)
});
sign('AVISO',.7,.9,'#fff','#a01010',-2.64,2.3,-5,Math.PI/2,.15);
sign('HORARIOS',.7,.9,'#fff','#0c35a8',2.64,2.3,-4.4,-Math.PI/2,.15);
cy(6.7,.8,-9,.1,.1,.55,redM);
cy(6.7,1.12,-9,.04,.04,.12,metalM);
cy(-6.7,.8,-15,.1,.1,.55,redM);
cy(-6.3,.3,-9,.2,.17,.6,darkM);
[-6.2,6.2].forEach(x=>{
  cy(x,.25,-17.2,.22,.17,.5,potM);
  const l=new THREE.Mesh(new THREE.SphereGeometry(.38,14,10),leafM);
  l.position.set(x,.85,-17.2);
  l.scale.y=1.2;
  l.castShadow=true;
  S.add(l)
});
[-9.5,-12,-15].forEach(z=>cy(0,2.88,z,.05,.05,13.6,metalM,Math.PI/2));
[-2.74,-1.26,1.26,2.74].forEach(x=>B(x,1.25,-2.92,.1,2.5,.24,metalM,false));
B(0,.012,-1.2,3.6,.02,2.6,rugM,false);
B(-.5,.856,-1.7,.4,.012,.3,papM,false);
B(.55,.86,-1.65,.35,.02,.25,darkM,false);
sign('SALIDA',1,.28,'#fff','#0a7a2a',0,2.62,-17.88,0,.9);
const clT=tex(256,256,(g,w,h)=>{
  g.fillStyle='#eee';
  g.beginPath();
  g.arc(128,128,120,0,7);
  g.fill();
  g.strokeStyle='#222';
  g.lineWidth=10;
  g.stroke();
  g.lineWidth=8;
  g.beginPath();
  g.moveTo(128,128);
  g.lineTo(128,60);
  g.moveTo(128,128);
  g.lineTo(175,150);
  g.stroke()
});
[[-3.88,2.2,1.2,Math.PI/2],[-6.88,2.55,-9.5,Math.PI/2]].forEach(a=>{
  const m=new THREE.Mesh(new THREE.PlaneGeometry(.5,.5),new THREE.MeshStandardMaterial({map:clT,transparent:true,roughness:.5}));
  m.position.set(a[0],a[1],a[2]);
  m.rotation.y=a[3];
  S.add(m)
});
const wiT=tex(256,320,(g,w,h)=>{
  const gr=g.createLinearGradient(0,0,0,h);
  gr.addColorStop(0,'#0b1a3c');
  gr.addColorStop(1,'#2a4a86');
  g.fillStyle=gr;
  g.fillRect(0,0,w,h);
  for(let i=0;i<40;i++){
    g.fillStyle='rgba(255,255,255,'+Math.random()*.8+')';
    g.fillRect(Math.random()*w,Math.random()*h*.6,2,2)
  }
  g.fillStyle='#e8f0ff';
  g.beginPath();
  g.arc(190,60,18,0,7);
  g.fill();
  g.strokeStyle='#15181c';
  g.lineWidth=14;
  g.strokeRect(7,7,w-14,h-14);
  g.lineWidth=8;
  g.beginPath();
  g.moveTo(w/2,0);
  g.lineTo(w/2,h);
  g.moveTo(0,h/2);
  g.lineTo(w,h/2);
  g.stroke()
});
[[-6.88,-9.5,Math.PI/2],[-6.88,-16.5,Math.PI/2],[6.88,-9.5,-Math.PI/2],[6.88,-16.5,-Math.PI/2]].forEach(a=>{
  const m=new THREE.Mesh(new THREE.PlaneGeometry(1.1,1.4),new THREE.MeshStandardMaterial({map:wiT,emissive:0xffffff,emissiveMap:wiT,emissiveIntensity:.35,roughness:.2}));
  m.position.set(a[0],1.5,a[1]);
  m.rotation.y=a[2];
  S.add(m)
});
[-5.5,5.5].forEach(x=>{
  const l=new THREE.PointLight(0x6a8cff,.7,9,1.4);
  l.userData.b=.7;
  l.position.set(x,1.8,-13);
  RL.push(l);
  S.add(l)
});
const beamT=tex(64,128,(g,w,h)=>{
  const gr=g.createLinearGradient(0,0,0,h);
  gr.addColorStop(0,'rgba(120,160,255,.6)');
  gr.addColorStop(1,'rgba(120,160,255,0)');
  g.fillStyle=gr;
  g.fillRect(0,0,w,h)
});
[[-1,-9.5],[-1,-16.5],[1,-9.5],[1,-16.5]].forEach(a=>{
  const gp=new THREE.Group(),m=new THREE.Mesh(new THREE.PlaneGeometry(1.1,3.3),new THREE.MeshBasicMaterial({map:beamT,transparent:true,opacity:.28,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide}));
  m.rotation.y=Math.PI/2;
  gp.add(m);
  gp.position.set(a[0]*5.7,1.1,a[1]);
  gp.rotation.z=a[0]*-.82;
  S.add(gp)
});
[[0,0],[-2,-5],[2,-5],[0,-13],[-11,-13],[11,-13]].forEach(p=>B(p[0],2.985,p[1],1.6,.04,.55,metalM,false));
[D.L,D.R].forEach(d=>{
  const hb=new THREE.Mesh(new THREE.BoxGeometry(1.1,.06,.08),metalM);
  hb.position.set(0,0,.1);
  d.m.add(hb)
});
cy(-1,.87,-1.95,.1,.12,.04,darkM);
const arm=cy(-1,1.05,-1.95,.012,.012,.36,metalM);
arm.rotation.z=.25;
cy(-.9,1.24,-1.95,.04,.1,.12,new THREE.MeshStandardMaterial({color:0x1d4a28,roughness:.4,metalness:.5}));
const dlL=new THREE.PointLight(0xffd9a0,.55,3.5,1.6);
dlL.position.set(-.9,1.15,-1.9);
S.add(dlL);
B(0,.865,-1.4,.5,.025,.17,darkM,false);
(function(){
  const whM=new THREE.MeshStandardMaterial({color:0xcfd6e2,roughness:.4}),lm=new THREE.MeshBasicMaterial({color:new THREE.Color(.8,.9,1.05)});
  [[-25,-13],[25,-13],[-25,-25],[25,-25],[12,0],[-12,0]].forEach(p=>B(p[0],2.95,p[1],1.6,.05,.5,lm,false));
  [[-25,-19],[25,-19]].forEach(p=>{
    const l=new THREE.PointLight(0xdde8ff,1.1,15,1.3);
    l.position.set(p[0],2.6,p[1]);
    S.add(l)
  });
  for(let z=-17;z<-8;z+=2)B(-29.4,1.1,z,.5,2.2,1.4,woodM);
  B(-23,.4,-10.5,2.4,.8,.9,woodM);
  B(-23,.4,-16.5,2.4,.8,.9,woodM);
  [-10.5,-16.5].forEach(z=>{
    B(25,.38,z,5,.76,.9,woodM);
    B(25,1.05,z-.3,.9,.5,.05,scM,false)
  });
  [-22.5,-28].forEach(z=>[23,27].forEach(x=>B(x,.4,z,2,.8,1,woodM)));
  B(29.5,.5,-25,.6,1,5,woodM);
  [-22.6,-28.4].forEach(z=>{
    for(let i=0;i<4;i++)B(-22.5-i*2,.28,z,.6,.1,.55,chM,false)
  });
  B(-29.7,1.4,-25,.1,1.2,5,whM);
  for(let x=-18;x<-6;x+=3)B(x,1,3.5,2,2,.5,lkM);
  B(-15,.4,0,3,.8,1,woodM);
  [8,13,17].forEach(x=>B(x,.35,3,1.2,.7,2,papM));
  B(19.5,1,0,.6,2,3,lkM);
  sign('BIBLIOTECA',3,.55,'#fff','#0c35a8',-19.85,2.4,-16,Math.PI/2,.4);
  sign('AUDITORIO',3,.55,'#fff','#0c35a8',-19.85,2.4,-22,Math.PI/2,.4);
  sign('COMPUTACIÓN',3,.55,'#fff','#0c35a8',19.85,2.4,-16,-Math.PI/2,.4);
  sign('CAFETÍN',3,.55,'#fff','#0c35a8',19.85,2.4,-22,-Math.PI/2,.4);
  sign('ARCHIVO',2.6,.55,'#fff','#0c35a8',-15.5,2.3,-4.1,Math.PI,.4);
  sign('ENFERMERÍA',2.8,.55,'#fff','#0c35a8',15.5,2.3,-4.1,Math.PI,.4)
})();
/* ---------- luces ---------- */
const amb=new THREE.AmbientLight(0xdde6ff,1.15);
S.add(amb);
const oL=new THREE.PointLight(0xfff0c8,1.5,13,2);
oL.position.set(0,2.7,0);
oL.castShadow=true;
oL.shadow.mapSize.set(matchMedia('(pointer:coarse)').matches?1024:2048,matchMedia('(pointer:coarse)').matches?1024:2048);
oL.shadow.bias=-.0004;
S.add(oL);
const dk=new THREE.PointLight(0x7db8ff,.7,4,2);
dk.position.set(0,1.3,-1.4);
S.add(dk);
const hL=new THREE.PointLight(0xffffff,0,10,1.4);
hL.position.set(-2,2.4,-4.5);
S.add(hL);
const hR=new THREE.PointLight(0xffffff,0,10,1.4);
hR.position.set(2,2.4,-4.5);
S.add(hR);
[[0,-13,0xfff4e0,2.2],[-11,-13,0xffffff,2],[11,-13,0xfff0d8,2]].forEach(a=>{
  const l=new THREE.PointLight(a[2],a[3],26,1.1);
  l.userData.b=a[3];
  l.position.set(a[0],2.7,a[1]);
  S.add(l);
  RL.push(l)
});
const hm=new THREE.HemisphereLight(0xd8e6ff,0x4a4f58,0);
S.add(hm);
const hl=new THREE.PointLight(0xdde8ff,0,14,1.2);
hl.position.set(0,2.6,-5.2);
S.add(hl);
const cl=new THREE.PointLight(0xffffff,0,24,1.1);
const dL=new THREE.PointLight(0xff2a18,0,9,1.4);
S.add(dL);
try{
  const pm=new THREE.PMREMGenerator(R),es=new THREE.Scene();
  es.add(new THREE.Mesh(new THREE.BoxGeometry(20,10,20),new THREE.MeshBasicMaterial({color:0x0c1228,side:THREE.BackSide})));
  [[0,4.8,0],[-8,2,0],[8,2,0],[0,2,-8]].forEach(p=>{
    const m=new THREE.Mesh(new THREE.BoxGeometry(p[1]>4?6:.3,p[1]>4?.3:3,6),new THREE.MeshBasicMaterial({color:new THREE.Color(.9,1,1.15)}));
    m.position.set(p[0],p[1],p[2]);
    es.add(m)
  });
  S.environment=pm.fromScene(es,.04).texture
}catch(e){}
S.add(cl);

/* ---------- animatrónicos ---------- */
function mkBot(col,hat,kind){
  const g=new THREE.Group();
  const bm=new THREE.MeshStandardMaterial({color:col,roughness:.45,metalness:.35});
  const hm=new THREE.MeshStandardMaterial({color:hat,roughness:.4,metalness:.3});
  const add=(geo,m,x,y,z,r)=>{
    const o=new THREE.Mesh(geo,m);
    o.position.set(x,y,z);
    if(r)o.rotation.set(...r);
    o.castShadow=true;
    g.add(o);
    return o
  };
  add(new THREE.BoxGeometry(.72,.95,.42),bm,0,1.2,0);
  [-.2,.2].forEach(x=>add(new THREE.CylinderGeometry(.09,.08,.8,10),metalM,x,.42,0));
  [-.48,.48].forEach(x=>add(new THREE.CylinderGeometry(.08,.07,.85,10),metalM,x,1.15,.05,[.5,0,0]));
  add(new THREE.SphereGeometry(.31,28,18),bm,0,1.92,0);
  add(new THREE.BoxGeometry(.2,.2,.04),new THREE.MeshStandardMaterial({color:0xf2c230,metalness:.9,roughness:.2}),.18,1.45,.22);
  if(kind==0){
    const b=add(new THREE.SphereGeometry(.34,20,10,0,7,0,Math.PI/2),hm,0,2.08,0);
    b.scale.y=.45;
  }
  if(kind==1){
    add(new THREE.SphereGeometry(.34,20,10,0,7,0,Math.PI/2),hm,0,2.06,0);
    add(new THREE.CylinderGeometry(.42,.42,.04,24),hm,0,2.06,0)
  }
  if(kind==2){
    add(new THREE.CylinderGeometry(.34,.36,.2,24),hm,0,2.2,0);
    add(new THREE.BoxGeometry(.5,.04,.3),metalM,0,2.1,.28)
  }
  const em=new THREE.MeshBasicMaterial({color:0xff2a10});
  [-.12,.12].forEach(x=>add(new THREE.SphereGeometry(.055,10,8),em,x,1.95,.27));
  add(new THREE.BoxGeometry(.26,.06,.04),new THREE.MeshBasicMaterial({color:0xeeeeee}),0,1.8,.29);
  g.scale.setScalar(1.15);
  g.visible=true;
  S.add(g);
  return g
}
function mkProf(k){
  const g=new THREE.Group();
  const M=(c,r=.55,m=.1)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
  const skin=M(0xd9b49a,.5),
    cloth=[M(0x1648c8),M(0x24337a),M(0x5a4a34)][k],
    pants=M(0x14161f),
    dark=M(0x0a0a10),
    white=M(0xeeeeee),
    W=[1.15,.8,.95][k];
  const add=(geo,m,x,y,z,r)=>{
    const o=new THREE.Mesh(geo,m);
    o.position.set(x,y,z);
    if(r)o.rotation.set(...r);
    o.castShadow=true;
    g.add(o);
    return o
  };
  [-1,1].forEach(s=>{
    add(new THREE.CylinderGeometry(.1*W,.09*W,.85,12),pants,s*.17*W,.42,0);
    add(new THREE.CylinderGeometry(.075*W,.065*W,.85,10),cloth,s*.42*W,1.2,.04,[.35,0,s*.1]);
    add(new THREE.SphereGeometry(.08,10,8),skin,s*.47*W,.76,.22)
  });
  add(new THREE.CylinderGeometry(.3*W,.36*W,.95,18),cloth,0,1.3,0);
  add(new THREE.CylinderGeometry(.09,.1,.14,10),skin,0,1.82,0);
  const hd=add(new THREE.SphereGeometry(.28,32,24),k==0?M(0xe3bba2,.22,.05):skin,0,2.05,0);
  hd.scale.set(1,1.12,1);
  const em=new THREE.MeshBasicMaterial({color:0xff2a10});
  [-1,1].forEach(s=>{
    add(new THREE.SphereGeometry(.06,12,10),white,s*.1,2.1,.23);
    add(new THREE.SphereGeometry(.03,10,8),em,s*.1,2.1,.28)
  });
  add(new THREE.ConeGeometry(.04,.1,8),skin,0,2.03,.28,[Math.PI/2,0,0]);
  add(new THREE.BoxGeometry(.18,.035,.03),dark,0,1.93,.26);
  if(k==0){
    const b=add(new THREE.SphereGeometry(.29,24,14,0,7,Math.PI*.55,Math.PI*.45),dark,0,2.04,.02);
    b.scale.set(1.02,1.12,1.06);
    add(new THREE.BoxGeometry(.08,.55,.03),M(0x0b2f8f),0,1.35,.37)
  }
  if(k==1){
    [-1,1].forEach(s=>add(new THREE.TorusGeometry(.075,.012,8,20),dark,s*.1,2.1,.27));
    add(new THREE.BoxGeometry(.06,.012,.012),dark,0,2.11,.27);
    const h=add(new THREE.SphereGeometry(.3,24,14,0,7,0,Math.PI*.58),dark,0,2.08,-.02);
    h.scale.y=1.1;
    add(new THREE.SphereGeometry(.12,14,10),dark,0,2.38,-.1);
    add(new THREE.CylinderGeometry(.3,.42,.5,18),cloth,0,.85,0);
    add(new THREE.BoxGeometry(.26,.34,.02),white,.5,.9,.3)
  }
  if(k==2){
    [-1,1].forEach(s=>add(new THREE.SphereGeometry(.09,10,8),white,s*.27,2.08,0));
    add(new THREE.SphereGeometry(.2,16,8,0,7,0,Math.PI*.4),white,0,2.14,-.05);
    add(new THREE.BoxGeometry(.16,.035,.03),white,0,1.96,.27);
    add(new THREE.CylinderGeometry(.02,.02,.9,8),M(0x3a2410),.58,.45,.28);
    add(new THREE.SphereGeometry(.05,8,8),M(0x3a2410),.58,.92,.28)
  }
  g.scale.setScalar([1.2,1.02,.88][k]);
  S.add(g);
  return g
}
const BOTS=[{n:'Ysea',k:0,s:1.2,start:'lab',side:'L'},{n:'Laurimar',k:1,s:1.02,start:'cancha',side:'R'},{n:'Peña',k:2,s:.88,start:'aula',side:'?',st:true}];
const CB=tex(256,256,(g,w,h)=>{
  g.fillStyle='#808080';
  g.fillRect(0,0,w,h);
  for(let i=0;i<1800;i++){
    g.strokeStyle='rgba('+(Math.random()<.5?'0,0,0':'255,255,255')+','+Math.random()*.25+')';
    g.lineWidth=1;
    g.beginPath();
    const x=Math.random()*w,y=Math.random()*h;
    g.moveTo(x,y);
    g.lineTo(x+Math.random()*10-5,y+Math.random()*14);
    g.stroke()
  }
},3,3);
function faceTex(k){
  const Wd=2048;
  return tex(Wd,Wd/2,(g,W,H)=>{
    const u=W/1024,sc=['222,178,150','238,198,174','212,174,150','128,84,56'][k];
    g.fillStyle='rgb('+sc+')';
    g.fillRect(0,0,W,H);
    for(let i=0;i<9000;i++){
      g.fillStyle=Math.random()<.5?'rgba(90,50,40,'+Math.random()*.05+')':'rgba(255,235,215,'+Math.random()*.05+')';
      g.beginPath();
      g.arc(Math.random()*W,Math.random()*H,Math.random()*3*u+.5,0,7);
      g.fill()
    }
    const fx=W*.25,sh=(x,y,r,a)=>{
      const gr=g.createRadialGradient(x,y,0,x,y,r);
      gr.addColorStop(0,'rgba(50,15,15,'+a+')');
      gr.addColorStop(1,'rgba(50,15,15,0)');
      g.fillStyle=gr;
      g.fillRect(x-r,y-r,2*r,2*r)
    };
    [-1,1].forEach(s=>{
      sh(fx+s*.056*W,H*.455,34*u,.45);
      sh(fx+s*.056*W,H*.5,26*u,k==2?.5:.25)
    });
    sh(fx,H*.56,30*u,.25);
    g.lineCap='round';
    g.strokeStyle=k==1?'rgba(150,30,50,.95)':k==3?'rgba(35,10,8,.95)':'rgba(90,40,40,.9)';
    g.lineWidth=(k==1?7:4)*u;
    g.beginPath();
    g.moveTo(fx-.045*W,H*.625);
    g.quadraticCurveTo(fx,H*.635,fx+.045*W,H*.625);
    g.stroke();
    if(k==2){
      g.strokeStyle='rgba(70,35,30,.4)';
      g.lineWidth=2*u;
      for(let i=0;i<5;i++){
        const y=H*(.31+i*.022);
        g.beginPath();
        g.moveTo(fx-.07*W,y);
        g.quadraticCurveTo(fx,y-9*u,fx+.07*W,y);
        g.stroke()
      }
      [-1,1].forEach(s=>{
        g.beginPath();
        g.moveTo(fx+s*.03*W,H*.55);
        g.quadraticCurveTo(fx+s*.055*W,H*.6,fx+s*.05*W,H*.65);
        g.stroke()
      });
      for(let i=0;i<60;i++){
        g.fillStyle='rgba(110,70,40,'+Math.random()*.35+')';
        g.beginPath();
        g.arc(fx+(Math.random()-.5)*.2*W,H*(.25+Math.random()*.2),Math.random()*4*u+1,0,7);
        g.fill()
      }
    }
    if(k==0||k==3){
      for(let i=0;i<7000;i++){
        g.fillStyle='rgba(20,15,15,'+Math.random()*.5+')';
        g.fillRect(fx+(Math.random()-.5)*.26*W,H*(.55+Math.random()*.25),1.5*u,1.5*u)
      }
    }
    if(k==3){
      const gr=g.createRadialGradient(fx,H*.22,0,fx,H*.22,.1*W);
      gr.addColorStop(0,'rgba(255,225,190,.3)');
      gr.addColorStop(1,'rgba(255,225,190,0)');
      g.fillStyle=gr;
      g.fillRect(fx-.1*W,H*.22-.1*W,.2*W,.2*W)
    }
  },1,1,1)
}
function mkProf2(k){
  const g=new THREE.Group(),up=new THREE.Group(),hd=new THREE.Group();
  up.position.y=.95;
  hd.position.set(0,1.1,0);
  up.add(hd);
  g.add(up);
  const M=(c,r=.6,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
  const flesh=M([0xdcb296,0xeec6ac,0xd2aa8e][k],.5),skin=new THREE.MeshStandardMaterial({map:faceTex(k),roughness:k==0?.3:.55});
  const ad=(p,geo,m,x,y,z,r,s)=>{
    const o=new THREE.Mesh(geo,m);
    o.position.set(x,y,z);
    if(r)o.rotation.set(r[0],r[1],r[2]);
    if(s)o.scale.set(s[0],s[1],s[2]);
    o.castShadow=true;
    p.add(o);
    return o
  };
  const U=(a,m,x,y,z,r,s)=>ad(up,a,m,x,y-.95,z,r,s),G=(a,m,x,y,z,r,s)=>ad(g,a,m,x,y,z,r,s),Hd=(a,m,x,y,z,r,s)=>ad(hd,a,m,x,y,z,r,s);
  const cl=[M(0x1c4fd0,.8),M(0x1b2a6e,.55),M(0x6b5b43,.9)][k],
    pa=[M(0x1a1c24,.8),M(0x15151b,.5),M(0x4a4a50,.8)][k],
    dk=M(0x0b0b0e,.5),
    wh=M(0xf0ebe4,.7),
    shoe=M(0x050505,.25,.3),
    hairM=M(k==2?0xe8e8ec:0x1a1210,.6),
    w=[1.18,.8,.88][k];
  [-1,1].forEach(s=>{
    G(new THREE.CylinderGeometry(.095*w,.075*w,.9,14),pa,s*.15*w,.47,0);
    G(new THREE.BoxGeometry(.13,.07,.3),shoe,s*.15*w,.04,.06);
    U(new THREE.CylinderGeometry(.065*w,.055*w,.8,12),cl,s*.42*w,1.4,.03,[.15,0,s*.06]);
    U(new THREE.BoxGeometry(.075,.13,.06),flesh,s*.46*w,.95,.1)
  });
  U(new THREE.CylinderGeometry(.3*w,.34*w,.9,20),cl,0,1.4,0);
  U(new THREE.SphereGeometry(.3*w,18,12),cl,0,1.82,0,null,[1.15,.5,.75]);
  U(new THREE.CylinderGeometry(.08,.09,.18,12),flesh,0,1.93,0);
  if(k==0){
    U(new THREE.SphereGeometry(.3,16,12),cl,0,1.2,.1,null,[1.15,1,.9]);
    const lg=new THREE.Mesh(new THREE.PlaneGeometry(.16,.07),new THREE.MeshBasicMaterial({map:tex(128,56,(c,a,b)=>{
      c.fillStyle='#fff';
      c.font='bold 34px Georgia';
      c.textAlign='center';
      c.textBaseline='middle';
      c.fillText('UNEFA',a/2,b/2)
    }),transparent:true}));
    lg.position.set(.14,.62,.335);
    up.add(lg)
  }
  if(k==1){
    U(new THREE.CylinderGeometry(.25,.34,.6,20),M(0x15151b,.6),0,.98,0);
    U(new THREE.BoxGeometry(.13,.34,.02),wh,0,1.62,.215,[.1,0,0]);
    [-1,1].forEach(s=>U(new THREE.BoxGeometry(.07,.36,.02),cl,s*.085,1.62,.225,[.1,0,s*.3]));
    U(new THREE.BoxGeometry(.26,.34,.02),wh,.5,1.05,.3,[.2,0,0]);
    U(new THREE.BoxGeometry(.1,.04,.03),dk,.5,1.23,.31)
  }
  if(k==2){
    up.rotation.x=.22;
    U(new THREE.BoxGeometry(.22,.5,.02),wh,0,1.55,.26);
    U(new THREE.BoxGeometry(.055,.42,.02),M(0x7a1220),0,1.5,.275);
    G(new THREE.CylinderGeometry(.018,.018,.9,8),M(0x3a2410,.5),.56,.45,.28);
    G(new THREE.TorusGeometry(.06,.016,8,14,Math.PI),M(0x3a2410,.5),.5,.9,.28)
  }
  Hd(new THREE.SphereGeometry(.28,48,36),skin,0,0,0,null,[1,1.12,1.03]);
  const red=new THREE.MeshBasicMaterial({color:new THREE.Color(5,.25,.06)});
  [-1,1].forEach(s=>{
    Hd(new THREE.SphereGeometry(.05,16,12),M(0xf2e8e2,.2),s*.1,.05,.22);
    Hd(new THREE.SphereGeometry(.028,12,10),dk,s*.1,.05,.262);
    Hd(new THREE.SphereGeometry(.013,8,8),red,s*.1,.05,.278);
    Hd(new THREE.BoxGeometry(k==2?.15:.12,k==2?.045:.022,.03),hairM,s*.1,.135,.245,[0,0,-s*.12]);
    Hd(new THREE.SphereGeometry(.05,12,10),flesh,s*.285,-.01,-.01,null,[.45,1,.8])
  });
  Hd(new THREE.SphereGeometry(.04,12,10),flesh,0,-.03,.272,null,[.9,1.35,1.15]);
  Hd(new THREE.BoxGeometry(.1,.012,.02),M(0x7a3a3a,.4),0,-.15,.252);
  if(k==0){
    Hd(new THREE.SphereGeometry(.29,32,16,Math.PI/2-1.15,2.3,Math.PI*.5+.2,.9),dk,0,0,0,null,[1.01,1.12,1.04]);
    Hd(new THREE.BoxGeometry(.15,.03,.035),dk,0,-.115,.258)
  }
  if(k==1){
    Hd(new THREE.SphereGeometry(.3,32,20,0,Math.PI*2,0,Math.PI*.36),hairM,0,.02,-.015,null,[1,1.12,1.06]);
    [-1,1].forEach(s=>{
      Hd(new THREE.BoxGeometry(.06,.55,.22),hairM,s*.285,-.15,-.04);
      Hd(new THREE.TorusGeometry(.07,.009,8,24),dk,s*.1,.05,.275);
      Hd(new THREE.CircleGeometry(.065,20),new THREE.MeshBasicMaterial({color:0x6a9cff,transparent:true,opacity:.12}),s*.1,.05,.276)
    });
    Hd(new THREE.BoxGeometry(.5,.62,.1),hairM,0,-.2,-.24);
    Hd(new THREE.SphereGeometry(.11,14,10),hairM,0,.3,-.17);
    Hd(new THREE.BoxGeometry(.06,.01,.01),dk,0,.06,.28)
  }
  if(k==2){
    [-1,1].forEach(s=>{
      Hd(new THREE.SphereGeometry(.09,10,8),hairM,s*.26,.03,-.04,null,[.7,1.4,1]);
      Hd(new THREE.TorusGeometry(.07,.008,8,24),M(0xc9a227,.3,.9),s*.1,.05,.275)
    });
    Hd(new THREE.BoxGeometry(.2,.04,.035),hairM,0,-.115,.258)
  }
  cl.bumpMap=CB;
  cl.bumpScale=.6;
  skin.bumpMap=skin.map;
  skin.bumpScale=.2;
  [-1,1].forEach(s=>{
    Hd(new THREE.SphereGeometry(.054,16,8,0,Math.PI*2,0,Math.PI*.45),flesh,s*.1,.052,.222,[.8,0,0]);
    for(let i=0;i<4;i++)U(new THREE.BoxGeometry(.014,.075,.016),flesh,s*.46*w+(i-1.5)*.017,.87,.1);
    U(new THREE.BoxGeometry(.03,.05,.02),flesh,s*.5*w,.93,.1);
    G(new THREE.BoxGeometry(.03,.1,.03),shoe,s*.15*w,.05,-.05)
  });
  U(new THREE.CylinderGeometry(.345*w,.345*w,.05,24),dk,0,1.0,0);
  Hd(new THREE.BoxGeometry(.09,.012,.01),wh,0,-.152,.247);
  for(let i=0;i<4;i++)U(new THREE.SphereGeometry(.012,8,6),wh,0,1.7-i*.12,.32*w+.005);
  g.userData.head=hd;
  g.userData.up=up;
  g.scale.setScalar([1.2,1.02,.88][k]);
  S.add(g);
  return g
}
BOTS.forEach(b=>b.m=mkProf2(b.k));
const jM=new THREE.MeshStandardMaterial({color:0x6a7078,roughness:.3,metalness:.9}),ledM=new THREE.MeshBasicMaterial({color:new THREE.Color(.2,3,.4)});
const blobT=tex(64,64,(g,w,h)=>{
  const r=g.createRadialGradient(32,32,2,32,32,32);
  r.addColorStop(0,'rgba(0,0,0,.7)');
  r.addColorStop(1,'rgba(0,0,0,0)');
  g.fillStyle=r;
  g.fillRect(0,0,w,h)
});
function detail(g,k){
  const up=g.userData.up,
    hd=g.userData.head,
    w=[1.18,.8,.88][k],
    A=(p,geo,x,y,z,r)=>{
    const o=new THREE.Mesh(geo,jM);
    o.position.set(x,y,z);
    if(r)o.rotation.set(r[0],r[1],r[2]);
    o.castShadow=true;
    p.add(o);
    return o
  };
  [-1,1].forEach(s=>{
    A(up,new THREE.SphereGeometry(.085,14,10),s*.36*w,.84,0);
    A(up,new THREE.SphereGeometry(.06,12,8),s*.43*w,.05,.04);
    A(g,new THREE.SphereGeometry(.07,12,8),s*.15*w,.47,0);
    A(hd,new THREE.CylinderGeometry(.028,.028,.09,8),s*.275,-.06,0,[0,0,Math.PI/2])
  });
  A(up,new THREE.TorusGeometry(.1,.022,8,16),0,.99,0,[Math.PI/2,0,0]);
  A(up,new THREE.BoxGeometry(.13,.1,.015),-.1*w,.62,.325*w);
  const l=new THREE.Mesh(new THREE.SphereGeometry(.018,8,6),ledM);
  l.position.set(-.1*w,.62,.335*w);
  up.add(l);
  const bl=new THREE.Mesh(new THREE.PlaneGeometry(1.3,1.3),new THREE.MeshBasicMaterial({map:blobT,transparent:true,depthWrite:false}));
  bl.rotation.x=-Math.PI/2;
  bl.position.y=.012;
  g.add(bl)
}
BOTS.forEach(b=>detail(b.m,b.k));
function mkRos(){
  const g=new THREE.Group(),up=new THREE.Group(),hd=new THREE.Group();
  up.position.y=.95;
  hd.position.set(0,1.1,0);
  up.add(hd);
  g.add(up);
  const M=(c,r=.7,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m});
  const flesh=M(0x7a4f33,.55),skin=new THREE.MeshStandardMaterial({map:faceTex(3),roughness:.5});
  const camo=tex(256,256,(c,w,h)=>{
    c.fillStyle='#4b5a34';
    c.fillRect(0,0,w,h);
    [['#2f3b20',16],['#6f7a4a',12],['#1e2615',12],['#8a7a52',8]].forEach(a=>{
      c.fillStyle=a[0];
      for(let i=0;i<a[1]*3;i++){
        const x=Math.random()*w,
          y=Math.random()*h,
          rx=14+Math.random()*30,
          ry=7+Math.random()*18,
          an=Math.random()*3;
        [-1,0,1].forEach(a1=>[-1,0,1].forEach(b1=>{
          c.beginPath();
          c.ellipse(x+a1*w,y+b1*h,rx,ry,an,0,7);
          c.fill()
        }))
      }
    })
  },2,2);
  const cl=new THREE.MeshStandardMaterial({map:camo,roughness:.85}),
    pa=new THREE.MeshStandardMaterial({map:camo,roughness:.85,color:0xcccccc}),
    dk=M(0x0b0b0e,.5),
    wh=M(0xf0ebe4,.7),
    boot=M(0x120d08,.3,.25),
    hairM=M(0x120c08,.7),
    gold=M(0xd4af37,.3,.9);
  const ad=(p,geo,m,x,y,z,r,sc)=>{
    const o=new THREE.Mesh(geo,m);
    o.position.set(x,y,z);
    if(r)o.rotation.set(r[0],r[1],r[2]);
    if(sc)o.scale.set(sc[0],sc[1],sc[2]);
    o.castShadow=true;
    p.add(o);
    return o
  };
  const U=(a,m,x,y,z,r,sc)=>ad(up,a,m,x,y-.95,z,r,sc),
    G=(a,m,x,y,z,r,sc)=>ad(g,a,m,x,y,z,r,sc),
    Hd=(a,m,x,y,z,r,sc)=>ad(hd,a,m,x,y,z,r,sc),
    w=1.12;
  [-1,1].forEach(s=>{
    G(new THREE.CylinderGeometry(.095*w,.075*w,.9,14),pa,s*.15*w,.47,0);
    G(new THREE.BoxGeometry(.14,.1,.32),boot,s*.15*w,.05,.06);
    U(new THREE.CylinderGeometry(.065*w,.055*w,.8,12),cl,s*.42*w,1.4,.03,[.15,0,s*.06]);
    U(new THREE.BoxGeometry(.08,.13,.07),flesh,s*.46*w,.95,.1);
    U(new THREE.BoxGeometry(.17,.03,.1),gold,s*.3*w,1.9,0,[0,0,s*.25])
  });
  U(new THREE.CylinderGeometry(.3*w,.34*w,.9,20),cl,0,1.4,0);
  U(new THREE.SphereGeometry(.3*w,18,12),cl,0,1.82,0,null,[1.15,.5,.75]);
  U(new THREE.CylinderGeometry(.09,.1,.18,12),flesh,0,1.93,0);
  U(new THREE.CylinderGeometry(.345*w,.345*w,.06,24),dk,0,1.0,0);
  U(new THREE.BoxGeometry(.08,.06,.02),gold,0,1.0,.346*w);
  const nt=new THREE.Mesh(new THREE.PlaneGeometry(.2,.06),new THREE.MeshBasicMaterial({map:tex(256,80,(c,W,H)=>{
    c.fillStyle='#e8e2c8';
    c.fillRect(0,0,W,H);
    c.fillStyle='#1b2a12';
    c.font='bold 46px Arial,sans-serif';
    c.textAlign='center';
    c.textBaseline='middle';
    c.fillText('ROSALES',W/2,H/2+2)
  })}));
  nt.position.set(.12,.66,.352*w);
  up.add(nt);
  Hd(new THREE.SphereGeometry(.28,48,36),skin,0,0,0,null,[1,1.12,1.03]);
  const red=new THREE.MeshBasicMaterial({color:new THREE.Color(5,.25,.06)});
  [-1,1].forEach(s=>{
    Hd(new THREE.SphereGeometry(.05,16,12),M(0xf2e8e2,.2),s*.1,.05,.22);
    Hd(new THREE.SphereGeometry(.028,12,10),dk,s*.1,.05,.262);
    Hd(new THREE.SphereGeometry(.013,8,8),red,s*.1,.05,.278);
    Hd(new THREE.BoxGeometry(.15,.05,.03),hairM,s*.1,.135,.245,[0,0,-s*.12]);
    Hd(new THREE.SphereGeometry(.05,12,10),flesh,s*.285,-.01,-.01,null,[.45,1,.8])
  });
  Hd(new THREE.SphereGeometry(.04,12,10),flesh,0,-.03,.272,null,[.9,1.35,1.15]);
  Hd(new THREE.BoxGeometry(.1,.012,.02),M(0x2a0f0c,.4),0,-.15,.252);
  Hd(new THREE.BoxGeometry(.17,.035,.035),hairM,0,-.105,.258);
  Hd(new THREE.SphereGeometry(.29,32,16,Math.PI/2+1.0,Math.PI*2-2.0,Math.PI*.3,Math.PI*.38),hairM,0,0,0,null,[1.01,1.12,1.04]);
  const bl=new THREE.Mesh(new THREE.PlaneGeometry(1.3,1.3),new THREE.MeshBasicMaterial({map:blobT,transparent:true,depthWrite:false}));
  bl.rotation.x=-Math.PI/2;
  bl.position.y=.012;
  g.add(bl);
  g.userData.head=hd;
  g.userData.up=up;
  g.scale.setScalar(1.12);
  S.add(g);
  return g
}
const ROS={n:'Rosales',k:3,s:1.12,m:mkRos(),loc:'off',t:0,door:0,side:'L'};
ROS.m.visible=false;
[[0,0],[-2,-5],[2,-5]].forEach(p=>{
  const c=new THREE.Mesh(new THREE.CylinderGeometry(.15,1.1,2.9,24,1,true),new THREE.MeshBasicMaterial({color:new THREE.Color(.25,.4,.8),transparent:true,opacity:.05,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.DoubleSide}));
  c.position.set(p[0],1.5,p[1]);
  S.add(c)
});
[[0,2.95,0],[-2,2.95,-5],[2,2.95,-5],[0,2.95,-13],[-11,2.95,-13],[11,2.95,-13]].forEach(p=>{
  const l=new THREE.Mesh(new THREE.BoxGeometry(1.4,.05,.4),new THREE.MeshBasicMaterial({color:new THREE.Color(.8,.9,1.05)}));
  l.position.set(...p);
  S.add(l)
});
const dg=new THREE.BufferGeometry(),dp=new Float32Array(900);
for(let i=0;i<900;i+=3){
  dp[i]=(Math.random()-.5)*7;
  dp[i+1]=Math.random()*2.8;
  dp[i+2]=Math.random()*5.5-2.5
}
dg.setAttribute('position',new THREE.BufferAttribute(dp,3));
const dust=new THREE.Points(dg,new THREE.PointsMaterial({color:0xaac8ff,size:.025,transparent:true,opacity:.3}));
S.add(dust);
const NODE={aula:[0,-13],lab:[-11,-16.3],cancha:[11,-16],coord:[0,-24.3],pasL:[-2,-6],pasR:[2,-6],dL:[-2,-3.7],dR:[2,-3.7]};
function place(b,i){
  const p=NODE[b.loc];
  b.m.position.set(p[0]+(b.loc=='aula'||b.loc=='lab'||b.loc=='cancha'||b.loc=='coord'?(i-1)*2.4:0),0,p[1]);
  b.m.lookAt(0,0,3)
}

/* ---------- audio ---------- */
let AC;
const au=()=>AC||(AC=new (window.AudioContext||window.webkitAudioContext)());
function tone(f,d,ty='sine',v=.12,f2,p){
  if(!SND)return;
  try{
    const a=au(),o=a.createOscillator(),g=a.createGain();
    o.type=ty;
    o.frequency.setValueAtTime(f,a.currentTime);
    if(f2)o.frequency.exponentialRampToValueAtTime(f2,a.currentTime+d);
    g.gain.setValueAtTime(v,a.currentTime);
    g.gain.exponentialRampToValueAtTime(.0001,a.currentTime+d);
    if(p&&a.createStereoPanner){
      const sp=a.createStereoPanner();
      sp.pan.value=p;
      o.connect(g);
      g.connect(sp);
      sp.connect(a.destination)
    }else{
      o.connect(g);
      g.connect(a.destination)
    }
    o.start();
    o.stop(a.currentTime+d)
  }catch(e){}
}
function nz(d,v){
  if(!SND)return;
  try{
    const a=au(),b=a.createBuffer(1,a.sampleRate*d,a.sampleRate),x=b.getChannelData(0);
    for(let i=0;i<x.length;i++)x[i]=(Math.random()*2-1)*(1-i/x.length);
    const s=a.createBufferSource();
    s.buffer=b;
    const g=a.createGain();
    g.gain.value=v;
    s.connect(g);
    g.connect(a.destination);
    s.start()
  }catch(e){}
}
let hum;
function scream(){
  if(!SND)return;
  try{
    const a=au(),t=a.currentTime,m=a.createGain();
    m.gain.value=1.4;
    const ws=a.createWaveShaper(),cv=new Float32Array(256);
    for(let i=0;i<256;i++)cv[i]=Math.tanh((i/128-1)*6);
    ws.curve=cv;
    m.connect(ws);
    ws.connect(a.destination);
    [[620,2600,'sawtooth',.5],[880,3300,'square',.3],[90,30,'sawtooth',.9],[1500,700,'sawtooth',.25]].forEach(q=>{
      const o=a.createOscillator(),
        g=a.createGain(),
        l=a.createOscillator(),
        lg=a.createGain();
      o.type=q[2];
      o.frequency.setValueAtTime(q[0],t);
      o.frequency.exponentialRampToValueAtTime(q[1],t+1.3);
      g.gain.setValueAtTime(q[3],t);
      g.gain.exponentialRampToValueAtTime(.001,t+1.8);
      l.frequency.value=38;
      lg.gain.value=q[0]*.25;
      l.connect(lg);
      lg.connect(o.frequency);
      l.start(t);
      l.stop(t+1.8);
      o.connect(g);
      g.connect(m);
      o.start(t);
      o.stop(t+1.8)
    });
    nz(2,1.5)
  }catch(e){}
}
let RB;
function ruler(v,pan,tock){
  if(!SND)return;
  try{
    const a=au(),t=a.currentTime,n=Math.floor(a.sampleRate*.08);
    if(!RB||RB.length!==n){
      RB=a.createBuffer(1,n,a.sampleRate);
      const x=RB.getChannelData(0);
      for(let i=0;i<n;i++)x[i]=(Math.random()*2-1)*Math.pow(1-i/n,3)
    }
    const s=a.createBufferSource();
    s.buffer=RB;
    const f=a.createBiquadFilter();
    f.type='bandpass';
    f.frequency.value=tock?1300:2300;
    f.Q.value=2;
    const g=a.createGain();
    g.gain.value=v*1.6;
    s.connect(f);
    f.connect(g);
    const o=a.createOscillator(),og=a.createGain();
    o.type='square';
    o.frequency.setValueAtTime(tock?500:780,t);
    o.frequency.exponentialRampToValueAtTime(tock?230:360,t+.05);
    og.gain.setValueAtTime(v*.55,t);
    og.gain.exponentialRampToValueAtTime(.0001,t+.06);
    o.connect(og);
    let out=a.destination;
    if(a.createStereoPanner){
      const sp=a.createStereoPanner();
      sp.pan.value=pan;
      sp.connect(a.destination);
      out=sp
    }
    g.connect(out);
    og.connect(out);
    s.start(t);
    o.start(t);
    o.stop(t+.07)
  }catch(e){}
}
let MU=null,
  mt=0,
  mh=0,
  mn=0,
  mg=-1,
  mq=0;
function startMusic(){
  if(MU||!SND)return;
  try{
    const a=au(),m=a.createGain();
    m.gain.value=0;
    const lp=a.createBiquadFilter();
    lp.type='lowpass';
    lp.frequency.value=620;
    m.connect(lp);
    lp.connect(a.destination);
    const mk=(f,ty,g)=>{
      const o=a.createOscillator(),og=a.createGain();
      o.type=ty;
      o.frequency.value=f;
      og.gain.value=g;
      o.connect(og);
      og.connect(m);
      o.start();
      return o
    };
    mk(55,'sine',.55);
    mk(58.27,'triangle',.3);
    mk(110.5,'sawtooth',.1);
    mk(155.6,'triangle',.08);
    const l=a.createOscillator(),lg=a.createGain();
    l.frequency.value=.16;
    lg.gain.value=260;
    l.connect(lg);
    lg.connect(lp.frequency);
    l.start();
    MU={m,a}
  }catch(e){}
}
function mOff(){
  try{
    if(MU){
      MU.m.gain.cancelScheduledValues(0);
      MU.m.gain.setTargetAtTime(0,MU.a.currentTime,.15);
      mg=0
    }
  }catch(e){}
}
const MN=[220,233.1,220,164.8,185,174.6];
function music(dt,md){
  if(!MU)return;
  const mi=Math.pow(Math.max(0,Math.min(1,(16-md)/16)),1.4);
  mq-=dt;
  if(mq<=0){
    mq=.12;
    const g=Math.round(mi*100)/100;
    if(g!==mg){
      mg=g;
      try{
        MU.m.gain.setTargetAtTime(g*.12,MU.a.currentTime,.35)
      }catch(e){}
    }
  }
  if(mi>.12){
    mt-=dt;
    if(mt<=0){
      mt=3.4-mi*2;
      const f=MN[mn++%MN.length];
      tone(f,1.5,'triangle',.05+.07*mi,f*.985)
    }
  }
  if(mi>.55){
    mh-=dt;
    if(mh<=0){
      mh=1.1-.55*mi;
      tone(52,.2,'sine',.22*mi,34);
      setTimeout(()=>tone(52,.2,'sine',.16*mi,34),190)
    }
  }
}
function startHum(){
  return;
  if(hum)return;
  try{
    const a=au();
    hum=a.createOscillator();
    const g=a.createGain();
    hum.type='sawtooth';
    hum.frequency.value=48;
    g.gain.value=.025;
    hum.connect(g);
    g.connect(a.destination);
    hum.start()
  }catch(e){}
}

/* ---------- juego (Baldi) ---------- */
let st='menu',
  T=0,
  night=1,
  glitch=0,
  dieT=0,
  killer=null,
  camUp=false,
  out=false,
  lights={L:false,R:false},
  mx=0,
  my=0;
const CAMS=[],ci=0; /* cámaras de seguridad: reservado (sin uso por ahora) */
addEventListener('unhandledrejection',e=>{
  const n=e.reason&&e.reason.name;
  if(n=='NotAllowedError'||n=='AbortError'||n=='WrongDocumentError'||n=='InvalidStateError')e.preventDefault()
});
let P={x:0,z:.6,yaw:0,pt:0,sp:100},
  K={},
  nb=0,
  wr=0,
  nzv=0,
  yT=0,
  lH=0,
  lT=0,
  dcT=0,
  decN=0,
  decT=0,
  hair=0,
  hw=false,
  rosOn=false,
  cutT=0,
  buz=0,
  ti=0,
  qi=0,
  NB=null,
  run=false,
  peF=0,
  peA=0,
  pc=0;
const CUTD=2.2;
const G=[[0,0],[-2,-3],[-2,-6],[0,-9],[0,-13],[-7,-12.5],[-11,-13],[7,-12.5],[11,-13],[0,-18],[0,-23],[2,-3],[2,-6],[-15,-13],[-17.5,-13],[-17.5,-28],[0,-28],[17.5,-28],[17.5,-13],[15,-13],[0,-26],[-9,-6],[9,-6],[-17.5,-6],[17.5,-6],[20,-13],[25,-13],[-20,-13],[-25,-13],[20,-25],[25,-25],[-20,-25],[-25,-25],[17.5,-25],[-17.5,-25],[10,-4],[10,0],[-10,-4],[-10,0]],
  E=[[0,1],[1,2],[2,3],[3,4],[4,5],[5,6],[4,7],[7,8],[4,9],[9,10],[0,11],[11,12],[12,3],[6,13],[13,14],[14,15],[15,16],[16,17],[17,18],[18,19],[19,8],[16,20],[20,10],[2,21],[21,23],[23,14],[12,22],[22,24],[24,18],[18,25],[25,26],[14,27],[27,28],[18,33],[33,17],[14,34],[34,15],[33,29],[29,30],[34,31],[31,32],[22,35],[35,36],[21,37],[37,38]],
  AD=G.map(()=>[]),
  NX=[];
E.forEach(([a,b])=>{
  AD[a].push(b);
  AD[b].push(a)
});
G.forEach((_,t)=>{
  const pr=Array(G.length).fill(-1),q=[t];
  pr[t]=t;
  while(q.length){
    const a=q.shift();
    AD[a].forEach(b=>{
      if(pr[b]<0){
        pr[b]=a;
        q.push(b)
      }
    })
  }
  NX[t]=pr
});
const near=(x,z)=>{
  let b=0,d=1e9;
  for(let i=0;i<G.length;i++){
    const p=G[i],dx=p[0]-x,dz=p[1]-z,e=dx*dx+dz*dz;
    if(e<d){
      d=e;
      b=i
    }
  }
  return b
};
const CG=new Map(),CS=2,CM=.32;
COL.forEach(c=>{
  for(let i=Math.floor((c[0]-CM)/CS);i<=Math.floor((c[1]+CM)/CS);i++)for(let j=Math.floor((c[2]-CM)/CS);j<=Math.floor((c[3]+CM)/CS);j++){
    const k=i*1000+j;
    let a=CG.get(k);
    if(!a)CG.set(k,a=[]);
    a.push(c)
  }
});
let CGc=CG,
  BX0=-29.6,
  BX1=29.6,
  BZ0=-29.6,
  BZ1=3.7;
const cellC=(x,z)=>CGc.get(Math.floor(x/CS)*1000+Math.floor(z/CS));
function los(x1,z1,x2,z2){
  const d=Math.hypot(x2-x1,z2-z1),n=Math.ceil(d/.35);
  for(let i=1;i<n;i++){
    const t=i/n,
      x=x1+(x2-x1)*t,
      z=z1+(z2-z1)*t,
      a=cellC(x,z);
    if(a)for(const c of a)if(x>c[0]-.2&&x<c[1]+.2&&z>c[2]-.2&&z<c[3]+.2)return false
  }
  return true
}
function mon(b,dt,sp,tn,px,pz){
  let tx,tz;
  const a=near(b.x,b.z);
  if(a==tn){
    if(los(b.x,b.z,px,pz)){
      tx=px;
      tz=pz
    }else{
      tx=G[a][0];
      tz=G[a][1]
    }
  }else{
    const n=G[NX[tn][a]];
    if(los(b.x,b.z,n[0],n[1])){
      tx=n[0];
      tz=n[1]
    }else{
      tx=G[a][0];
      tz=G[a][1]
    }
  }
  const dx=tx-b.x,
    dz=tz-b.z,
    d=Math.hypot(dx,dz)||1,
    s=Math.min(d,sp*dt);
  b.x+=dx/d*s;
  b.z+=dz/d*s;
  b.m.position.x=b.x;
  b.m.position.z=b.z;
  if(d>.05)b.m.rotation.y=Math.atan2(dx,dz)
}
function roam(b){
  if(b.rt==null||near(b.x,b.z)==b.rt)b.rt=(Math.random()*G.length)|0;
  return b.rt
}
function mv(dx,dz){
  const r=.28;
  [[dx,0],[0,dz]].forEach(([a,b])=>{
    P.x+=a;
    P.z+=b;
    if(P.x<BX0||P.x>BX1||P.z<BZ0||P.z>BZ1){
      P.x-=a;
      P.z-=b;
      return
    }
    const ca=cellC(P.x,P.z);
    if(ca)for(const c of ca)if(P.x>c[0]-r&&P.x<c[1]+r&&P.z>c[2]-r&&P.z<c[3]+r){
      P.x-=a;
      P.z-=b;
      break
    }
  })
}
const NBP=[[0,-10.5],[-9,-11.5],[-25,-14],[14,-6],[26,-15],[25,-26],[-25,-26]],NBS=[];
const nbT=tex(128,160,(g,w,h)=>{
  g.fillStyle='#1e8c3a';
  g.fillRect(0,0,w,h);
  g.fillStyle='#fff';
  g.fillRect(12,14,w-24,50);
  g.fillStyle='#0c35a8';
  g.font='bold 28px Georgia';
  g.textAlign='center';
  g.fillText('MATH',w/2,50);
  g.font='bold 40px Georgia';
  g.fillStyle='#fff';
  g.fillText('+ − ×',w/2,118)
});
const nfm=new THREE.MeshBasicMaterial({color:0x2ad060}),nbm=new THREE.MeshBasicMaterial({map:nbT});
NBP.forEach(p=>{
  const m=new THREE.Mesh(new THREE.BoxGeometry(.34,.44,.05),[nfm,nfm,nfm,nfm,nbm,nbm]);
  m.position.set(p[0],1.05,p[1]);
  S.add(m);
  NBS.push(m)
});
const SNS=[];
[14,18,16,21,22,26,28,36].forEach(i=>{
  const m=new THREE.Mesh(new THREE.BoxGeometry(.22,.1,.38),new THREE.MeshStandardMaterial({color:0x2a6cff,emissive:0x1038a0,emissiveIntensity:.8,roughness:.4}));
  m.position.set(G[i][0],.9,G[i][1]);
  S.add(m);
  SNS.push(m)
});
var rk=0,
  yk=0,
  yst=0,
  lj=0;
const RUL=new THREE.Group();
RUL.position.set(.54,1.0,.12);
BOTS[0].m.add(RUL);
(function(){
  const t=tex(32,256,(g,w,h)=>{
    g.fillStyle='#e8c040';
    g.fillRect(0,0,w,h);
    g.fillStyle='#3a2a08';
    for(let i=0;i<32;i++)g.fillRect(0,i*8,i%4?8:15,1.6)
  });
  const m=new THREE.Mesh(new THREE.BoxGeometry(.07,.016,.8),new THREE.MeshStandardMaterial({map:t,roughness:.4}));
  m.position.set(0,0,.32);
  m.castShadow=true;
  RUL.add(m)
})();
function toast(t,ms){
  const e=$('ts');
  e.textContent=t;
  e.style.opacity=1;
  clearTimeout(toast.h);
  toast.h=setTimeout(()=>e.style.opacity=0,ms||2400)
}
function say(t,p){
  if(!SND)return;
  try{
    if(window.speechSynthesis){
      speechSynthesis.cancel();
      const u=new SpeechSynthesisUtterance(t);
      u.lang='es-ES';
      u.rate=.95;
      u.pitch=p||.6;
      speechSynthesis.speak(u)
    }
  }catch(e){}
}
const lock=()=>{
  if(!matchMedia('(pointer:coarse)').matches)try{
    const q=$('app').requestPointerLock();
    q&&q.catch&&q.catch(()=>{})
  }catch(e){}
};
function hairUI(){
  const e=$('rc'),h=Math.round(hair),w=hair>=70&&cutT<=0;
  if(h!==lpl){
    lpl=h;
    e.style.setProperty('--h',h+'%')
  }
  if(w!==lhw){
    lhw=w;
    e.classList.toggle('warn',w)
  }
}
function reset(){
  nb=wr=0;
  nzv=yT=lH=lT=dcT=decT=0;
  hair=10;
  hw=false;
  rosOn=false;
  cutT=0;
  cutKind=0;
  hcStop();
  qClr();
  mirK=-9;
  ROS.m.visible=false;
  $('cut').style.display='none';
  $('qz').style.display='none';
  $('wr').style.display='none';
  SNS.forEach(m=>m.visible=true);
  BOTS[1].pt=0;
  lj=0;
  P.x=0;
  P.z=.6;
  P.yaw=P.pt=0;
  P.sp=100;
  NBS.forEach(m=>m.visible=true);
  peF=0;
  peA=0;
  BOTS[2].m.visible=false;
  $('pe').style.display='none';
  [10,8,6].forEach((n,i)=>{
    const b=BOTS[i];
    b.x=G[n][0];
    b.z=G[n][1];
    b.rt=null;
    b.m.position.set(b.x,0,b.z)
  });
  $('nbn').textContent=0;
  hairUI();
  INT1.forEach(o=>o.cd=0);
  caps=0;
  ord=null;
  spdT=invT=0
}
/* ===== Cuaderno: hoja de papel con textura, problema escrito a lápiz y cuenta resuelta paso a paso ===== */
let qTm=[],
  qLock=false,
  qBt=[],
  qSkip=null,
  qPaper=false;
function qClr(){
  qTm.forEach(clearTimeout);
  qTm=[]
}
function qLater(f,ms){
  const id=setTimeout(()=>{
    const i=qTm.indexOf(id);
    if(i>=0)qTm.splice(i,1);
    f()
  },ms);
  qTm.push(id);
  return id
}
function paperTex(){
  const c=document.createElement('canvas');
  c.width=c.height=360;
  const g=c.getContext('2d');
  g.fillStyle='#f6f1e1';
  g.fillRect(0,0,360,360);
  for(let i=0;i<1400;i++){
    g.fillStyle='rgba('+(Math.random()<.5?'120,95,50':'255,255,255')+','+Math.random()*.07+')';
    g.fillRect(Math.random()*360,Math.random()*360,Math.random()*3+.5,Math.random()*3+.5)
  }
  g.lineWidth=.6;
  for(let i=0;i<170;i++){
    g.strokeStyle='rgba('+(Math.random()<.5?'150,120,70':'255,255,255')+','+Math.random()*.12+')';
    g.beginPath();
    const x=Math.random()*360,y=Math.random()*360;
    g.moveTo(x,y);
    g.quadraticCurveTo(x+Math.random()*14-7,y+Math.random()*14-7,x+Math.random()*22-11,y+Math.random()*22-11);
    g.stroke()
  }
  for(let i=0;i<5;i++){
    const x=40+Math.random()*280,
      y=40+Math.random()*280,
      r=40+Math.random()*50,
      gr=g.createRadialGradient(x,y,0,x,y,r);
    gr.addColorStop(0,'rgba(170,130,60,.06)');
    gr.addColorStop(1,'rgba(170,130,60,0)');
    g.fillStyle=gr;
    g.fillRect(x-r,y-r,r*2,r*2)
  }
  return c.toDataURL('image/jpeg',.85)
}
/* Escribe texto "a lápiz" (con lápiz que se mueve). Sin animaciones: instantáneo. */
function typeInto(el,txt,cps,done){
  clearTimeout(el._t);
  el.dataset.full=txt;
  if(!ANI||cps>=1e4){
    el.classList.remove('wr');
    el.textContent=txt;
    done&&done();
    return
  }
  el.textContent='';
  el.classList.add('wr');
  let i=0;
  const dl=Math.max(14,1000/cps),tick=()=>{
    i++;
    el.textContent=txt.slice(0,i);
    if(i>=txt.length){
      el.classList.remove('wr');
      el._t=0;
      done&&done()
    }else el._t=qLater(tick,dl)
  };
  el._t=qLater(tick,dl)
}
function typeDone(el){
  if(el._t){
    clearTimeout(el._t);
    el._t=0
  }
  if(el.dataset.full!=null)el.textContent=el.dataset.full;
  el.classList.remove('wr')
}
/* Pasos de la cuenta (sin dar la respuesta antes de que el jugador conteste) */
function workSteps(a,b,o,ex,c,ans){
  const L=[];
  if(ex){
    L.push('Primero la multiplicación:');
    L.push(b+' × '+c+' = '+b*c);
    L.push(a+' + '+b*c+' = '+ans)
  }
 else if(o==0){
    const tb=b-b%10,ub=b%10;
    if(tb>0){
      L.push(a+' + '+tb+' = '+(a+tb));
      if(ub>0)L.push((a+tb)+' + '+ub+' = '+ans)
    }
  else{
      const k=10-a%10;
      if(a%10>0&&b>k){
        L.push(a+' + '+k+' = '+(a+k));
        L.push((a+k)+' + '+(b-k)+' = '+ans)
      }else L.push(a+' + '+b+' = '+ans)
    }
  }
 else if(o==1){
    const tb=b-b%10,ub=b%10;
    if(tb>0){
      L.push(a+' − '+tb+' = '+(a-tb));
      if(ub>0)L.push((a-tb)+' − '+ub+' = '+ans)
    }
  else{
      const k=a%10;
      if(k>0&&k<b){
        L.push(a+' − '+k+' = '+(a-k));
        L.push((a-k)+' − '+(b-k)+' = '+ans)
      }else L.push(a+' − '+b+' = '+ans)
    }
  }
 else{
    if(b==10)L.push(a+' × 10 = '+ans);else if(b>10){
      L.push(a+' × 10 = '+a*10);
      L.push(a+' × '+(b-10)+' = '+a*(b-10));
      L.push(a*10+' + '+a*(b-10)+' = '+ans)
    }
  else if(b>5){
      L.push(a+' × 5 = '+a*5);
      L.push(a+' × '+(b-5)+' = '+a*(b-5));
      L.push(a*5+' + '+a*(b-5)+' = '+ans)
    }
  else L.push(Array(b).fill(a).join(' + ')+' = '+ans)
  }
  return L
}
function openQ(m){
  NB=m;
  st='quiz';
  qi=0;
  document.exitPointerLock&&document.exitPointerLock();
  if(!qPaper){
    qPaper=true;
    $('pp').style.setProperty('--tx','url('+paperTex()+')')
  }
  $('qz').style.display='flex';
  tone(520,.1,'square',.06);
  nz(.14,.05);
  nextQ()
}
function nextQ(){
  qClr();
  qSkip=null;
  if(st!='quiz')return;
  if(qi>=3)return closeQ();
  const lv=Math.min(nb,6),r=n=>3+((Math.random()*(9+lv*4))|0);
  let a=r(),b=r(),c=2+((Math.random()*5)|0);
  const o=qi==2?2:(Math.random()<.5?0:1),ex=nb>=2&&qi==1;
  if(o==1&&b>a)[a,b]=[b,a];
  if(o==2){
    a=2+((Math.random()*(6+lv))|0);
    b=2+((Math.random()*(5+lv))|0)
  }
  let ans=o==0?a+b:o==1?a-b:a*b;
  if(ex)ans=a+b*c;
  const opt=new Set([ans]);
  while(opt.size<4){
    const v=ans+((Math.random()*9)|0)-4;
    if(v!=ans&&v>=0)opt.add(v)
  }
  qLock=false;
  const pp=$('pp');
  pp.classList.remove('ok','no','done');
  $('sw').innerHTML='';
  $('qf').textContent='';
  $('qh').textContent='Cuaderno '+(nb+1)+' · Problema '+(qi+1)+' de 3';
  typeInto($('qq'),ex?a+' + '+b+' × '+c+' = ?':a+' '+'+−×'[o]+' '+b+' = ?',34);
  const q=$('qa');
  q.innerHTML='';
  qBt=[];
  [...opt].sort(()=>Math.random()-.5).forEach((v,i)=>{
    const x=document.createElement('button');
    x.type='button';
    x.dataset.v=v;
    x.innerHTML='<b>'+'ABCD'[i]+'</b><span>'+v+'</span><svg class="cr" viewBox="0 0 200 80" preserveAspectRatio="none" aria-hidden="true"><ellipse cx="100" cy="40" rx="96" ry="35" pathLength="1" transform="rotate(-2 100 40)"/></svg>';
    x.onclick=()=>{
      if(qLock)return;
      qLock=true;
      typeDone($('qq'));
      qBt.forEach(bb=>bb.disabled=true);
      x.classList.add('pick');
      const good=v==ans;
      if(good){
        tone(660,.15,'triangle',.12);
        say('¡Muy bien!',.5)
      }
   else{
        wr++;
        nzv=1;
        yT=8;
        {
          const c=G.map((_,i)=>i).filter(i=>Math.hypot(G[i][0]-P.x,G[i][1]-P.z)>12),n=G[c.length?c[(Math.random()*c.length)|0]:10],Pn=BOTS[2];
          if(peA<=0){
            Pn.x=n[0];
            Pn.z=n[1];
            Pn.m.position.set(n[0],0,n[1])
          }
          peA=16+wr*2
        }
        tone(110,.5,'sawtooth',.2,60);
        say('¡Incorrecto!',.4)
      }
      qLater(()=>solveQ(a,b,o,ex,c,ans,good,x),ANI?380:0)
    };
    q.appendChild(x);
    qBt.push(x)
  })
}
/* La cuenta se escribe a lápiz paso a paso; después la profesora marca ✓ o ✗ con lapicero rojo */
function solveQ(a,b,o,ex,c,ans,good,btn){
  const L=workSteps(a,b,o,ex,c,ans),sw=$('sw');
  sw.innerHTML='<div class="sh">✎ Cuenta</div>';
  let k=0;
  const fin=()=>{
    $('pp').classList.add(good?'ok':'no','done');
    btn.classList.add(good?'good':'bad');
    if(!good)qBt.forEach(bb=>{
      if(+bb.dataset.v==ans)bb.classList.add('good','pick')
    });
    $('qf').textContent=good?'¡Muy bien!':'¡INCORRECTO! Era '+ans+'. ¡Ysea se enfada y Peña viene por ti!';
    tone(good?784:180,.14,good?'triangle':'square',.07);
    const go=()=>{
      qSkip=null;
      qClr();
      qi++;
      nextQ()
    };
    qSkip=go;
    qLater(go,good?1000:2400)
  };
  const next=()=>{
    if(k>=L.length)return fin();
    const d=document.createElement('div');
    d.className='sl2'+(k==L.length-1?' fin':'');
    sw.appendChild(d);
    typeInto(d,L[k++],ANI?44:1e4,()=>qLater(next,ANI?150:0))
  };
  next()
}
function closeQ(){
  qClr();
  qSkip=null;
  $('qz').style.display='none';
  NB.visible=false;
  nb++;
  $('nbn').textContent=nb;
  nzv=Math.max(nzv,.6);
  yT=Math.max(yT,3);
  st='play';
  lock();
  [523,659,784].forEach((f,i)=>setTimeout(()=>tone(f,.2,'triangle',.1),i*110));
  toast(nb<7?'📓 Cuaderno '+nb+'/7. Ysea se acerca más rápido.':'¡Los 7 cuadernos! Corre a la OFICINA: todos te persiguen.',3500);
  if(nb==7)say('Ven aquí, ven a la oficina',.5)
}
function qKey(e){
  const k=e.code,n={Digit1:0,Digit2:1,Digit3:2,Digit4:3,Numpad1:0,Numpad2:1,Numpad3:2,Numpad4:3,KeyA:0,KeyB:1,KeyC:2,KeyD:3}[k];
  if(n!=null){
    const b=qBt[n];
    if(b&&!b.disabled)b.click();
    e.preventDefault();
    return
  }
  if((k=='Enter'||k=='Space'||k=='KeyE')&&qSkip){
    e.preventDefault();
    const f=qSkip;
    qSkip=null;
    f()
  }
}
$('pp').onclick=e=>{
  if(qSkip&&!e.target.closest('#qa button')){
    const f=qSkip;
    qSkip=null;
    f()
  }
};

/* ===== Corte de pelo: sólo en la máquina (barbería de Coordinación) o a la fuerza con Rosales ===== */
const CUTM=3.6,
  MQ={x:3.2,z:-24},
  CAMX=3.32,
  CAMZ=-24,
  CAMYAW=-Math.PI/2;
let cutKind=0,
  cutTot=1,
  cutCb=0,
  hS=0,
  mirK=-9,
  mirT=0,
  MIR=null,
  POLEM=null;
function addCol(c){
  COL.push(c);
  for(let i=Math.floor((c[0]-CM)/CS);i<=Math.floor((c[1]+CM)/CS);i++)for(let j=Math.floor((c[2]-CM)/CS);j<=Math.floor((c[3]+CM)/CS);j++){
    const k=i*1000+j;
    let a=CG.get(k);
    if(!a)CG.set(k,a=[]);
    a.push(c)
  }
}
function doCut(){
  if(st!='play'||cutT>0)return;
  if(LV!=1&&LV!=3){
    toast('Aquí no hace falta cortarse el pelo');
    return
  }
  if(hair<20){
    toast('Tu pelo está al día');
    return
  }
  const dx=MQ.x-P.x,
    dz=MQ.z-P.z,
    fw=-dx*Math.sin(P.yaw)-dz*Math.cos(P.yaw),
    rg=dx*Math.cos(P.yaw)-dz*Math.sin(P.yaw),
    d=Math.round(Math.hypot(dx,dz)),
    w=Math.abs(rg)>Math.abs(fw)?(rg>0?'a tu derecha':'a tu izquierda'):(fw>0?'al frente':'detrás de ti');
  toast('✂ El pelo ya no se corta aquí: ve a la BARBERÍA, en Coordinación Académica (a unos '+d+' m, '+w+') y usa E',5000);
  tone(520,.08,'square',.05)
}
function startHaircut(){
  if(st!='play'||cutT>0)return false;
  if(hair<15){
    toast('Tu pelo está al día: no hace falta cortarlo');
    return false
  }
  cutKind=1;
  cutTot=CUTM;
  cutT=CUTM;
  hS=hair;
  buz=0;
  $('cutt').textContent='✂ Cortándote el pelo…';
  $('cutb').style.width='0';
  $('cut').style.display='flex';
  tone(300,.1,'square',.08);
  hcStart(1);
  return true
}
function startRosCut(){
  cutKind=2;
  cutTot=3.5;
  cutT=3.5;
  hS=hair;
  buz=0;
  $('cutt').textContent='✂ Detención: Rosales te corta el pelo…';
  $('cutb').style.width='0';
  $('cut').style.display='flex';
  hcStart(2)
}
function cutTick(dt){
  if(cutT<=0)return;
  cutT-=dt;
  buz-=dt;
  const p=Math.min(1,Math.max(0,1-cutT/cutTot));
  if(buz<=0){
    buz=.2;
    tone(120+Math.random()*30,.22,'sawtooth',.045);
    if(Math.random()<.6)tone(2200+Math.random()*600,.03,'square',.02,1600)
  }
  hair=hS*(1-p);
  $('cutb').style.width=(p*100)+'%';
  if(cutT<=0){
    cutT=0;
    cutKind=0;
    cutDone()
  }
}
function cutDone(){
  $('cut').style.display='none';
  hair=0;
  hw=false;
  mirK=-9;
  const was=rosOn;
  rosOn=false;
  ROS.m.visible=false;
  hcEnd();
  fxText('✂ ¡Listo!');
  toast(was?'✂ Rosales: «Así se ve un soldado. Descansa.»':'✂ Pelo recortado. Presentación impecable',3200);
  [392,523].forEach((f,i)=>setTimeout(()=>tone(f,.2,'triangle',.1),i*140));
  hairUI()
}
/* --- espejo de la barbería: dibuja tu reflejo con el pelo que tienes (y la máquina mientras cortas) --- */
function drawMirror(len,p,t,cut){
  const g=MIR.g,
    W=256,
    H=384,
    cx=W/2,
    L=Math.max(0,Math.min(1,len));
  const bg=g.createLinearGradient(0,0,0,H);
  bg.addColorStop(0,'#b4c8da');
  bg.addColorStop(1,'#6f879b');
  g.fillStyle=bg;
  g.fillRect(0,0,W,H);
  g.fillStyle='rgba(255,255,240,.6)';
  g.fillRect(36,12,76,8);
  g.fillRect(146,12,76,8);
  g.fillStyle='#7a161d';
  rr(g,cx-74,168,148,230,18);
  g.fillStyle='#8c1a22';
  rr(g,cx-44,92,88,84,14);
  g.fillStyle='rgba(255,255,255,.12)';
  rr(g,cx-38,98,20,70,8);
 /* hombros: capa de barbero al cortar, uniforme azul si no */
  if(cut){
    g.fillStyle='#1d2c52';
    g.beginPath();
    g.moveTo(cx-128,H);
    g.quadraticCurveTo(cx-116,262,cx-36,240);
    g.lineTo(cx+36,240);
    g.quadraticCurveTo(cx+116,262,cx+128,H);
    g.closePath();
    g.fill();
    g.strokeStyle='rgba(255,255,255,.12)';
    g.lineWidth=2;
    g.beginPath();
    g.moveTo(cx-60,250);
    g.lineTo(cx-80,H);
    g.moveTo(cx+60,250);
    g.lineTo(cx+80,H);
    g.stroke()
  }
 else{
    g.fillStyle='#2d4f9e';
    g.beginPath();
    g.moveTo(cx-120,H);
    g.quadraticCurveTo(cx-108,250,cx-34,232);
    g.lineTo(cx+34,232);
    g.quadraticCurveTo(cx+108,250,cx+120,H);
    g.closePath();
    g.fill();
    g.fillStyle='#f2c230';
    g.fillRect(cx-4,250,8,70);
    g.fillStyle='#eee';
    g.beginPath();
    g.moveTo(cx-30,232);
    g.lineTo(cx,262);
    g.lineTo(cx+30,232);
    g.lineTo(cx+18,226);
    g.lineTo(cx,246);
    g.lineTo(cx-18,226);
    g.closePath();
    g.fill()
  }
  g.fillStyle='#d4a27c';
  rr(g,cx-20,196,40,46,10);
  g.fillStyle='#e8b994';
  g.beginPath();
  g.ellipse(cx,150,58,74,0,0,7);
  g.fill();
  g.fillStyle='#d9a47e';
  [-1,1].forEach(s=>{
    g.beginPath();
    g.ellipse(cx+s*58,152,9,15,0,0,7);
    g.fill()
  });
 /* pelo: largo según 'len' (0 = casi rapado) */
  const hc='#2b1a12';
  g.fillStyle=hc;
  if(L<.1){
    g.globalAlpha=.82;
    g.beginPath();
    g.ellipse(cx,134,58,64,0,Math.PI,0);
    g.fill();
    g.globalAlpha=1
  }
 else{
    const top=70+L*30;
    g.beginPath();
    g.ellipse(cx,136,60+L*14,66+L*28*.0+L*10,0,Math.PI,0);
    g.fill();
    g.beginPath();
    g.moveTo(cx-60,132);
    g.quadraticCurveTo(cx-10,top+20,cx+60,126);
    g.lineTo(cx+60,128+L*30);
    g.quadraticCurveTo(cx,100+L*22,cx-60,138+L*26);
    g.closePath();
    g.fill();
    if(L>.28){
      const sl=40+L*100,sw=14+L*18;
      rr(g,cx-72-L*10,118,sw,sl,10);
      rr(g,cx+72+L*10-sw,118,sw,sl,10)
    }
    if(L>.6){
      g.beginPath();
      g.ellipse(cx,118,90,40,0,Math.PI,0);
      g.fill()
    }
  }
 /* cara */
  g.fillStyle='#fff';
  [-1,1].forEach(s=>{
    g.beginPath();
    g.ellipse(cx+s*22,150,10,6.5,0,0,7);
    g.fill()
  });
  g.fillStyle='#2a1c14';
  [-1,1].forEach(s=>{
    g.beginPath();
    g.arc(cx+s*22,150,4,0,7);
    g.fill()
  });
  g.strokeStyle='#2a1810';
  g.lineWidth=4;
  g.lineCap='round';
  [-1,1].forEach(s=>{
    g.beginPath();
    g.moveTo(cx+s*12,138);
    g.lineTo(cx+s*34,cut?135:136);
    g.stroke()
  });
  g.strokeStyle='#b07c5a';
  g.lineWidth=3;
  g.beginPath();
  g.moveTo(cx,152);
  g.lineTo(cx-5,176);
  g.lineTo(cx+4,178);
  g.stroke();
  g.strokeStyle='#8a3f3a';
  g.lineWidth=3.5;
  g.beginPath();
  g.moveTo(cx-17,194);
  g.quadraticCurveTo(cx,cut?206:202,cx+17,194);
  g.stroke();
 /* máquina de cortar con vibración y pelitos cayendo */
  if(cut){
    const sx=cx+Math.sin(t*3.6)*46,
      sy=Math.max(70,128-p*18*0+Math.sin(t*7)*3)-(L>.4?0:0),
      vx=(Math.random()-.5)*2,
      vy=(Math.random()-.5)*2;
    g.save();
    g.translate(sx+vx,sy+vy);
    g.rotate(-.5+Math.sin(t*3.6)*.25);
    g.fillStyle='#23262d';
    rr(g,-14,-62,28,62,8);
    g.fillStyle='#c0262a';
    g.fillRect(-4,-50,8,10);
    g.fillStyle='#cfd6df';
    g.fillRect(-17,0,34,8);
    g.fillStyle='#8892a0';
    for(let i=-16;i<17;i+=4)g.fillRect(i,8,2,6);
    g.restore();
    g.strokeStyle=hc;
    g.lineWidth=2;
    for(let i=0;i<9;i++){
      const k=(t*2.2+i*.37)%1,x=sx-30+((i*53)%60)+Math.sin(t*5+i)*6,y=sy+10+k*(210+i*5);
      g.beginPath();
      g.moveTo(x,y);
      g.lineTo(x+6*Math.sin(i),y+9);
      g.stroke()
    }
  }
  const sh=g.createLinearGradient(0,0,W,H);
  sh.addColorStop(0,'rgba(255,255,255,.28)');
  sh.addColorStop(.35,'rgba(255,255,255,.04)');
  sh.addColorStop(.36,'rgba(255,255,255,.14)');
  sh.addColorStop(.5,'rgba(255,255,255,0)');
  g.fillStyle=sh;
  g.fillRect(0,0,W,H);
  g.strokeStyle='rgba(0,0,0,.35)';
  g.lineWidth=6;
  g.strokeRect(0,0,W,H);
  MIR.t.needsUpdate=true
}
function barberTick(dt){
  if(LV==2||!MIR)return;
  const dx=P.x-MQ.x,dz=P.z-MQ.z;
  if(dx*dx+dz*dz>196)return;
  POLEM.map.offset.y=(T*.35)%1;
  if(cutKind==1&&cutT>0){
    mirT-=dt;
    if(mirT<=0){
      mirT=1/24;
      drawMirror(hair/100,1-cutT/cutTot,T,true)
    }
  }
 else{
    const k=Math.round(hair/5);
    if(k!==mirK){
      mirK=k;
      drawMirror(hair/100,0,T,false)
    }
  }
}
/* --- pelitos que caen al piso (3D, instanciados: una sola llamada de dibujo) --- */
const HN=72,
  hcPos=new Float32Array(HN*3),
  hcVel=new Float32Array(HN*3),
  hcRot=new Float32Array(HN),
  hcLd=new Uint8Array(HN),
  hcO=new THREE.Object3D();
let HCI=null,
  hcI=0,
  hcLife=0,
  hcBusy=0,
  hcSp3=0;
function hc3Init(){
  HCI=new THREE.InstancedMesh(new THREE.BoxGeometry(.1,.005,.012),new THREE.MeshStandardMaterial({color:0x2a1810,roughness:.9}),HN);
  HCI.frustumCulled=false;
  HCI.visible=false;
  S.add(HCI)
}
function hc3Reset(){
  if(!HCI)return;
  hcI=0;
  hcLife=0;
  hcBusy=0;
  hcLd.fill(1);
  hcO.position.set(0,-5,0);
  hcO.scale.set(0,0,0);
  hcO.rotation.set(0,0,0);
  hcO.updateMatrix();
  for(let i=0;i<HN;i++)HCI.setMatrixAt(i,hcO.matrix);
  hcO.scale.set(1,1,1);
  HCI.instanceMatrix.needsUpdate=true;
  HCI.visible=true
}
function hc3Emit(){
  const i=hcI++%HN,k=i*3;
  hcPos[k]=MQ.x+.05+(Math.random()-.5)*.3;
  hcPos[k+1]=1.15+Math.random()*.2;
  hcPos[k+2]=MQ.z+(Math.random()-.5)*.3;
  hcVel[k]=(Math.random()-.5)*.35;
  hcVel[k+1]=Math.random()*.4;
  hcVel[k+2]=(Math.random()-.5)*.35;
  hcRot[i]=Math.random()*6.28;
  hcLd[i]=0;
  hcBusy=1
}
function hc3Tick(dt){
  if(!HCI||!HCI.visible)return;
  const cutting=cutKind==1&&cutT>0;
  if(cutting){
    hcSp3+=dt*30;
    while(hcSp3>=1){
      hcSp3--;
      hc3Emit()
    }
  }
  if(hcBusy){
    let any=0;
    for(let i=0;i<HN;i++){
      if(hcLd[i])continue;
      any=1;
      const k=i*3;
      hcVel[k+1]-=3.4*dt;
      hcPos[k]+=hcVel[k]*dt;
      hcPos[k+1]+=hcVel[k+1]*dt;
      hcPos[k+2]+=hcVel[k+2]*dt;
      hcRot[i]+=dt*3;
      if(hcPos[k+1]<=.03){
        hcPos[k+1]=.03;
        hcLd[i]=1
      }
      hcO.position.set(hcPos[k],hcPos[k+1],hcPos[k+2]);
      hcO.rotation.set(hcLd[i]?0:hcRot[i],hcRot[i],hcLd[i]?0:hcRot[i]*.7);
      hcO.updateMatrix();
      HCI.setMatrixAt(i,hcO.matrix)
    }
    HCI.instanceMatrix.needsUpdate=true;
    hcBusy=any
  }
  if(!cutting){
    hcLife+=dt;
    if(hcLife>28)HCI.visible=false
  }
}
/* --- pelitos y capa en pantalla (canvas 2D, sólo mientras dura el corte) --- */
let hcOn=0,
  hcFade=0,
  hcK=0,
  hcSp=0,
  hcCv=null,
  hcG=null;
const hcP=[],hcL=[];
for(let i=0;i<60;i++)hcP.push({on:0,x:0,y:0,vx:0,vy:0,a:0,va:0,l:0,ph:0});
function hcSize(){
  const w=innerWidth,h=innerHeight;
  if(hcCv.width!==w||hcCv.height!==h){
    hcCv.width=w;
    hcCv.height=h
  }
}
function hcStart(k){
  hcK=k;
  if(!ANI)return;
  hcOn=1;
  hcFade=0;
  hcSp=0;
  hcP.forEach(p=>p.on=0);
  hcL.length=0;
  hcCv=$('hc');
  hcG=hcG||hcCv.getContext('2d');
  hcCv.style.display='block';
  hcCv.style.opacity=1;
  hcSize();
  if(k==1)hc3Reset()
}
function hcEnd(){
  if(hcOn&&!hcFade)hcFade=.0001
}
function hcStop(){
  hcOn=0;
  hcFade=0;
  if(hcCv)hcCv.style.display='none';
  if(HCI)HCI.visible=false
}
const capeY=(x,W,H)=>{
  const u=Math.abs(x/W-.5)*2;
  let y=H*(.8+.07*u*u);
  if(u<.2)y+=H*.05*(1-(u/.2)*(u/.2));
  return y
};
function hcDraw(dt){
  if(!hcOn)return;
  hcSize();
  const g=hcG,
    W=hcCv.width,
    H=hcCv.height,
    sc=H/720;
  if(hcFade){
    hcFade+=dt;
    if(hcFade>=.7){
      hcStop();
      return
    }
    hcCv.style.opacity=Math.max(0,1-hcFade/.7)
  }
 else if(cutT>0){
    hcSp+=dt*(hcK==1?26:34);
    while(hcSp>=1){
      hcSp--;
      const p=hcP.find(q=>!q.on);
      if(!p)break;
      p.on=1;
      p.x=W*(hcK==1?.5+(Math.random()-.5)*.22:.12+Math.random()*.76);
      p.y=H*(hcK==1?.16:-.02);
      p.vx=(Math.random()-.5)*90*sc;
      p.vy=(40+Math.random()*80)*sc;
      p.a=Math.random()*6.28;
      p.va=(Math.random()-.5)*8;
      p.l=(14+Math.random()*22)*sc;
      p.ph=Math.random()*6.28
    }
  }
  g.clearRect(0,0,W,H);
 /* capa */
  g.beginPath();
  g.moveTo(0,H);
  for(let i=0;i<=48;i++){
    const x=i/48*W;
    g.lineTo(x,capeY(x,W,H))
  }
  g.lineTo(W,H);
  g.closePath();
  const cg=g.createLinearGradient(0,H*.78,0,H);
  cg.addColorStop(0,'#26386a');
  cg.addColorStop(1,'#0b1226');
  g.fillStyle=cg;
  g.fill();
  g.strokeStyle='rgba(255,255,255,.09)';
  g.lineWidth=2*sc+1;
  for(let i=1;i<6;i++){
    g.beginPath();
    g.moveTo(W*(i/6),capeY(W*i/6,W,H)+4);
    g.quadraticCurveTo(W*(i/6)+(i-3)*14*sc,H*.93,W*(i/6)+(i-3)*30*sc,H);
    g.stroke()
  }
  g.lineCap='round';
  g.lineWidth=Math.max(1.8,2.8*sc);
  g.strokeStyle='#4a2f1e';
  for(const q of hcL){
    g.save();
    g.translate(q[0],q[1]);
    g.rotate(q[2]);
    g.beginPath();
    g.moveTo(-q[3]/2,0);
    g.quadraticCurveTo(0,q[3]*.3,q[3]/2,0);
    g.stroke();
    g.restore()
  }
  for(const p of hcP){
    if(!p.on)continue;
    p.vy=Math.min(p.vy+520*sc*dt,700*sc);
    p.x+=(p.vx+Math.sin(T*3+p.ph)*28*sc)*dt;
    p.y+=p.vy*dt;
    p.a+=p.va*dt;
    const cy=capeY(p.x,W,H);
    if(p.y>=cy){
      p.on=0;
      if(hcL.length<110)hcL.push([p.x,cy+Math.random()*H*.05,p.a,p.l]);
      continue
    }
    g.save();
    g.translate(p.x,p.y);
    g.rotate(p.a);
    g.beginPath();
    g.moveTo(-p.l/2,0);
    g.quadraticCurveTo(0,p.l*.35,p.l/2,0);
    g.stroke();
    g.restore()
  }
}
/* --- construcción de la barbería (silla, espejo, poste, carrito) en Coordinación --- */
function buildBarber(){
  const M=(c,r=.5,m=.1)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m}),
    ad=(p,geo,m,x,y,z,r)=>{
    const o=new THREE.Mesh(geo,m);
    o.position.set(x,y,z);
    if(r)o.rotation.set(r[0],r[1],r[2]);
    p.add(o);
    return o
  },
    leather=M(0x8c1a22,.38,.15),
    chrome=M(0xc9d1da,.2,.9),
    blk=M(0x1b1e24,.5,.4),
    dwood=M(0x3a2414,.55,.05),
    gold=M(0xc9a227,.3,.8),
    wood=M(0x5a3b22,.55,.05);
  const ch=new THREE.Group();
  ch.position.set(MQ.x,0,MQ.z);
  ch.rotation.y=Math.PI/2;
  S.add(ch);
  ad(ch,new THREE.CylinderGeometry(.33,.37,.05,22),blk,0,.025,0);
  ad(ch,new THREE.CylinderGeometry(.08,.1,.34,12),chrome,0,.22,0);
  ad(ch,new THREE.BoxGeometry(.6,.12,.58),leather,0,.46,0);
  ad(ch,new THREE.BoxGeometry(.56,.74,.12),leather,0,.9,-.27,[-.1,0,0]);
  ad(ch,new THREE.BoxGeometry(.3,.2,.1),leather,0,1.4,-.31,[-.1,0,0]);
  ad(ch,new THREE.BoxGeometry(.06,.14,.06),chrome,0,1.27,-.3);
  [-1,1].forEach(s=>{
    ad(ch,new THREE.BoxGeometry(.07,.06,.46),blk,s*.34,.7,-.02);
    ad(ch,new THREE.BoxGeometry(.05,.24,.05),chrome,s*.34,.57,.14)
  });
  ad(ch,new THREE.BoxGeometry(.46,.05,.26),chrome,0,.2,.5,[.35,0,0]);
  ad(ch,new THREE.BoxGeometry(.05,.32,.05),chrome,0,.34,.36,[.2,0,0]);
  addCol([MQ.x-.4,MQ.x+.6,MQ.z-.36,MQ.z+.36]);
  const rug=new THREE.Mesh(new THREE.PlaneGeometry(1.7,1.5),M(0x25282e,.95,0));
  rug.rotation.x=-Math.PI/2;
  rug.position.set(MQ.x+.2,.014,MQ.z);
  S.add(rug);
 /* espejo con marco, letrero y poste giratorio en la pared este */
  MIR={c:document.createElement('canvas')};
  MIR.c.width=256;
  MIR.c.height=384;
  MIR.g=MIR.c.getContext('2d');
  MIR.t=new THREE.CanvasTexture(MIR.c);
  MIR.t.encoding=THREE.sRGBEncoding;
  drawMirror(.1,0,0,false);
  const mf=new THREE.Group();
  mf.position.set(4.83,1.3,MQ.z);
  mf.rotation.y=-Math.PI/2;
  S.add(mf);
  ad(mf,new THREE.BoxGeometry(1.34,1.96,.07),dwood,0,0,0);
  ad(mf,new THREE.BoxGeometry(1.42,.06,.1),gold,0,1.0,0);
  ad(mf,new THREE.BoxGeometry(1.42,.06,.1),gold,0,-1.0,0);
  ad(mf,new THREE.PlaneGeometry(1.16,1.76),new THREE.MeshBasicMaterial({map:MIR.t,color:new THREE.Color(1.1,1.1,1.1)}),0,0,.04);
  sign('CORTE DE PELO',2.2,.5,'#fff','#8c1a22',4.86,2.6,MQ.z,-Math.PI/2,.7);
  const pt=tex(96,96,(g,w,h)=>{
    g.fillStyle='#f4f4f4';
    g.fillRect(0,0,w,h);
    [[0,'#c8202a'],[48,'#1b3f9b']].forEach(a=>[-96,0,96].forEach(o=>{
      g.fillStyle=a[1];
      g.beginPath();
      g.moveTo(a[0]+o,0);
      g.lineTo(a[0]+o+24,0);
      g.lineTo(a[0]+o-72,96);
      g.lineTo(a[0]+o-96,96);
      g.closePath();
      g.fill()
    }))
  },1,1,1);
  POLEM=M(0xffffff,.3,.1);
  POLEM.map=pt;
  const pole=ad(S,new THREE.CylinderGeometry(.06,.06,.8,16),POLEM,4.76,1.15,-25.3);
  ad(S,new THREE.SphereGeometry(.075,12,8),M(0xc8202a,.3,.3),4.76,1.58,-25.3);
  ad(S,new THREE.SphereGeometry(.075,12,8),M(0xc8202a,.3,.3),4.76,.72,-25.3);
 /* carrito con herramientas */
  const tr=new THREE.Group();
  tr.position.set(4.2,0,-25.15);
  S.add(tr);
  ad(tr,new THREE.BoxGeometry(.7,.04,.4),wood,0,.82,0);
  ad(tr,new THREE.BoxGeometry(.66,.03,.36),wood,0,.25,0);
  [-1,1].forEach(a=>[-1,1].forEach(b=>ad(tr,new THREE.BoxGeometry(.04,.82,.04),chrome,a*.31,.41,b*.17)));
  ad(tr,new THREE.BoxGeometry(.05,.14,.045),blk,-.2,.91,0,[0,0,.2]);
  ad(tr,new THREE.BoxGeometry(.05,.025,.045),chrome,-.215,.99,0,[0,0,.2]);
  ad(tr,new THREE.BoxGeometry(.14,.008,.03),M(0xf2f2f2,.5),0,.845,.1);
  ad(tr,new THREE.BoxGeometry(.12,.005,.012),chrome,.14,.845,-.06,[0,.4,0]);
  ad(tr,new THREE.BoxGeometry(.12,.005,.012),chrome,.14,.845,-.06,[0,-.4,0]);
  ad(tr,new THREE.CylinderGeometry(.027,.027,.15,12),M(0x7ec8f0,.2,.1),.24,.915,.08);
  ad(tr,new THREE.BoxGeometry(.045,.03,.03),blk,.24,1.0,.08);
  addCol([3.85,4.55,-25.35,-24.95]);
  hc3Init()
}
function decoy(){
  if(st!='play'||dcT>0)return;
  dcT=22;
  decT=10;
  peA=0;
  decN=near(P.x,P.z);
  tone(660,.12,'square',.08);
  setTimeout(()=>tone(990,.2,'square',.08),140);
  toast('Señuelo: Ysea va a ese punto y Peña se rinde')
}
const WP='excelencia educativa';
let wN=0,wD=0;
const nrm=t=>t.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim().replace(/\s+/g,' ');
function wUI(){
  $('wc').textContent='Frase '+Math.min(wD+1,wN)+' de '+wN;
  $('wu').style.width=(wD/wN*100)+'%'
}
function startWrite(){
  if(st!='play')return;
  st='write';
  K={};
  jx=jy=0;
  run=false;
  lT=999;
  lH=0;
  document.exitPointerLock&&document.exitPointerLock();
  wN=4+Math.min(night-1,4);
  wD=0;
  $('qz').style.display='none';
  $('wh').textContent='LAURIMAR TE ATRAPÓ · CASTIGO: escribe la frase '+wN+' veces (¡Ysea sigue caminando!)';
  $('wf').textContent='';
  $('wi').value='';
  wUI();
  $('wr').style.display='flex';
  tone(300,.4,'sawtooth',.15,900);
  say('¡A escribir!',.9);
  setTimeout(()=>{
    try{
      $('wi').focus()
    }catch(e){}
  },60)
}
function wSubmit(){
  if(st!='write')return;
  const v=nrm($('wi').value);
  $('wi').value='';
  if(v==WP){
    wD++;
    tone(660,.1,'triangle',.12);
    $('wf').style.color='#9dffb0';
    $('wf').textContent='¡Bien!';
    if(wD>=wN)return wDone();
    wUI()
  }else{
    wD=Math.max(0,wD-1);
    nzv=.7;
    yT=Math.max(yT,4);
    tone(110,.4,'sawtooth',.18,60);
    $('wf').style.color='#ff9a9a';
    $('wf').textContent='¡Mal escrito! Pierdes una línea. Escribe: EXCELENCIA EDUCATIVA';
    wUI()
  }
  try{
    $('wi').focus()
  }catch(e){}
}
function wDone(){
  $('wr').style.display='none';
  st='play';
  lT=16;
  lH=0;
  const L=BOTS[1],c=G.map((_,i)=>i).filter(i=>Math.hypot(G[i][0]-P.x,G[i][1]-P.z)>14),n=G[c.length?c[(Math.random()*c.length)|0]:8];
  L.x=n[0];
  L.z=n[1];
  L.rt=null;
  L.m.position.set(L.x,0,L.z);
  lock();
  [523,659,784].forEach((f,i)=>setTimeout(()=>tone(f,.2,'triangle',.1),i*110));
  toast('✏ Castigo cumplido. Laurimar se aleja… por ahora.',3200)
}
$('wi').addEventListener('keydown',e=>{
  if(e.key=='Enter'){
    e.preventDefault();
    wSubmit()
  }
});
$('wi').addEventListener('input',()=>tone(900+Math.random()*200,.02,'square',.025));
$('wb').onclick=wSubmit;
function die(b){
  if(st=='dead')return;
  st='dead';
  $('or').style.display='none';
  $('dg').style.display='none';
  mOff();
  $('wr').style.display='none';
  cutT=0;
  cutKind=0;
  hcStop();
  qClr();
  $('cut').style.display='none';
  $('qz').style.display='none';
  document.exitPointerLock&&document.exitPointerLock();
  b.m.visible=true;
  killer=b;
  dieT=0;
  SV.deaths++;
  svSave();
  $('hud').style.display='none';
  b.m.position.set(0,0,-2.5);
  b.m.scale.setScalar(b.s*1.1);
  b.m.lookAt(0,0,3);
  scream();
  tone(50,.8,'sine',.9,22);
  $('fl').style.opacity=.5
}
function win(){
  st='win';
  mOff();
  document.exitPointerLock&&document.exitPointerLock();
  $('hud').style.display='none';
  ovMode(true);$('ovp').textContent='¡NIVEL 1 completado! Escapaste de la UNEFA con los 7 cuadernos. Ahora te espera el NIVEL 2 · TERRENO: el patio y su Sargento.';
  $('go').textContent='Ir al Nivel 2';
  LV=2;
  SV.lv=2;
  SV.night=night;
  SV.best=Math.max(SV.best,night);
  SV.wins++;
  svSave();
  $('stat').innerHTML=statTxt();
  $('stat').style.display='flex';
  $('nw').style.display='none';
  $('ov').style.display='flex';
  [261,329,392,523].forEach((f,i)=>setTimeout(()=>tone(f,.5,'triangle',.15),i*220))
}
$('go').onclick=()=>{
  {
    const r=au().resume();
    r&&r.catch&&r.catch(()=>{})
  }
  startMusic();
  $('ov').style.display='none';
  $('hud').style.display='block';
  BOTS.forEach(b=>b.m.scale.setScalar(b.s));
  ROS.m.scale.setScalar(ROS.s);
  $('fl').style.opacity=0;
  dL.intensity=0;
  cam.fov=cam.aspect<1?100:72;
  cam.updateProjectionMatrix();
  S.fog.density=.014;
  reset();
  aqc=-480;
  $('nt').textContent=night;
  st='play';
  lock();
  startLv()
};
$('dc').onclick=decoy;
$('rc').onclick=doCut;
let pvS='menu';
function showInfo(){
  pvS=st;
  if(st=='play'){
    st='pause';
    mOff();
    document.exitPointerLock&&document.exitPointerLock();
    K={};
    jx=jy=0
  }
  $('inf').style.display='flex'
}
function closeInfo(){
  $('inf').style.display='none';
  if(st=='pause'){
    st='play';
    lock()
  }
}
$('inb').onclick=$('ib').onclick=showInfo;
$('infc').onclick=closeInfo;
$('inf').addEventListener('pointerdown',e=>{
  if(e.target===$('inf'))closeInfo()
});
/* Pausa automática: Esc (se suelta el ratón), cambio de pestaña o tecla P */
document.addEventListener('pointerlockchange',()=>{
  if(!document.pointerLockElement&&st=='play'&&!matchMedia('(pointer:coarse)').matches)showInfo()
});
document.addEventListener('visibilitychange',()=>{
  if(document.hidden&&st=='play')showInfo()
});
addEventListener('keydown',e=>{
  if(e.code=='Escape'){
    if($('cfg').classList.contains('on'))closeCfg();
    else if($('inf').style.display=='flex')closeInfo();
    return
  }
  if(e.code=='KeyP'&&st=='play')showInfo()
});
/* Menú con teclado: flechas arriba/abajo y Enter */
addEventListener('keydown',e=>{
  if(e.code!='ArrowDown'&&e.code!='ArrowUp'&&e.code!='Enter')return;
  const ov=$('ov');
  if(ov.style.display=='none'||$('cfg').classList.contains('on')||$('inf').style.display=='flex')return;
  const bs=[...ov.querySelectorAll('.acts button')].filter(b=>b.offsetParent);
  if(!bs.length)return;
  const i=bs.indexOf(document.activeElement);
  if(e.code=='Enter'){
    if(i<0){
      e.preventDefault();
      $('go').click()
    }
    return
  }
  e.preventDefault();
  bs[(i<0?0:(i+(e.code=='ArrowDown'?1:-1)+bs.length)%bs.length)].focus()
});
$('ov').addEventListener('focusin',e=>{
  if(AC&&AC.state=='running'&&e.target.closest&&e.target.closest('.acts button'))tone(520,.03,'square',.025)
});
$('ia').onclick=()=>{
  if(st=='play')useE()
};
$('c').onclick=()=>{
  if(st=='play')lock()
};
[].forEach(id=>{
  const e=$(id);
  e.onpointerdown=()=>K[id]=1;
  e.onpointerup=e.onpointerleave=e.onpointercancel=()=>K[id]=0
});
addEventListener('keydown',e=>{
  if(st=='write')return;
  if(e.repeat)return;
  if(st=='quiz'){
    qKey(e);
    return
  }
  K[e.code]=1;
  if(e.code=='KeyE'&&st=='play')useE();
  if(/^Digit[123]$/.test(e.code)){
    sel=+e.code[5]-1;
    renderBar()
  }
  if(e.code=='KeyF')useItem(sel);
  if(e.code=='KeyC')doCut();
  if(e.code=='KeyR')decoy();
  if(e.code.startsWith('Arrow'))e.preventDefault()
});
addEventListener('keyup',e=>K[e.code]=0);
addEventListener('mousemove',e=>{
  if(document.pointerLockElement&&st=='play'){
    P.yaw-=e.movementX*.0025*(CFG.sens||1);
    P.pt=Math.max(-1.2,Math.min(1.2,P.pt-e.movementY*.0025*(CFG.sens||1)))
  }
});
let lx=0,ly=0,lid=null;
addEventListener('pointerdown',e=>{
  if(e.pointerType=='touch'&&lid==null&&e.clientX>innerWidth*.4&&!(e.target.closest&&e.target.closest('button,#js'))){
    lid=e.pointerId;
    lx=e.clientX;
    ly=e.clientY
  }
});
addEventListener('pointerup',e=>{
  if(e.pointerId==lid)lid=null
});
addEventListener('pointercancel',e=>{
  if(e.pointerId==lid)lid=null
});
addEventListener('pointermove',e=>{
  if(e.pointerType=='touch'&&st=='play'&&e.pointerId==lid){
    P.yaw-=(e.clientX-lx)/innerWidth*3.5*(CFG.sens||1);
    P.pt=Math.max(-1.2,Math.min(1.2,P.pt-(e.clientY-ly)/innerHeight*2));
    lx=e.clientX;
    ly=e.clientY
  }
});
let jx=0,jy=0,jid=null;
const js=$('js'),jk=$('jk');
function jset(e){
  const r=js.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
  let dx=(e.clientX-cx)/(r.width/2),dy=(e.clientY-cy)/(r.height/2);
  const m=Math.hypot(dx,dy);
  if(m>1){
    dx/=m;
    dy/=m
  }
  jx=Math.abs(dx)<.12?0:dx;
  jy=Math.abs(dy)<.12?0:dy;
  jk.style.transform='translate('+dx*48+'px,'+dy*48+'px)'
}
js.onpointerdown=e=>{
  jid=e.pointerId;
  js.setPointerCapture(e.pointerId);
  jset(e)
};
js.onpointermove=e=>{
  if(e.pointerId==jid)jset(e)
};
js.onpointerup=js.onpointercancel=()=>{
  jid=null;
  jx=jy=0;
  jk.style.transform=''
};
function update(dt){
  const cutting=cutT>0||st=='write'||slp,f=(K.KeyW||K.ArrowUp?1:0)-(K.KeyS||K.ArrowDown?1:0)-jy,s=(K.KeyD?1:0)-(K.KeyA?1:0)+jx;
  if(K.ArrowLeft)P.yaw+=dt*2;
  if(K.ArrowRight)P.yaw-=dt*2;
  const moving=(f||s)&&!cutting;
  run=!!(moving&&(K.ShiftLeft||K.ShiftRight||K.tr||Math.hypot(jx,jy)>.93)&&P.sp>2);
  if(moving){
    const sp=(run?4.9:2.9)*(spdT>0?1.45:1)*dt,l=Math.max(1,Math.hypot(f,s));
    mv((-Math.sin(P.yaw)*f+Math.cos(P.yaw)*s)/l*sp,(-Math.cos(P.yaw)*f-Math.sin(P.yaw)*s)/l*sp)
  }
  P.sp=run?P.sp-dt*22:Math.min(100,P.sp+dt*(moving?6:14));
  {
    const pw=Math.round(P.sp);
    if(pw!==lpw){
      lpw=pw;
      $('pb').style.width=pw+'%';
      $('pb').style.background=pw<25?'#e03a3a':''
    }
  }
  fxTick(dt);
  cutTick(dt);
  if(LV==2)return upd2(dt);
  if(LV==3)return upd3(dt);
  if(LV==4)return upd4(dt);
  if(run)nzv=1;
  nzv=Math.max(0,nzv-dt*.5);
  dcT=Math.max(0,dcT-dt);
  lT=Math.max(0,lT-dt);
  decT-=dt;
  yT-=dt;
  lH-=dt;
  const q=Math.ceil(dcT);
  if(q!==ldq){
    ldq=q;
    $('dc').firstElementChild.textContent=q?'Señuelo · '+q+'s':'Señuelo';
    $('dc').style.opacity=q?.55:''
  }
  NB=null;
  NBS.forEach((m,i)=>{
    if(m.visible){
      m.rotation.y=T*1.5;
      m.position.y=1.05+Math.sin(T*2+i)*.06;
      if(Math.hypot(m.position.x-P.x,m.position.z-P.z)<1.9)NB=m
    }
  });
  iaUI();
  SNS.forEach(m=>{
    if(m.visible){
      m.rotation.y=T*2;
      m.position.y=.9+Math.sin(T*3)*.05;
      if(Math.hypot(m.position.x-P.x,m.position.z-P.z)<1.1){
        m.visible=false;
        P.sp=100;
        tone(880,.1,'triangle',.1);
        toast('🍫 Cocosette: ¡resistencia al máximo!',2500)
      }
    }
  });
  if(nb==7&&P.z>-1.2&&Math.abs(P.x)<3)return win();
 /* pelo / Rosales */
  if(cutT<=0)hair=Math.min(100,hair+dt*100/Math.max(45,75-(night-1)*5));
  if(hair>=70&&!hw){
    hw=true;
    toast('✂ Se te alarga el pelo: busca la barbería',4000);
    tone(880,.12,'square',.06)
  }
  if(hair<70)hw=false;
  if(hair>=100&&!rosOn&&cutT<=0){
    rosOn=true;
    ROS.x=0;
    ROS.z=-23;
    ROS.m.visible=true;
    ROS.m.position.set(0,0,-23);
    toast('⚠ ¡Rosales viene por ese pelo!',3500);
    tone(70,.6,'sawtooth',.2,40)
  }
  hairUI();
  const ps=[P.x,P.z];
  if(rosOn&&cutT<=0&&invT<=0){
    mon(ROS,dt,3+(night-1)*.1,near(P.x,P.z),P.x,P.z);
    if(Math.hypot(ROS.x-P.x,ROS.z-P.z)<1.1){
      startRosCut();
      rosOn=false;
      nzv=1;
      toast('✂ Rosales: «Esos pelos, soldado. Directo al corte.»',3000)
    }
  }
 /* Ysea (Baldi) */
  const Y=BOTS[0],yd=Math.hypot(Y.x-P.x,Y.z-P.z);
  if(nzv>.3&&invT<=0)yT=Math.max(yT,4);
  if(invT>0)yT=Math.min(yT,0);
  const hunt=(decT>0||yT>0)&&nb>=1,ysp=Math.min(4.3,1.6+.3*nb+.18*wr+(night-1)*.15)*(nb>=7?1.25:1)*(hunt?1:.75)*(st=='write'?.85:1)*(nb>=1?1:0);
  mon(Y,dt,ysp,decT>0?decN:yT>0?near(P.x,P.z):roam(Y),decT>0?G[decN][0]:P.x,decT>0?G[decN][1]:P.z);
  if(decT>0&&Math.hypot(Y.x-G[decN][0],Y.z-G[decN][1])<1.2)decT=0;
  ti-=dt;
  if(ti<=0){
    ti=Math.max(.26,Math.min(1.1,yd/15))*(nb>=7?.8:1);
    yk^=1;
    rk=1;
    if(yd<34){
      const pn=Math.max(-1,Math.min(1,((Y.x-P.x)*Math.cos(P.yaw)-(Y.z-P.z)*Math.sin(P.yaw))/10));
      ruler(Math.max(.05,Math.min(.5,.55-yd/42)),pn,yk)
    }
  }
  yst-=dt;
  if(yst<=0){
    yst=.5;
    if(yd<16)tone(70,.09,'sine',Math.max(.03,.3-yd/60),45)
  }
  if(yd<(invT>0?.6:1.1)&&nb>=1)return die(Y);
 /* Laurimar (Playtime): patrulla el edificio; si corres te persigue y te manda a escribir */
  const L=BOTS[1];
  if(run)lH=4;
  const lc=lH>0&&lT<=0&&st=='play'&&invT<=0;
  L.pt=(L.pt||0)-dt;
  if(!lc&&(L.rt==null||near(L.x,L.z)==L.rt||L.pt<=0)){
    let n;
    do{
      n=(Math.random()*G.length)|0
    }while(n==near(L.x,L.z)||Math.hypot(G[n][0]-L.x,G[n][1]-L.z)<8);
    L.rt=n;
    L.pt=14+Math.random()*8
  }
  const lpx=L.x,
    lpz=L.z,
    lsp=lc?3.3+(night-1)*.12:2.1+(night-1)*.08,
    ltn=lc?near(P.x,P.z):L.rt;
  mon(L,dt,lsp,ltn,lc?P.x:G[ltn][0],lc?P.z:G[ltn][1]);
  if(Math.hypot(L.x-lpx,L.z-lpz)<lsp*dt*.2){
    L.sk=(L.sk||0)+dt;
    if(L.sk>1.2){
      L.pt=0;
      L.sk=0;
      L.rt=null
    }
  }else L.sk=0;
  lj-=dt;
  const ld=Math.hypot(L.x-P.x,L.z-P.z);
  if(lj<=0){
    lj=lc?.28:.45;
    if(ld<15)tone(lc?640:480,.05,'triangle',Math.max(.02,.12-ld/150),lc?900:620,Math.max(-1,Math.min(1,(L.x-P.x)/10)))
  }
  if(st=='play'&&lT<=0&&ld<(invT>0?.6:1.1))startWrite();
 /* Peña: solo avanza si no lo miras */
  const Pe=BOTS[2],
    dx=Pe.x-P.x,
    dz=Pe.z-P.z,
    pd=Math.hypot(dx,dz)||1,
    fw=dx*-Math.sin(P.yaw)+dz*-Math.cos(P.yaw),
    rg=dx*Math.cos(P.yaw)+dz*-Math.sin(P.yaw),
    sn=0;
  peA-=dt;
  pc-=dt;
  if(invT>0)peA=0;
  if(peA>0)mon(Pe,dt,2.9+(night-1)*.1+wr*.05,near(P.x,P.z),P.x,P.z);
  Pe.m.visible=peA>0;
  if(peA>0&&pc<=0){
    pc=Math.max(.25,pd/14);
    tone(190,.09,'square',.05,110,Math.max(-1,Math.min(1,rg/8)))
  }
  const pe=$('pe'),ptx=peA>0?(Math.abs(rg)>Math.abs(fw)?(rg>0?'PEÑA ▶':'◀ PEÑA'):(fw>0?'▲ PEÑA':'▼ PEÑA ATRÁS')):'';
  if(ptx!==lpe){
    lpe=ptx;
    if(ptx){
      pe.style.display='block';
      pe.textContent=ptx
    }else pe.style.display='none'
  }
  music(dt,Math.min(yd,ld,peA>0?pd:99,rosOn?Math.hypot(ROS.x-P.x,ROS.z-P.z):99));
  if(peA>0&&pd<1)return die(Pe);
}
const nzc=$('nz').getContext('2d'),nzi=nzc.createImageData(160,90);
function render(dt){
  const nt=T*1000;
  odTick(dt);
  barberTick(dt);
  hc3Tick(dt);
  hcDraw(dt);
  rk=Math.max(0,rk-dt*6);
  RUL.rotation.x=.45-rk*1.15;
  oL.intensity=out?.08:1.4*(Math.sin(T*47)>.97||Math.sin(T*3.1)>.992?.45:1)*(.94+.06*Math.sin(T*9));
  dk.intensity=out?0:.9;
  dlL.intensity=out?0:.55*(Math.sin(T*23)>.97?.5:1);
  amb.intensity=(camUp?.3:.5)*(CFG.bri||1);
  hm.intensity=.62;
  hl.intensity=1.3;
  lightPool(dt);
  hL.intensity+=((lights.L?3:0)-hL.intensity)*.4*(Math.random()<.04?0:1);
  hR.intensity+=((lights.R?3:0)-hR.intensity)*.4*(Math.random()<.04?0:1);
  DRS.forEach(d=>{
    const ty=d.c?1.4:4.4;
    if(Math.abs(ty-d.m.position.y)>.02)R.shadowMap.needsUpdate=true;
    d.m.position.y+=(ty-d.m.position.y)*Math.min(1,dt*8)
  });
  blades.rotation.z+=dt*(out?0:18);
  dust.position.y=Math.sin(T*.3)*.06;
  dust.rotation.y=Math.sin(T*.1)*.08;
  BOTS.forEach((b,i)=>{
    const hh=b.m.userData.head;
    if(hh){
      hh.rotation.y=Math.sin(T*.8+i*2)*(b.loc=='dL'||b.loc=='dR'?.06:.4);
      hh.rotation.x=Math.sin(T*1.7+i)*.06;
      b.m.userData.up.scale.y=1+Math.sin(T*1.6+i)*.012
    }
    if(st=='play'||st=='write'){
      b.m.position.y=i==1?Math.abs(Math.sin(T*5))*.1:Math.sin(T*2+i)*.02;
      b.m.rotation.z=Math.sin(T*1.3+i)*.03
    }
  });
  if(st=='play'&&ROS.m.visible){
    const hh=ROS.m.userData.head;
    hh.rotation.y=Math.sin(T*.7+5)*(ROS.loc=='dL'||ROS.loc=='dR'?.05:.35);
    hh.rotation.x=Math.sin(T*1.5)*.05;
    ROS.m.position.y=Math.sin(T*2+4)*.02;
    ROS.m.rotation.z=Math.sin(T*1.2+2)*.03
  }
  if(st!='dead'){
    const fv=camUp?(cam.aspect<1?85:60):(cam.aspect<1?100:72);
    if(Math.abs(cam.fov-fv)>.01){
      cam.fov=fv;
      cam.updateProjectionMatrix()
    }
  }
  if(st=='dead'){
    dieT+=dt;
    cam.position.set((Math.random()-.5)*.08,1.55+(Math.random()-.5)*.08,.4);
    const p=Math.min(1,dieT/.45),hh=killer.m.userData.head;
    killer.m.position.z=-2.5+1.8*(1-(1-p)*(1-p));
    hh.rotation.z=Math.sin(dieT*30)*.12*(p>=1?1:0);
    hh.rotation.x=.15+Math.sin(dieT*26)*.08;
    hh.rotation.y=Math.sin(dieT*19)*.18;
    killer.m.userData.up.rotation.x=(killer.k==2?.22:0)+.25;
    const hy=2.05*killer.s*(killer.k==2?.93:1);
    cam.position.y=1.55+(hy-.1-1.55)*p+(Math.random()-.5)*.03*p;
    cam.position.x=(Math.random()-.5)*.05;
    cam.lookAt(0,1.55+(hy-1.55)*p,killer.m.position.z);
    cam.fov=62-12*Math.min(1,dieT/2);
    cam.updateProjectionMatrix();
    dL.position.set(0,hy-.2,killer.m.position.z+.7);
    dL.intensity=Math.random()<.5?3:.8;
    cl.position.set(0,hy+.1,killer.m.position.z+.9);
    cl.intensity=((dieT*14)|0)%3?1.6:.3;
    if((fcnt++&1)==0)R.shadowMap.needsUpdate=true;
    killer.m.scale.setScalar(killer.s*(1.05+Math.sin(dieT*24)*.02));
    $('fl').style.opacity=dieT<.6?(((dieT*16)|0)%2?.35:.05):0;
    if(dieT>3.6&&$('ov').style.display!='flex'){
      ovMode(true);$('ovp').innerHTML='<span style="font-size:1.3em;color:#ff8a8a;font-weight:700">'+killer.n+' te atrapó</span><br><br><span style="color:#8fd3ff;font-weight:700">💡 Consejo</span><br>'+deathTip();
      $('stat').innerHTML=statTxt();
      $('stat').style.display='flex';
      $('nw').style.display='none';
      $('go').textContent='Reintentar noche';
      $('ov').style.display='flex'
    }
  }
 else if(camUp){
    const c=CAMS[ci];
    cam.position.set(...c.p);
    cam.lookAt(c.t[0]+Math.sin(T*.4)*1.6,c.t[1],c.t[2]);
    cl.position.set(c.p[0]+(c.t[0]-c.p[0])*.15,c.p[1]-.3,c.p[2]+(c.t[2]-c.p[2])*.15);
    cl.intensity=.55
  }
 else{
    cl.intensity=0;
    const by=1.55+(ANI?(run?Math.sin(T*14)*.03:Math.sin(T*1.1)*.012):0),tg=cutKind==1&&cutT>0?1:0;
    cutCb+=(tg-cutCb)*Math.min(1,dt*(tg?3.5:5));
    if(cutCb<.003)cutCb=0;else if(cutCb>.997)cutCb=1;
    if(cutCb>0){
      const e=cutCb*cutCb*(3-2*cutCb),dy=((CAMYAW-P.yaw+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;
      cam.position.set(P.x+(CAMX-P.x)*e,by+(1.25-by)*e,P.z+(CAMZ-P.z)*e);
      cam.rotation.set(P.pt*(1-e)+.03*e,P.yaw+dy*e,0,'YXZ')
    }
  else{
      cam.position.set(P.x,by,P.z);
      cam.rotation.set(P.pt,P.yaw,0,'YXZ')
    }
    if(cutT>0&&ANI)cam.position.x+=(Math.random()-.5)*(cutKind==1?.006:.02)
  }
  if(glitch>0){
    glitch-=dt;
    cam.position.x+=(Math.random()-.5)*.1;
    $('nz').style.opacity=.15;
    nzO=1
  }else if(nzO){
    nzO=0;
    $('nz').style.opacity=0
  }
  if(glitch>0&&((T*30)|0)%2==0){
    const d=nzi.data;
    for(let i=0;i<d.length;i+=4){
      const v=Math.random()*255;
      d[i]=d[i+1]=d[i+2]=v;
      d[i+3]=255
    }
    nzc.putImageData(nzi,0,0)
  }
  if(POST){
    try{
      composer.passes[1].strength=.11;
      GP.uniforms.t.value=T;
      GP.uniforms.ex.value=EX*1.9*Math.pow(CFG.bri||1,1.4)*(COARSE?.95:1);
      GP.uniforms.cm.value=camUp?1:0;
      GP.uniforms.gl.value=Math.max(0,glitch);
      composer.render(dt)
    }catch(e){
      POST=false;
      R.render(S,cam)
    }
  }else R.render(S,cam);
}
let last=performance.now();
let fa=1/60,fc=0,fmn=.0167,lm=0;
const COARSE=matchMedia('(pointer:coarse)').matches;
function loop(now){
  if(FPSL&&now-lF<1000/FPSL-3){
    requestAnimationFrame(loop);
    return
  }
  /* En menú / pantallas de resultado basta con ~30 fps: el juego queda fluido y el equipo respira */
  if((st=='menu'||st=='win')&&now-lm<14){
    requestAnimationFrame(loop);
    return
  }
  lF=lm=now;
  const raw=(now-last)/1000,dt=Math.min(.05,raw),live=st=='play'||st=='write';
  last=now;
  T+=dt;
  if(st=='menu'){
    P.yaw=Math.sin(T*.15)*.42;
    P.pt=Math.sin(T*.11)*.04;
    P.x=Math.sin(T*.07)*.55;
    P.z=.2-Math.sin(T*.09+1)*.55
  }
  /* La resolución dinámica solo mide fotogramas de juego real (no menú, pausa ni límite de FPS) */
  if(live&&raw>.004){
    fa+=(raw-fa)*.05;
    fmn=Math.min(fmn+.000004,Math.max(raw,.0075))
  }
  const fmx=FPSL?Math.max(fmn,1/FPSL):fmn;
  if(CFG.q==3&&st=='play'&&++aqc>150){
    aqc=0;
    if(fa>Math.max(.0125,fmx*1.6)&&aq>1){
      aq--;
      applyCfg()
    }
  }
  if(live&&++fc>60){
    fc=0;
    if(composer){
      let p=composer._pixelRatio;
      if(fa>fmx*1.25&&p>.75)p=Math.max(.75,p-.12);else if(fa<fmx*1.1&&p<pr0)p=Math.min(pr0,p+.08);
      if(p!==composer._pixelRatio)composer.setPixelRatio(p)
    }else{
      let p=R.getPixelRatio();
      if(fa>fmx*1.25&&p>.75)p=Math.max(.75,p-.125);else if(fa<fmx*1.1&&p<rp0)p=Math.min(rp0,p+.1);
      if(Math.abs(p-R.getPixelRatio())>.01)R.setPixelRatio(p)
    }
  }
  if(live)update(dt);
  if(st!='quiz'&&st!='write'&&st!='pause')render(dt);else{
    hcDraw(dt)
  }
  requestAnimationFrame(loop)
}
function rr(g,x,y,w,h,r){
  g.beginPath();
  g.moveTo(x+r,y);
  g.arcTo(x+w,y,x+w,y+h,r);
  g.arcTo(x+w,y+h,x,y+h,r);
  g.arcTo(x,y+h,x,y,r);
  g.arcTo(x,y,x+w,y,r);
  g.closePath();
  g.fill()
}
function plq(w,h,tw,th,x,y,z,ry,fn,em){
  const t=tex(tw,th,g=>fn(g,tw,th)),m=new THREE.Mesh(new THREE.PlaneGeometry(w,h),new THREE.MeshStandardMaterial({map:t,roughness:.45,metalness:.05,emissive:0xffffff,emissiveMap:t,emissiveIntensity:em}));
  m.position.set(x,y,z);
  m.rotation.y=ry;
  S.add(m);
  return m
}
function goldTxt(g,t,x,y,s,maxW){
  g.textAlign='center';
  g.textBaseline='middle';
  do{
    g.font='900 '+s+'px Georgia,serif';
    s-=3
  }while(g.measureText(t).width>maxW&&s>10);
  g.fillStyle='rgba(0,0,0,.6)';
  g.fillText(t,x+4,y+5);
  const gr=g.createLinearGradient(0,y-s/2,0,y+s/2);
  gr.addColorStop(0,'#fff3b8');
  gr.addColorStop(.5,'#e9b92e');
  gr.addColorStop(1,'#9c6c10');
  g.fillStyle=gr;
  g.fillText(t,x,y)
}
function drawExc(g,W,H){
  const bg=g.createLinearGradient(0,0,0,H);
  bg.addColorStop(0,'#145a35');
  bg.addColorStop(1,'#0a301d');
  g.fillStyle=bg;
  g.fillRect(0,0,W,H);
  g.strokeStyle='#e9b92e';
  g.lineWidth=8;
  g.strokeRect(14,14,W-28,H-28);
  g.lineWidth=2;
  g.strokeRect(30,30,W-60,H-60);
  g.fillStyle='#e9b92e';
  g.font='700 30px Georgia,serif';
  g.textAlign='center';
  g.textBaseline='middle';
  g.fillText('★  U N E F A  ★',W/2,78);
  goldTxt(g,'EXCELENCIA',W/2,205,128,W*.84);
  goldTxt(g,'EDUCATIVA',W/2,335,128,W*.84);
  g.fillStyle='#e9b92e';
  g.fillRect(W*.2,405,W*.6,3);
  g.fillStyle='#f3ecd0';
  g.font='italic 26px Georgia,serif';
  g.textAlign='center';
  g.fillText('Universidad Nacional Experimental Politécnica de la FANB',W/2,440,W*.86);
  const v=g.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,W*.7);
  v.addColorStop(0,'rgba(0,0,0,0)');
  v.addColorStop(1,'rgba(0,0,0,.35)');
  g.fillStyle=v;
  g.fillRect(0,0,W,H)
}
function drawBarber(g,W,H){
  g.fillStyle='#efe6cf';
  g.fillRect(0,0,W,H);
  const band=y=>{
    g.save();
    g.beginPath();
    g.rect(0,y,W,80);
    g.clip();
    for(let i=-120;i<W+120;i+=64){
      g.fillStyle='#c8202a';
      g.beginPath();
      g.moveTo(i,y);
      g.lineTo(i+32,y);
      g.lineTo(i-8,y+80);
      g.lineTo(i-40,y+80);
      g.fill();
      g.fillStyle='#1b3f9b';
      g.beginPath();
      g.moveTo(i+32,y);
      g.lineTo(i+64,y);
      g.lineTo(i+24,y+80);
      g.lineTo(i-8,y+80);
      g.fill()
    }
    g.restore()
  };
  band(0);
  band(H-80);
  g.strokeStyle='#8a7a55';
  g.lineWidth=4;
  g.setLineDash([14,10]);
  g.strokeRect(24,104,W-48,H-208);
  g.setLineDash([]);
  const cx=W/2,cy=370;
  g.fillStyle='#d9a37c';
  g.beginPath();
  g.ellipse(cx-150,cy+10,26,44,0,0,7);
  g.ellipse(cx+150,cy+10,26,44,0,0,7);
  g.fill();
  g.fillStyle='#e8b890';
  g.fillRect(cx-55,cy+150,110,90);
  g.beginPath();
  g.ellipse(cx,cy,142,180,0,0,7);
  g.fill();
  g.strokeStyle='#8a5a3a';
  g.lineWidth=4;
  g.stroke();
  const sh=g.createRadialGradient(cx-40,cy-110,10,cx-40,cy-110,120);
  sh.addColorStop(0,'rgba(255,255,255,.55)');
  sh.addColorStop(1,'rgba(255,255,255,0)');
  g.fillStyle=sh;
  g.beginPath();
  g.ellipse(cx,cy,142,180,0,0,7);
  g.fill();
  g.fillStyle='#3a2a20';
  g.beginPath();
  g.ellipse(cx-50,cy-10,14,8,0,0,7);
  g.ellipse(cx+50,cy-10,14,8,0,0,7);
  g.fill();
  g.lineWidth=7;
  g.strokeStyle='#4a3022';
  g.beginPath();
  g.moveTo(cx-72,cy-38);
  g.lineTo(cx-30,cy-44);
  g.moveTo(cx+30,cy-44);
  g.lineTo(cx+72,cy-38);
  g.stroke();
  g.lineWidth=4;
  g.strokeStyle='#8a5a3a';
  g.beginPath();
  g.moveTo(cx,cy-5);
  g.lineTo(cx-10,cy+50);
  g.lineTo(cx+8,cy+54);
  g.stroke();
  g.beginPath();
  g.arc(cx,cy+75,38,.2*Math.PI,.8*Math.PI);
  g.stroke();
  g.save();
  g.translate(cx+170,cy-190);
  g.rotate(.55);
  g.fillStyle='#2a2d34';
  rr(g,-34,-20,68,150,14);
  g.fillStyle='#8c939e';
  g.fillRect(-34,-40,68,26);
  g.fillStyle='#d8dde4';
  for(let k=-30;k<34;k+=9)g.fillRect(k,-62,5,26);
  g.fillStyle='#c8202a';
  g.beginPath();
  g.arc(0,70,9,0,7);
  g.fill();
  g.restore();
  g.fillStyle='#3a2a20';
  [[-210,230],[-170,300],[200,330],[-230,380],[180,250],[230,420]].forEach(p=>{
    g.beginPath();
    g.ellipse(cx+p[0]*.9,p[1]+60,14,5,p[0]/200,0,7);
    g.fill()
  });
  g.textAlign='center';
  g.textBaseline='middle';
  g.fillStyle='#c8202a';
  g.font='900 62px Arial Black,Impact,Arial,sans-serif';
  g.fillText('CORTE DE PELO',cx,690,W-70);
  g.font='900 168px Arial Black,Impact,Arial,sans-serif';
  g.fillStyle='rgba(0,0,0,.25)';
  g.fillText('PELÓN',cx+5,813,W-70);
  g.fillStyle='#1b3f9b';
  g.fillText('PELÓN',cx,808,W-70);
  g.fillStyle='#4b4332';
  g.font='600 32px Arial,sans-serif';
  g.fillText('Presentación y disciplina · FANB',cx,905,W-80)
}
function drawEnroll(g,W,H){
  g.fillStyle='#eaf0f8';
  g.fillRect(0,0,W,H);
  g.fillStyle='#262a33';
  g.fillRect(0,0,W,44);
  ['#ff5f57','#febc2e','#28c840'].forEach((c,i)=>{
    g.fillStyle=c;
    g.beginPath();
    g.arc(24+i*24,22,7,0,7);
    g.fill()
  });
  g.fillStyle='#3c424e';
  rr(g,108,8,W-230,28,14);
  g.fillStyle='#bfe8cc';
  g.font='15px Arial,sans-serif';
  g.textAlign='left';
  g.textBaseline='middle';
  g.fillText('https://inscripcion.unefa.edu.ve',130,23);
  g.fillStyle='#0d3b8f';
  g.fillRect(0,44,W,76);
  g.fillStyle='#f2c230';
  g.beginPath();
  g.arc(58,82,27,0,7);
  g.fill();
  g.fillStyle='#0d3b8f';
  g.font='bold 15px Arial,sans-serif';
  g.textAlign='center';
  g.fillText('UNEFA',58,83);
  g.textAlign='left';
  g.fillStyle='#fff';
  g.font='bold 25px Arial,sans-serif';
  g.fillText('Sistema de Inscripción en Línea',104,72);
  g.fillStyle='#bcd2ff';
  g.font='14px Arial,sans-serif';
  g.fillText('Universidad Nacional Experimental Politécnica de la FANB',104,98);
  g.textAlign='right';
  g.fillStyle='#dbe6ff';
  g.font='15px Arial,sans-serif';
  g.fillText('Inicio     Carreras     Requisitos     Contacto',W-28,82);
  g.fillStyle='#f2c230';
  g.fillRect(0,120,W,6);
  g.textAlign='left';
  g.fillStyle='#0d3b8f';
  g.font='bold 27px Arial,sans-serif';
  g.fillText('Inscripciones abiertas · Período 2026-II',30,158);
  g.fillStyle='#fff';
  rr(g,30,184,230,326,10);
  g.fillStyle='#0d3b8f';
  g.font='bold 16px Arial,sans-serif';
  g.fillText('PASOS',52,212);
  ['Datos personales','Documentos','Selección de carrera','Confirmación'].forEach((s,i)=>{
    const y=252+i*62;
    g.fillStyle=i?'#c9d3e6':'#0d3b8f';
    g.beginPath();
    g.arc(66,y,17,0,7);
    g.fill();
    g.fillStyle=i?'#5a6a88':'#fff';
    g.font='bold 16px Arial,sans-serif';
    g.textAlign='center';
    g.fillText(String(i+1),66,y+1);
    g.textAlign='left';
    g.fillStyle=i?'#5a6a88':'#0d3b8f';
    g.font=(i?'':'bold ')+'16px Arial,sans-serif';
    g.fillText(s,92,y+1)
  });
  g.fillStyle='#fff';
  rr(g,284,184,710,326,10);
  g.fillStyle='#0d3b8f';
  g.font='bold 22px Arial,sans-serif';
  g.textAlign='left';
  g.fillText('Paso 1 de 4 · Datos personales',310,214);
  g.fillStyle='#dfe6f3';
  rr(g,310,230,658,8,4);
  g.fillStyle='#f2c230';
  rr(g,310,230,165,8,4);
  [['Cédula de identidad','V-00.000.000',0,0],['Fecha de nacimiento','DD / MM / AAAA',1,0],['Nombres y apellidos','Escribe tu nombre completo',0,1],['Correo electrónico','correo@ejemplo.com',1,1],['Carrera','Ingeniería de Sistemas  ▾',0,2],['Turno','Diurno  ▾',1,2]].forEach(f=>{
    const x=310+f[2]*340,y=262+f[3]*70;
    g.textAlign='left';
    g.fillStyle='#4a5670';
    g.font='bold 13px Arial,sans-serif';
    g.fillText(f[0],x,y);
    g.fillStyle='#f4f7fc';
    rr(g,x,y+10,318,36,6);
    g.strokeStyle='#b7c4de';
    g.lineWidth=1.5;
    g.strokeRect(x,y+10,318,36);
    g.fillStyle=f[3]==2?'#1e2a44':'#97a3bb';
    g.font='15px Arial,sans-serif';
    g.fillText(f[1],x+12,y+29)
  });
  g.fillStyle='#0d3b8f';
  rr(g,310,464,230,38,8);
  g.fillStyle='#fff';
  g.font='bold 16px Arial,sans-serif';
  g.textAlign='center';
  g.fillText('INSCRIBIRME  →',425,484);
  g.textAlign='left';
  g.fillStyle='#6b7a96';
  g.font='13px Arial,sans-serif';
  g.fillText('Ten a la mano: cédula, título de bachiller y notas certificadas',558,484);
  g.fillStyle='#0d3b8f';
  g.fillRect(0,540,W,66);
  g.fillStyle='#f2c230';
  g.textAlign='center';
  g.font='bold 20px Arial,sans-serif';
  g.fillText('EXCELENCIA EDUCATIVA',W/2,563);
  g.fillStyle='#bcd2ff';
  g.font='13px Arial,sans-serif';
  g.fillText('© UNEFA · Todos los derechos reservados',W/2,587);
  for(let y=0;y<H;y+=3){
    g.fillStyle='rgba(0,0,0,.07)';
    g.fillRect(0,y,W,1)
  }
}
function statTxt(){
  return '<div><b>'+SV.night+'</b><small>NOCHE ACTUAL</small></div><div><b>'+SV.best+'</b><small>MEJOR NOCHE</small></div><div><b>'+SV.wins+'</b><small>ESCAPES</small></div><div><b>'+SV.deaths+'</b><small>DERROTAS</small></div><i>'+(svOK?'Tu progreso se guarda automáticamente en este dispositivo.':'Tu navegador no permite guardar el progreso.')+'</i>'
}
const DT=[['Ysea lo oye todo: no corras y no falles en los cuadernos. El señuelo (R) lo desvía unos segundos.','Cada cuaderno acelera a Ysea. Recoge los cercanos primero y planea tu ruta hacia la oficina.'],['Laurimar patrulla siempre y se lanza si corres: camina cuando la oigas cerca. Si te atrapa, escribe la frase sin errores.','Escucha la regla de Ysea: cuanto más rápido hace tic-tac, más cerca está. Los Cocosette te devuelven la resistencia.'],['Peña ataca cuando fallas una operación: tómate tu tiempo y usa el señuelo (R) si viene por ti.'],['Rosales castiga el pelo largo: pulsa Recorte (C) antes de que la barra se llene.']];
function deathTip(){
  const a=DT[killer.k==3?3:killer.k];
  return a[SV.deaths%a.length]
}
const SK='basics-unefa-v1',SD={night:1,best:1,wins:0,deaths:0,ex:.8,lv:1,inv:[]};
let SV=Object.assign({},SD),svOK=true,nwArm=false;
function svLoad(){
  try{
    const o=JSON.parse(localStorage.getItem(SK)||'null');
    if(o&&o.v==1){
      SV=Object.assign({},SD,o);
      SV.night=Math.max(1,Math.min(99,SV.night|0||1));
      SV.best=Math.max(SV.best|0,SV.night)
    }
  }catch(e){
    svOK=false
  }
}
function svSave(){
  try{
    SV.v=1;
    localStorage.setItem(SK,JSON.stringify(SV))
  }catch(e){
    svOK=false
  }
}
function ovMode(res){
  $('ov').classList.toggle('res',!!res)
}
function menuInfo(){
  const has=!!(SV.wins||SV.deaths||SV.night>1);
  night=SV.night;
  $('go').textContent=has?'Continuar · Nivel '+LV:'Iniciar partida';
  $('nw').style.display=has?'':'none';
  $('nw').textContent='Nueva partida';
  nwArm=false;
  $('stat').innerHTML=statTxt();
  $('stat').style.display=has?'flex':'none';
  ovMode(false);
  try{$('go').focus({preventScroll:true})}catch(e){}
  const nv=NIVELES[Math.max(0,Math.min(NIVELES.length-1,LV-1))];
  $('ovl').textContent='NIVEL '+LV+' · '+nv.nombre+' · NOCHE '+night
}
$('nw').onclick=()=>{
  if(!nwArm){
    nwArm=true;
    $('nw').textContent='¿Borrar progreso? Toca otra vez';
    setTimeout(()=>{
      if(nwArm){
        nwArm=false;
        $('nw').textContent='Nueva partida'
      }
    },4000);
    return
  }
  SV=Object.assign({},SD);
  inv.fill(null);
  svSave();
  menuInfo();
  $('go').click()
};
svLoad();
/* ===== NUEVO: niveles, ítems, Terreno (patio), ajustes ===== */
/* Estructura de niveles: añadir uno nuevo = añadir un objeto aquí + su escenario en startLv() */
const NIVELES=[{nombre:'ESCUELA',escenario:'escuela',actividad:'cuadernos',meta:7},{nombre:'TERRENO',escenario:'patio',actividad:'ordenes',meta:6},{nombre:'SPEED RUN',escenario:'escuela',actividad:'refresco',meta:1},{nombre:'AULA',escenario:'aula',actividad:'sigilo',meta:1}];
let LV=1,
  spdT=0,
  invT=0,
  caps=0,
  hMax=3,
  col2=0,
  ord=null,
  og=5,
  sgT=0,
  tpl=0,
  sel=0,
  popI=-1,
  lbr="",
  IT=null,
  INT=[],
  lfx='',
  lht='',
  lal='',
  lob=-1,
  dgT=0,
  SND=true,
  ANI=true,
  FPSL=0,
  lF=0,
  SUN,
  HEM,
  SODA,
  SLM,
  tL=0,
  zs=0,
  zp=0,
  slp=false,
  ph=0,
  phT=6,
  lob2='',
  lz1=-1,
  lz2=-1;
const inv=[null,null,null],
  X0=300,
  NB2=[],
  INT1=[],
  INT2=[],
  C2=[],
  SARG={n:'El Sargento',k:3,s:1.12,x:X0,z:-6,rt:null,m:null};

/* Iconos vectoriales de los ítems (se dibujan igual en cualquier dispositivo) */
const ICON={
 rev:'<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="9" y="4" width="30" height="40" rx="3" fill="#e5483f"/><rect x="9" y="4" width="6" height="40" rx="3" fill="#b32c26"/><rect x="19" y="9" width="16" height="5" rx="1.2" fill="#fff"/><rect x="19" y="16" width="10" height="2.4" rx="1.2" fill="#ffd1cc"/><path d="M29 20 19.5 31.5h6.4L22.6 42 34 28.6h-6.6z" fill="#ffd84a" stroke="#7a5200" stroke-width="1.3" stroke-linejoin="round"/></svg>',
 pas:'<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M14 1.5 24 14 34 1.5" fill="none" stroke="#e0609f" stroke-width="3" stroke-linejoin="round"/><rect x="8.5" y="12" width="31" height="34" rx="5" fill="#fff6e8" stroke="#d65f98" stroke-width="2"/><rect x="20" y="14.4" width="8" height="2.6" rx="1.3" fill="#d65f98"/><circle cx="24" cy="29" r="8" fill="#f3c7a6"/><path d="M15.6 28.6c0-6 4-9.6 8.4-9.6s8.4 3.6 8.4 9.6c-2.4-3.2-5.2-4.4-8.4-4.4s-6 1.2-8.4 4.4z" fill="#ececf6" stroke="#b9b9cc" stroke-width=".8"/><circle cx="24" cy="18.6" r="3.4" fill="#ececf6" stroke="#b9b9cc" stroke-width=".8"/><circle cx="20.8" cy="29.6" r="2.7" fill="none" stroke="#6b4f76" stroke-width="1.2"/><circle cx="27.2" cy="29.6" r="2.7" fill="none" stroke="#6b4f76" stroke-width="1.2"/><path d="M23.4 29.5h1.2" stroke="#6b4f76" stroke-width="1.1"/><path d="M21.3 33.8q2.7 2.3 5.4 0" fill="none" stroke="#b5524f" stroke-width="1.3" stroke-linecap="round"/><circle cx="18.9" cy="32.6" r="1.6" fill="#f08a9a" opacity=".75"/><circle cx="29.1" cy="32.6" r="1.6" fill="#f08a9a" opacity=".75"/><rect x="14" y="40.6" width="20" height="2.6" rx="1.3" fill="#d65f98"/></svg>',
 per:'<svg viewBox="0 0 48 48" aria-hidden="true"><g transform="rotate(-28 24 24)"><rect x="2" y="17" width="44" height="15" rx="7.5" fill="#e9b45f" stroke="#b9822f" stroke-width="1.2"/><rect x="5" y="14.5" width="38" height="10.5" rx="5.2" fill="#c4372b" stroke="#8a2118" stroke-width="1.2"/><path d="M8 20l3-3 3 3 3-3 3 3 3-3 3 3 3-3 3 3 3-3 3 3 3-3" fill="none" stroke="#ffd93a" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/><rect x="2" y="22.5" width="44" height="10" rx="5" fill="#f0c374" stroke="#b9822f" stroke-width="1.2"/></g></svg>'};
/* Ítems: icono, nombre, descripción y efecto */
const ITEMS={rev:{n:'Revista Sojo',s:'Revista',d:'Velocidad extra durante 25 s',ic:ICON.rev,use(){
  spdT=25;
  fxText('⚡ ¡Velocidad!');
  tone(700,.2,'triangle',.12,1100)
}},
 pas:{n:'Credencial Odalys',s:'Credencial',d:'Te vuelves un profesor casi invisible durante 15 s',ic:ICON.pas,use(){
  invT=15;
  fxText('🎓 Profesor invisible');
  tone(400,.3,'sine',.1,200)
}},
 per:{n:'Perro Tripas',s:'Perro',d:'Cura una captura o devuelve la energía',ic:ICON.per,use(){
  if(caps>0){
    caps--;
    htUI();
    fxText('❤ curado')
  }else{
    P.sp=100;
    fxText('🌭 +energía')
  }
  tone(520,.15,'triangle',.1)
}}};
try{
  (SV.inv||[]).forEach((id,i)=>{
    if(i<3&&ITEMS[id])inv[i]=id
  })
}catch(e){}
function svSaveInv(){
  SV.inv=inv.slice();
  svSave()
}
/* Efectos visuales ligeros (CSS): texto flotante + destello, sacudida y flash rojo */
function fxText(t){
  if(!ANI){
    toast(t,1200);
    return
  }
  const d=document.createElement('div');
  d.className='ft';
  d.textContent=t;
  $('hud').appendChild(d);
  setTimeout(()=>d.remove(),1300);
  const g=$('gl');
  g.classList.remove('on');
  void g.offsetWidth;
  g.classList.add('on')
}
function shake(){
  if(!ANI)return;
  const a=$('app');
  a.classList.remove('shk');
  void a.offsetWidth;
  a.classList.add('shk')
}
function flashRed(){
  $('fl').style.opacity=.55;
  setTimeout(()=>{
    if(st!='dead')$('fl').style.opacity=0
  },220)
}
function dlg(n,t,ms){
  $('dgn').textContent=n;
  $('dgt').textContent=t;
  $('dg').style.display='block';
  dgT=(ms||4500)/1000
}
/* Barra de 3 espacios: agregar, seleccionar y usar */
function addItem(id){
  const i=inv.indexOf(null);
  if(i<0){
    toast('Barra de ítems llena: usa uno (tecla F, o tócalo dos veces)',2400);
    return false
  }
  inv[i]=id;
  sel=i;
  popI=i;
  renderBar();
  svSaveInv();
  fxText('+ '+ITEMS[id].n);
  tone(880,.12,'triangle',.1);
  return true
}
function useItem(i){
  const id=inv[i];
  if(!id||st!='play')return;
  inv[i]=null;
  popI=-1;
  ITEMS[id].use();
  renderBar();
  svSaveInv()
}
function selItem(i){
  if(st!='play')return;
  if(sel==i&&inv[i])useItem(i);else{
    sel=i;
    renderBar()
  }
}
function renderBar(){
  const h=inv.map((id,i)=>{
    const it=id&&ITEMS[id];
    return '<button class="sl'+(i==sel?' on':'')+(it?' has':'')+(i==popI?' pop':'')+'" data-i="'+i+'" data-n="'+(it?it.s:'')+'" aria-label="Ranura '+(i+1)+': '+(it?it.n+'. '+it.d:'vacía')+'" title="'+(it?it.n+' — '+it.d:'Ranura vacía')+'"><kbd>'+(i+1)+'</kbd>'+(it?'<i>'+it.ic+'</i><small>'+it.s+'</small>':'<i class="em"></i><small>vacío</small>')+'</button>'
  }).join('');
  popI=-1;
  if(h!==lbr){
    lbr=h;
    $('bar').innerHTML=h
  }
}
$('bar').onclick=e=>{
  const b=e.target.closest('.sl');
  if(b)selItem(+b.dataset.i)
};
/* Interacción con NPC / puestos */
function iaUI(){
  const t=NB?'Abrir cuaderno':IT?IT.lab:'';
  if(t!==lal){
    lal=t;
    $('ia').style.display=t?'flex':'none';
    if(t)$('ia').firstElementChild.textContent=t
  }
}
function useE(){
  if(NB)return openQ(NB);
  if(IT){
    const o=IT;
    o.cd=o.cool||25;
    if(o.act()===false)o.cd=0
  }
}
/* ===== NPC itinerantes: Sojo y la Profe Odalys cambian de sitio ===== */
const MOV=[];
let MSP1=null;
/* Puntos válidos del edificio (nivel 1/3/4): alrededor de los nodos del mapa, sin muros ni muebles */
function npcSpots1(){
  if(MSP1)return MSP1;
  MSP1=[];
  const skip=new Set([0,1,2,11,12,3,5,7,13,19,25,27,36,38,10,20]),
    off=[[0,0],[1.4,0],[-1.4,0],[0,1.4],[0,-1.4],[1.2,1.2],[-1.2,-1.2],[1.2,-1.2],[-1.2,1.2]],
    keepCG=CGc;
  CGc=CG;
  G.forEach((n,i)=>{
    if(skip.has(i))return;
    off.forEach(o=>{
      const x=n[0]+o[0],z=n[1]+o[1];
      if(x<-27.5||x>27.5||z<-27.5||z>2.2)return;
      if(npcFree(x,z,.7)&&los(n[0],n[1],x,z))MSP1.push([x,z])
    })
  });
  CGc=keepCG;
  return MSP1
}
function npcFree(x,z,r){
  const a=cellC(x,z);
  if(a)for(const c of a)if(x>c[0]-r&&x<c[1]+r&&z>c[2]-r&&z<c[3]+r)return false;
  return true
}
/* Elige un sitio nuevo: lejos del jugador, de Ysea y del otro NPC */
function npcPick(m,px,pz){
  let list;
  if(m.lv==2){
    const keepCG=CGc;
    CGc=CG2;
    list=[];
    for(let i=0;i<60&&list.length<24;i++){
      const x=X0+(Math.random()*2-1)*26,z=(Math.random()*2-1)*21;
      if(npcFree(x,z,1.1))list.push([x,z])
    }
    CGc=keepCG
  }else list=npcSpots1();
  const fixed=m.lv==2?[[X0-4,14],[X0-18,-9.4],[X0+18,-9.4],[X0,-22]]:[[2.8,-24]],
    others=MOV.filter(o=>o!==m&&o.lv==m.lv),
    ok=list.filter(p=>
      Math.hypot(p[0]-px,p[1]-pz)>(m.lv==2?14:12)&&
      Math.hypot(p[0]-m.o.x,p[1]-m.o.z)>8&&
      others.every(o=>Math.hypot(p[0]-o.o.x,p[1]-o.o.z)>9)&&
      fixed.every(f=>Math.hypot(p[0]-f[0],p[1]-f[1])>4)&&
      (m.lv==2?true:BOTS.every(b=>Math.hypot(p[0]-b.x,p[1]-b.z)>6)));
  const pool=ok.length?ok:list.filter(p=>Math.hypot(p[0]-px,p[1]-pz)>6);
  return pool.length?pool[(Math.random()*pool.length)|0]:null
}
function npcPlace(m,s){
  if(!m.g||!s)return;
  m.g.position.x=s[0];
  m.g.position.z=s[1];
  m.o.x=s[0];
  m.o.z=s[1]
}
/* Al empezar un nivel: todos aparecen en un sitio distinto cada partida */
function npcShuffle(lv){
  const px=lv==2?X0:0,pz=lv==2?22:.6;
  MOV.forEach(m=>{
    if(m.lv!=lv)return;
    m.pend=0;
    m.ph=0;
    if(m.g){
      m.g.scale.setScalar(m.sc);
      npcPlace(m,npcPick(m,px,pz))
    }
  })
}
/* Tras entregar el ítem: espera a que termine el diálogo, se esfuma y reaparece en otra zona */
function npcLeave(i,delay){
  const m=MOV[i];
  if(!m||!m.g)return;
  m.pend=delay;
  m.ph=0
}
function npcTick(dt){
  for(const m of MOV){
    if(!m.g)continue;
    if(m.pend>0){
      m.pend-=dt;
      if(m.pend<=0){
        m.pend=0;
        m.ph=1;
        m.k=0
      }
    }
    if(m.ph==1){
      m.k+=dt/.35;
      m.g.scale.setScalar(Math.max(.001,m.sc*(1-Math.min(1,m.k))));
      if(m.k>=1){
        const s=npcPick(m,P.x,P.z);
        if(s)npcPlace(m,s);
        m.ph=2;
        m.k=0;
        if(s)toast('📍 '+m.nm+' se fue a otra zona '+(m.lv==2?'del patio':'del edificio'),2600)
      }
    }else if(m.ph==2){
      m.k+=dt/.45;
      m.g.scale.setScalar(Math.max(.001,m.sc*Math.min(1,m.k)));
      if(m.k>=1){
        m.ph=0;
        m.g.scale.setScalar(m.sc)
      }
    }
    m.o.mv=m.ph>0||m.pend>0
  }
}
/* Efectos activos (velocidad, invisibilidad), diálogo y búsqueda de NPC cercano */
function fxTick(dt){
  npcTick(dt);
  spdT=Math.max(0,spdT-dt);
  invT=Math.max(0,invT-dt);
  IT=null;
  for(const o of INT){
    o.cd-=dt;
    if(!IT&&o.cd<=0&&!o.mv&&Math.hypot(o.x-P.x,o.z-P.z)<2.2)IT=o
  }
  const t=(spdT>0?'⚡ Velocidad '+Math.ceil(spdT)+'s  ':'')+(invT>0?'🎓 Profesor invisible '+Math.ceil(invT)+'s':'');
  if(t!==lfx){
    lfx=t;
    $('fx').textContent=t;
    $('app').classList.toggle('ghost',invT>0)
  }
  if(dgT>0&&(dgT-=dt)<=0)$('dg').style.display='none'
}
function htUI(){
  let h='';
  for(let i=0;i<hMax;i++)h+='<b class="'+(i<hMax-caps?'':'x')+'">❤</b>';
  if(h!==lht){
    lht=h;
    $('ht').innerHTML=h
  }
}
/* Sprite con nombre y NPC sencillo (pocas mallas) */
function lbl(t,w){
  w=w||1.8;
  const c=document.createElement('canvas');
  c.width=256;
  c.height=64;
  const g=c.getContext('2d');
  g.fillStyle='rgba(0,0,0,.55)';
  g.fillRect(0,0,256,64);
  g.fillStyle='#fff';
  g.font='bold 26px system-ui';
  g.textAlign='center';
  g.textBaseline='middle';
  g.fillText(t,128,34,244);
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),transparent:true,fog:false}));
  s.scale.set(w,w/4,1);
  return s
}
function npc(col,name,x,z,hat){
  const g=new THREE.Group(),
    M=c=>new THREE.MeshStandardMaterial({color:c,roughness:.8}),
    b=new THREE.Mesh(new THREE.CylinderGeometry(.2,.27,.95,10),M(col)),
    h=new THREE.Mesh(new THREE.SphereGeometry(.19,12,10),M(0xd9a47c));
  b.position.y=.5;
  h.position.y=1.25;
  g.add(b,h);
  if(hat){
    const c=new THREE.Mesh(new THREE.CylinderGeometry(.2,.2,.1,10),M(hat));
    c.position.y=1.43;
    g.add(c)
  }
  const s=lbl(name);
  s.position.y=1.8;
  g.add(s);
  g.position.set(x,0,z);
  S.add(g);
  return g
}
function inst(geo,mat,arr,fn){
  const m=new THREE.InstancedMesh(geo,mat,arr.length),o=new THREE.Object3D();
  arr.forEach((a,i)=>{
    o.rotation.set(0,0,0);
    o.scale.set(1,1,1);
    fn(o,a);
    o.updateMatrix();
    m.setMatrixAt(i,o.matrix)
  });
  m.frustumCulled=false;
  m.matrixAutoUpdate=false;
  S.add(m);
  return m
}
function mkGrid(list){
  const g=new Map();
  list.forEach(c=>{
    for(let i=Math.floor((c[0]-CM)/CS);i<=Math.floor((c[1]+CM)/CS);i++)for(let j=Math.floor((c[2]-CM)/CS);j<=Math.floor((c[3]+CM)/CS);j++){
      const k=i*1000+j;
      let a=g.get(k);
      if(!a)g.set(k,a=[]);
      a.push(c)
    }
  });
  return g
}
let CG2=null;
/* Construye NPC del nivel 1 y el patio completo del nivel 2 (instancias = pocas llamadas de dibujo) */
function buildExtra(){
 /* NPC del Nivel 1: Sojo y Odalys entregan ítems */
  const sj1=npc(0x2a8c5a,'Sojo',-17.5,-9,0x222222);
  let od1=null;
  safeBuild(()=>{od1=mkOdalys(17.5,-20)});
  safeBuild(buildBarber);
  INT1.push({x:-17.5,z:-9,lab:'Sojo · revista',cd:0,act(){
    if(!addItem('rev'))return false;
    dlg('Sojo','Toma esta revista: te da velocidad 25 s. Úsala con F.');
    npcLeave(0,4.8)
  }},
  {x:17.5,z:-20,lab:'Profe Odalys · credencial',cd:0,act(){
    if(!addItem('pas'))return false;
    dlg('Profe Odalys','¡Ay, mi cielo! Toma mi credencial de profesora: por 15 segundos nadie se fijará en ti. Úsala con F… ¡y no se lo cuentes a nadie! 💕',6500);
    say('Ay mi cielo, toma mi credencial',1.6);
    npcLeave(1,6.8)
  }});
  MOV.push({g:sj1,o:INT1[0],lv:1,nm:'Sojo',sc:1},{g:od1,o:INT1[1],lv:1,nm:'La Profe Odalys',sc:.92});
 /* Luces del patio (apagadas hasta entrar al nivel 2) */
  SUN=new THREE.DirectionalLight(0xfff1d6,1.1);
  SUN.position.set(X0+20,30,10);
  SUN.target.position.set(X0,0,0);
  S.add(SUN,SUN.target);
  HEM=new THREE.HemisphereLight(0xcfe4ff,0x6b6a5a,.55);
  S.add(HEM);
  SUN.visible=HEM.visible=false;
  const M=(c,r)=>new THREE.MeshStandardMaterial({color:c,roughness:r||.9,flatShading:true}),W=(x,y,z,a,b,c,m,rx)=>{
    const o=new THREE.Mesh(new THREE.BoxGeometry(a,b,c),m);
    o.position.set(X0+x,y,z);
    S.add(o);
    return o
  };
 /* Suelo de cemento + cancha con líneas */
  const gt=tex(256,256,(g,w,h)=>{
    g.fillStyle='#868780';
    g.fillRect(0,0,w,h);
    for(let i=0;i<700;i++){
      g.fillStyle='rgba('+(i%2?'0,0,0':'255,255,255')+','+Math.random()*.07+')';
      g.fillRect(Math.random()*w,Math.random()*h,3,3)
    }
    g.strokeStyle='rgba(0,0,0,.22)';
    g.strokeRect(0,0,w,h)
  },12,10);
  const gr=new THREE.Mesh(new THREE.PlaneGeometry(60,50),new THREE.MeshStandardMaterial({map:gt,roughness:.95}));
  gr.rotation.x=-Math.PI/2;
  gr.position.x=X0;
  S.add(gr);
  const ct=tex(512,300,(g,w,h)=>{
    g.fillStyle='#3f6f8f';
    g.fillRect(0,0,w,h);
    g.strokeStyle='#e8eef5';
    g.lineWidth=5;
    g.strokeRect(14,14,w-28,h-28);
    g.beginPath();
    g.moveTo(w/2,14);
    g.lineTo(w/2,h-14);
    g.stroke();
    g.beginPath();
    g.arc(w/2,h/2,46,0,7);
    g.stroke();
    g.strokeRect(14,h/2-50,82,100);
    g.strokeRect(w-96,h/2-50,82,100)
  });
  const cp=new THREE.Mesh(new THREE.PlaneGeometry(24,14),new THREE.MeshStandardMaterial({map:ct,roughness:.8}));
  cp.rotation.x=-Math.PI/2;
  cp.position.set(X0+8,.02,6);
  S.add(cp);
  [[-4,6],[20,6]].forEach(p=>{
    W(p[0]+0,1.6,p[1],.12,3.2,.12,M(0x444a52));
    W(p[0]+(p[0]<8?.5:-.5),3,p[1],.08,.9,1.4,M(0xdddddd))
  });
 /* Cerca perimetral: postes instanciados + paños translúcidos; portón norte (salida) */
  const post=[];
  for(let x=-30;x<=30;x+=3)[-25,25].forEach(z=>{
    if(!(z==-25&&Math.abs(x)<4))post.push([x,z])
  });
  for(let z=-22;z<=22;z+=3)[-30,30].forEach(x=>post.push([x,z]));
  inst(new THREE.BoxGeometry(.12,1.9,.12),M(0x55606c),post,(o,a)=>o.position.set(X0+a[0],.95,a[1]));
  const fm=new THREE.MeshStandardMaterial({color:0x9aa0a8,transparent:true,opacity:.35,roughness:.6});
  W(0,.95,25,60,1.8,.04,fm);
  W(-30,.95,0,.04,1.8,50,fm).rotation.y=0;
  W(30,.95,0,.04,1.8,50,fm);
  W(-17,.95,-25,26,1.8,.04,fm);
  W(17,.95,-25,26,1.8,.04,fm);
  W(-3.5,1.4,-25,.3,2.8,.3,M(0xd9b320));
  W(3.5,1.4,-25,.3,2.8,.3,M(0xd9b320));
  W(0,2.9,-25,7.4,.3,.3,M(0xd9b320));
  const sg=lbl('SALIDA ▲',2.6);
  sg.position.set(X0,3.5,-25);
  S.add(sg);
 /* Árboles (instancias) y bancos con colisión */
  const TR=[[-26,-20],[-26,-8],[-26,4],[-26,16],[26,-20],[26,-8],[26,4],[26,16],[-10,-18],[12,-18],[-4,21],[8,22]];
  inst(new THREE.CylinderGeometry(.18,.25,2.2,6),M(0x6b4a2b),TR,(o,a)=>o.position.set(X0+a[0],1.1,a[1]));
  inst(new THREE.IcosahedronGeometry(1.5,0),M(0x3f7a3c),TR,(o,a)=>{
    o.position.set(X0+a[0],3.2,a[1]);
    o.scale.set(1,1.1,1)
  });
  TR.forEach(a=>C2.push([X0+a[0]-.4,X0+a[0]+.4,a[1]-.4,a[1]+.4]));
  const BN=[[-14,2],[-14,10],[14,16],[-5,-6],[6,-6],[-14,-6]];
  inst(new THREE.BoxGeometry(1.6,.1,.45),M(0x8a5a2e),BN,(o,a)=>o.position.set(X0+a[0],.45,a[1]));
  inst(new THREE.BoxGeometry(1.6,.45,.06),M(0x8a5a2e),BN,(o,a)=>o.position.set(X0+a[0],.75,a[1]-.2));
  BN.forEach(a=>C2.push([X0+a[0]-.8,X0+a[0]+.8,a[1]-.3,a[1]+.3]));
 /* Puestos: perros del Tripas y puesto de Velasco */
  [[-18,0xc0392b,'PERROS · EL TRIPAS'],[18,0x2a6cff,'PUESTO DE VELASCO']].forEach(p=>{
    W(p[0],.5,-8,2.2,1,1,M(p[1]));
    const u=new THREE.Mesh(new THREE.ConeGeometry(1.6,.7,8),M(0xf2c230));
    u.position.set(X0+p[0],2.4,-8.6);
    S.add(u);
    W(p[0],1.2,-8.6,.06,2.4,.06,M(0x444444));
    const l=lbl(p[2],2.4);
    l.position.set(X0+p[0],3.1,-8);
    S.add(l);
    C2.push([X0+p[0]-1.2,X0+p[0]+1.2,-8.6,-7.4])
  });
 /* NPC del patio */
  npc(0x2c5aa0,'Soto',X0-4,14,0x111111);
  const sj2=npc(0x2a8c5a,'Sojo',X0+10,8,0x222222);
  let od2=null;
  safeBuild(()=>{od2=mkOdalys(X0-12,-17)});
  npc(0xe8e8e8,'El Tripas',X0-18,-9.4,0xffffff);
  npc(0x1a3a9a,'Velasco',X0+18,-9.4,0x111111);
  const tips=['Los cuadernos están repartidos por el patio. ¡Busca bien!','Si el sargento grita FIRMES, no te muevas ni un milímetro.','Con 6 cuadernos, corre al portón norte: la SALIDA.'];
  INT2.push({x:X0-4,z:14,lab:'Hablar con Soto',cool:6,cd:0,act(){
    dlg('Soto',tips[(Math.random()*3)|0])
  }},
  {x:X0+10,z:8,lab:'Sojo · revista',cd:0,act(){
    if(!addItem('rev'))return false;
    dlg('Sojo','Revista: velocidad 25 s (F para usar).');
    npcLeave(2,4.8)
  }},
  {x:X0-12,z:-17,lab:'Profe Odalys · credencial',cd:0,act(){
    if(!addItem('pas'))return false;
    dlg('Profe Odalys','¡Ay, mi cielo! Mi credencial te hace casi invisible 15 s. Úsala con F. 💕',5500);
    say('Ay mi cielo, toma mi credencial',1.6);
    npcLeave(3,5.8)
  }},
  {x:X0-18,z:-9.4,lab:'El Tripas · perros',cool:40,cd:0,act(){
    if(caps>0){
      caps--;
      htUI();
      fxText('❤ curado');
      dlg('El Tripas','¡Perro caliente! Te curó una captura.')
    }else{
      if(!addItem('per'))return false;
      dlg('El Tripas','Guárdalo y úsalo con F para curarte.')
    }
  }},
  {x:X0+18,z:-9.4,lab:'Velasco · +1 corazón',cool:60,cd:0,act(){
    if(caps>0)caps--;else hMax=Math.min(5,hMax+1);
    htUI();
    fxText('❤ +1 corazón');
    tone(660,.2,'triangle',.12,990);
    dlg('Velasco','¡Un corazón extra para el valiente!')
  }});
  MOV.push({g:sj2,o:INT2[1],lv:2,nm:'Sojo',sc:1},{g:od2,o:INT2[2],lv:2,nm:'La Profe Odalys',sc:.92});
 /* Cuadernos del patio */
 /* Refresco (Speed Run), zona de sueño (Aula) y barbería (nivel 1 y 3) */
  SODA=new THREE.Group();
  {
    const c=new THREE.Mesh(new THREE.CylinderGeometry(.1,.1,.32,12),new THREE.MeshStandardMaterial({color:0xd01818,emissive:0x601010,roughness:.3})),t=new THREE.Mesh(new THREE.CylinderGeometry(.095,.095,.03,12),new THREE.MeshStandardMaterial({color:0xcccccc,metalness:.9,roughness:.2}));
    t.position.y=.17;
    const l=lbl('REFRESCO',1.4);
    l.position.y=.6;
    SODA.add(c,t,l)
  }
  SODA.visible=false;
  S.add(SODA);
  SLM=new THREE.Group();
  {
    const d=new THREE.Mesh(new THREE.CircleGeometry(1.6,24),new THREE.MeshBasicMaterial({color:0x3a78ff,transparent:true,opacity:.35})),l=lbl('ZONA DE SUEÑO',2.2);
    d.rotation.x=-Math.PI/2;
    d.position.y=.03;
    l.position.y=1.2;
    SLM.add(d,l)
  }
  SLM.position.set(SLZ[0],0,SLZ[1]);
  SLM.visible=false;
  S.add(SLM);
  INT1.push({x:2.8,z:-24,lab:'✂ Cortarte el pelo',cool:20,cd:0,act(){
    return startHaircut()
  }});
  [[-20,18],[20,20],[0,6],[-22,-16],[22,-18],[-8,-12]].forEach(p=>{
    const m=new THREE.Mesh(new THREE.BoxGeometry(.34,.44,.05),[nfm,nfm,nfm,nfm,nbm,nbm]);
    m.position.set(X0+p[0],1.05,p[1]);
    m.visible=false;
    S.add(m);
    NB2.push(m)
  });
  CG2=mkGrid(C2);
 /* Sargento (modelo militar existente) */
  SARG.m=mkRos();
  SARG.m.scale.setScalar(SARG.s);
  SARG.m.position.set(SARG.x,0,SARG.z);
  if(!SARG.m.parent)S.add(SARG.m);
  SARG.m.visible=false
}
/* Inicio de nivel: escenario, luces, bienvenida / instrucciones */
function startLv(){
  const n=NIVELES[LV-1];
  npcShuffle(LV==2?2:1);
  PLS.forEach(l=>l.visible=LV!=2);
  R.shadowMap.needsUpdate=true;
  $('lvt').textContent='NIVEL '+LV;
  $('nbt').textContent=n.meta;
  renderBar();
  SARG.m.visible=LV==2;
  $('or').style.display='none';
  $('zz').style.display='none';
  $('app').classList.remove('sleepy');
  slp=false;
  if(LV>=3)return 0;
  if(LV==2){
    S.background.set(0x8fb4d8);
    S.fog.color.set(0x9db8cf);
    S.fog.density=.011;
    SUN.visible=HEM.visible=true;
    EX=.95;
    INT=INT2;
    BX0=X0-30;
    BX1=X0+30;
    BZ0=-24.6;
    BZ1=24.6;
    CGc=CG2;
    reset2();
    $('ht').style.display='flex';
    toast('🎖 TERRENO: obedece al Sargento. 3 capturas y quedas eliminado. Reúne 6 cuadernos y sal por el portón norte.',7000);
    dlg('Sargento','¡Soldados, atención! ¡Cumplan mis órdenes a pie firme!',4000);
    say('¡Atención soldados!',.3)
  }
 else{
    S.background.set(0x020403);
    S.fog.color.set(0x14233f);
    S.fog.density=.014;
    SUN.visible=HEM.visible=false;
    EX=.66;
    INT=INT1;
    BOTS.forEach(b=>b.m.visible=true);
    BX0=-29.6;
    BX1=29.6;
    BZ0=-29.6;
    BZ1=3.7;
    CGc=CG;
    $('ht').style.display='none';
    $('nbt').textContent=7;
    toast('📓 Reúne los 7 cuadernos de matemáticas. Ysea lo oye todo: no corras ni falles.',6500);
    dlg('Ysea','¡Hola, alumno! ¡Bienvenido a Basics en la UNEFA!',7000);
    say('¡Hola alumno! te voy a raspar la materia, ponte las pilas',.5)
  }
}
function reset2(){
  col2=0;
  caps=0;
  hMax=3;
  ord=null;
  og=5;
  sgT=0;
  tpl=0;
  spdT=invT=0;
  NB2.forEach(m=>m.visible=true);
  INT2.forEach(o=>o.cd=0);
  SARG.x=X0;
  SARG.z=-6;
  SARG.rt=null;
  SARG.m.position.set(SARG.x,0,SARG.z);
  P.x=X0;
  P.z=22;
  P.yaw=P.pt=0;
  $('nbn').textContent=0;
  lht='';
  htUI()
}
/* Órdenes militares: tipo, duración y condición de cumplimiento */
const ORD=[['¡FIRMES!','still',4],['¡ALTO!','still',2.5],['¡MEDIA VUELTA!','turn',4.5,d=>Math.abs(d)>2.7],['¡A LA DERECHA!','turn',4,d=>d<-1.1],['¡A LA IZQUIERDA!','turn',4,d=>d>1.1],['¡DESCANSO!','free',2.2]];
function startOrd(){
  const k=Math.random()<.12?5:(Math.random()*5)|0,o=ORD[k];
  ord={k:o[1],d:o[2],t:o[2],f:o[3],x0:P.x,z0:P.z,y0:P.yaw};
  const b=$('or');
  b.style.display='block';
  $('ot').textContent=o[0];
  b.classList.remove('pop');
  void b.offsetWidth;
  if(ANI)b.classList.add('pop');
  tone(1800,.15,'square',.08,1500);
  say(o[0].replace(/[¡!]/g,''),.3)
}
function ordEnd(ok){
  ord=null;
  $('ot').textContent=ok?'✔ ¡BIEN!':'✖ ¡INCUMPLIDO!';
  $('ot').style.color=ok?'#9dffb0':'#ff7a7a';
  setTimeout(()=>{
    if(!ord){
      $('or').style.display='none';
      $('ot').style.color=''
    }
  },700);
  og=Math.max(1.6,6-tpl*.025-col2*.35)+Math.random()*1.5
}
/* Captura: sacudida + flash rojo; el sargento te agarra. Con todas las capturas, eliminado */
function fail(){
  if(invT>0){
    toast('¡Casi te ven! (invisible)',1500);
    ordEnd(true);
    return false
  }
  caps++;
  htUI();
  ordEnd(false);
  shake();
  flashRed();
  sgT=1.2;
  tone(90,.5,'sawtooth',.25,50);
  say('¡Incumplimiento!',.3);
  if(caps>=hMax){
    die(SARG);
    return true
  }
  return false
}
function gt2(b,dt,tx,tz,sp){
  const dx=tx-b.x,
    dz=tz-b.z,
    d=Math.hypot(dx,dz)||1,
    s=Math.min(d,sp*dt);
  b.x+=dx/d*s;
  b.z+=dz/d*s;
  b.m.position.set(b.x,0,b.z);
  if(d>.05)b.m.rotation.y=Math.atan2(dx,dz)
}
/* Actualización del Nivel 2 (Terreno) */
function upd2(dt){
  NB=null;
  tpl+=dt;
  NB2.forEach((m,i)=>{
    if(m.visible){
      m.rotation.y=T*1.5;
      m.position.y=1.05+Math.sin(T*2+i)*.06;
      if(Math.hypot(m.position.x-P.x,m.position.z-P.z)<1.3){
        m.visible=false;
        col2++;
        $('nbn').textContent=col2;
        tone(784,.15,'triangle',.12);
        fxText('📓 +cuaderno');
        if(col2==6){
          toast('¡Todos los cuadernos! Ve a la SALIDA (portón norte).',4000);
          say('Salida al norte',.6)
        }
      }
    }
  });
  iaUI();
  if(col2>=6&&Math.hypot(P.x-X0,P.z+23.3)<3)return win2();
  const S2=SARG,
    dx=P.x-S2.x,
    dz=P.z-S2.z,
    sd=Math.hypot(dx,dz);
  if(sgT>0){
    sgT-=dt;
    if(sd>1.3)gt2(S2,dt,P.x,P.z,7);else S2.m.rotation.y=Math.atan2(dx,dz);
    if(sgT<=0){
      const a=Math.random()*6.28;
      S2.x=Math.max(X0-27,Math.min(X0+27,P.x+Math.cos(a)*9));
      S2.z=Math.max(-22,Math.min(22,P.z+Math.sin(a)*9));
      S2.m.position.set(S2.x,0,S2.z)
    }
  }
 else{
    if(!S2.rt||Math.hypot(S2.rt[0]-S2.x,S2.rt[1]-S2.z)<1)S2.rt=[X0+Math.random()*50-25,Math.random()*40-20];
    gt2(S2,dt,S2.rt[0],S2.rt[1],ord?0:1.6);
    if(ord)S2.m.rotation.y=Math.atan2(dx,dz)
  }
  const hd=S2.m.userData.head;
  if(hd)hd.rotation.x=(ANI?Math.sin(T*3)*.05:0)+(ord?.18:0);
  if(ord){
    ord.t-=dt;
    const pc=Math.max(0,Math.round(ord.t/ord.d*50));
    if(pc!==lob){
      lob=pc;
      $('ob').style.width=pc*2+'%'
    }
    const e=Math.hypot(P.x-ord.x0,P.z-ord.z0),dy=P.yaw-ord.y0;
    if(ord.k=='still'){
      if(ord.t<ord.d-.45&&e>.12){
        if(fail())return
      }else if(ord.t<=0)ordEnd(true)
    }
  else if(ord.k=='turn'){
      if(ord.f(dy))ordEnd(true);else if(ord.t<=0&&fail())return
    }
  else if(ord.t<=0)ordEnd(true)
  }
 else{
    og-=dt;
    if(og<=0&&tpl>3)startOrd()
  }
}
function win2(m){
  st='win';
  mOff();
  document.exitPointerLock&&document.exitPointerLock();
  $('hud').style.display='none';
  LV=LV>=NIVELES.length?1:LV+1;
  night++;
  SV.lv=LV;
  SV.night=night;
  SV.best=Math.max(SV.best,night);
  SV.wins++;
  svSave();
  ovMode(true);$('ovp').textContent=(m||'¡TERRENO superado! Saliste del patio sin ser eliminado.')+' '+(LV==1?'Vuelves a la ESCUELA, ahora más difícil.':'Siguiente: '+NIVELES[LV-1].nombre);
  $('go').textContent='Continuar';
  $('stat').innerHTML=statTxt();
  $('stat').style.display='flex';
  $('nw').style.display='none';
  $('ov').style.display='flex';
  [261,329,392,523].forEach((f,i)=>setTimeout(()=>tone(f,.5,'triangle',.15),i*220))
}
/* Inicio de los niveles 3 (Speed Run) y 4 (Aula): usan el edificio de la escuela sin profesores */
const SLZ=[0,-16.5],SLP={lab:'Dormir (E)',cool:1,cd:0,act(){
  slp=!slp;
  $('app').classList.toggle('sleepy',slp);
  tone(300,.2,'sine',.08,200)
}};
function startSchool(){
  S.background.set(0x020403);
  S.fog.color.set(0x14233f);
  S.fog.density=.014;
  SUN.visible=HEM.visible=false;
  EX=.66;
  INT=INT1;
  BX0=-29.6;
  BX1=29.6;
  BZ0=-29.6;
  BZ1=3.7;
  CGc=CG;
  $('ht').style.display='none';
  BOTS.forEach(b=>b.m.visible=false);
  ROS.m.visible=false;
  rosOn=false;
  $('nbt').textContent=1;
  $('nbn').textContent=0;
  SODA.visible=false;
  SLM.visible=LV==4;
  if(LV==3){
    const c=G.map((_,i)=>i).filter(i=>Math.hypot(G[i][0]-P.x,G[i][1]-P.z)>16),n=G[c[(Math.random()*c.length)|0]];
    SODA.position.set(n[0],.7,n[1]);
    SODA.visible=true;
    tL=100;
    lob2='';
    $('or').style.display='block';
    $('ot').style.color='';
    toast('⏱ SPEED RUN: encuentra el REFRESCO antes de que se acabe el tiempo.',6000);
    dlg('Ysea','¡Tengo sed! Tráeme mi refresco en 100 segundos. ¡Hoy no hay cuadernos!',5000);
    say('Tengo sed',.5)
  }
 else{
    INT=[];
    P.x=0;
    P.z=-11.5;
    P.yaw=0;
    zs=zp=0;
    ph=0;
    phT=6;
    lz1=lz2=-1;
    const Y=BOTS[0];
    Y.x=0;
    Y.z=-9.4;
    Y.m.visible=true;
    Y.m.position.set(0,0,-9.4);
    Y.m.rotation.y=0;
    $('zz').style.display='flex';
    toast('😴 AULA: ve a la ZONA DE SUEÑO y dueérmete (E). Si Ysea va a revisar, ¡despierta!',7000);
    dlg('Ysea','Clase tranquila... ¡y nadie se duerme en mi aula!',5000)
  }
}
function endOv(t,b){
  st='win';
  mOff();
  document.exitPointerLock&&document.exitPointerLock();
  $('hud').style.display='none';
  $('app').classList.remove('sleepy');
  slp=false;
  SV.deaths++;
  svSave();
  ovMode(true);$('ovp').textContent=t;
  $('go').textContent=b;
  $('stat').innerHTML=statTxt();
  $('stat').style.display='flex';
  $('nw').style.display='none';
  $('ov').style.display='flex';
  tone(110,.6,'sawtooth',.2,50)
}
/* Nivel 3: buscar el refresco contra reloj, con pista frío/caliente */
function upd3(dt){
  NB=null;
  tL-=dt;
  SODA.rotation.y=T*2;
  SODA.position.y=.7+Math.sin(T*3)*.08;
  iaUI();
  const d=Math.hypot(SODA.position.x-P.x,SODA.position.z-P.z);
  if(d<1.2){
    SODA.visible=false;
    fxText('🥤 ¡Refresco!');
    return win2('¡SPEED RUN superado! Encontraste el refresco con '+Math.ceil(tL)+' s de sobra.')
  }
  if(tL<=0)return endOv('¡Se acabó el tiempo! No encontraste el refresco.','Reintentar');
  const t='⏱ '+Math.max(0,Math.ceil(tL))+' s  '+(d<6?'🔥 ¡Muy caliente!':d<14?'♨ Tibio':'❄ Frío');
  if(t!==lob2){
    lob2=t;
    $('ot').textContent=t;
    $('ob').style.width=Math.max(0,tL)+'%'
  }
}
/* Nivel 4: dormirse sin que Ysea lo note (barra de sueño y de sospecha) */
function upd4(dt){
  NB=null;
  const Y=BOTS[0],inz=Math.hypot(P.x-SLZ[0],P.z-SLZ[1])<2.4;
  phT-=dt;
  if(phT<=0){
    ph=(ph+1)%3;
    phT=ph==0?5+Math.random()*4:ph==1?1.3:2.6;
    if(ph==1){
      tone(900,.15,'square',.1);
      toast('👁 ¡Ysea va a revisar! Despierta (E)',1500)
    }
  }
  Y.m.rotation.y+=((ph==2?Math.PI:0)-Y.m.rotation.y)*Math.min(1,dt*6);
  if(inz){
    SLP.lab=slp?'Despertar (E)':'Dormir (E)';
    IT=SLP
  }else if(slp){
    slp=false;
    $('app').classList.remove('sleepy')
  }
  iaUI();
  if(slp){
    zs=Math.min(100,zs+dt*(100/22));
    zp=ph==2?zp+dt*45:Math.max(0,zp-dt*8)
  }else zp=Math.max(0,zp-dt*18);
  const a=Math.round(zs),b=Math.round(zp);
  if(a!==lz1){
    lz1=a;
    $('zs').style.width=a+'%'
  }
  if(b!==lz2){
    lz2=b;
    $('zp').style.width=Math.min(100,b)+'%'
  }
  if(zs>=100)return win2('¡AULA superada! Te dormiste sin que Ysea lo notara.');
  if(zp>=100){
    shake();
    flashRed();
    return endOv('¡Ysea te descubrió durmiendo! Revisaba justo cuando dormías.','Reintentar')
  }
}
/* Ajustes (se guardan en localStorage): calidad, sonido, animaciones, límite de FPS */
const CK='basics-cfg-v1';
const AQL=[0,1,2,4];
let aq=matchMedia('(pointer:coarse)').matches?1:3,aqc=0,CFG={q:3,snd:1,ani:1,fps:0,sens:1,bri:1};
try{
  Object.assign(CFG,JSON.parse(localStorage.getItem(CK)||'{}'))
}catch(e){}
let cfgQ=-1;
/* applyCfg solo toca el renderizador cuando cambia la calidad real: sonido/animaciones no reasignan buffers */
function applyCfg(){
  SND=!!CFG.snd;
  ANI=!!CFG.ani;
  FPSL=CFG.fps|0;
  document.body.classList.toggle('noani',!ANI);
  if(!SND)mOff();
  const qq=CFG.q==3?AQL[aq]:CFG.q;
  if(qq===cfgQ)return;
  cfgQ=qq;
  const dpr=Math.max(1,devicePixelRatio||1),
    co=matchMedia('(pointer:coarse)').matches,
    pr=qq==0?.6:qq==1?1:qq==2?Math.min(dpr,2):Math.min(dpr*1.35,co?1.5:2.5);
  R.setPixelRatio(co?Math.min(pr,qq==4?1.5:1.25):pr);
  pr0=Math.max(.5,pr);
  if(composer){
    composer.setPixelRatio(pr0);
    composer.passes[1].enabled=qq>1
  }
  POST=!!composer&&qq>0;
  oL.castShadow=qq>1;
  R.shadowMap.needsUpdate=true;
  rs()
}
function saveCfg(){
  try{
    localStorage.setItem(CK,JSON.stringify(CFG))
  }catch(e){}
}
/* Panel de ajustes: HTML fijo en index.html; aquí solo se sincroniza y se enlazan eventos (una vez) */
function cfgSync(){
  $('cq').value=CFG.q;
  $('cs').checked=!!CFG.snd;
  $('ca').checked=!!CFG.ani;
  $('cff').value=CFG.fps;
  $('csn').value=CFG.sens;
  $('cbr').value=CFG.bri;
  $('cbv').textContent=Math.round(CFG.bri*100)+'%';
  $('csv').textContent=(+CFG.sens).toFixed(1)+'×'
}
function openCfg(){
  cfgSync();
  $('cfg').classList.add('on');
  setTimeout(()=>{
    try{
      $('cx3').focus({preventScroll:true})
    }catch(e){}
  },30)
}
function closeCfg(){
  $('cfg').classList.remove('on')
}
function cfgChange(){
  const was=CFG.snd;
  CFG.q=+$('cq').value;
  CFG.snd=$('cs').checked?1:0;
  CFG.ani=$('ca').checked?1:0;
  CFG.fps=+$('cff').value;
  CFG.sens=Math.max(.5,Math.min(2,+$('csn').value||1));
  $('csv').textContent=CFG.sens.toFixed(1)+'×';
  CFG.bri=Math.max(.7,Math.min(3,+$('cbr').value||1));
  $('cbv').textContent=Math.round(CFG.bri*100)+'%';
  saveCfg();
  applyCfg();
  if(CFG.snd&&!was&&st!='menu'){
    startMusic();
    mg=-1
  }
}
['cq','cs','ca','cff'].forEach(i=>$(i).addEventListener('change',cfgChange));
$('csn').addEventListener('input',cfgChange);
$('cbr').addEventListener('input',cfgChange);
$('cx2').onclick=$('cx3').onclick=closeCfg;
$('cfg').addEventListener('pointerdown',e=>{
  if(e.target===$('cfg'))closeCfg()
});
$('crs').onclick=()=>{
  Object.assign(CFG,{q:3,snd:1,ani:1,fps:0,sens:1,bri:1});
  saveCfg();
  applyCfg();
  cfgSync()
};
$('cfb').onclick=$('cfb2').onclick=openCfg;
/* ===== Profe Odalys: una abuelita profesora, dulce y tierna ===== */
const ODS=[];
function safeBuild(f){
  try{
    f()
  }catch(e){}
}
function mkOdalys(x,z){
  const g=new THREE.Group(),
    up=new THREE.Group(),
    hd=new THREE.Group(),
    arm=new THREE.Group(),
    la=new THREE.Group(),
    M=(c,r=.8,m=0)=>new THREE.MeshStandardMaterial({color:c,roughness:r,metalness:m}),
    skin=M(0xf1c9a8,.6),
    hairM=M(0xeeeef6,.85),
    cardi=M(0xd9739f,.9),
    blouse=M(0xfff4f4,.85),
    skirt=M(0x7b5aa8,.92),
    shawl=M(0xf9dce8,.95),
    shoe=M(0x3b2630,.5),
    gl=M(0x6b4f76,.35,.6),
    dk=M(0x2b1f2e,.5),
    pink=new THREE.MeshBasicMaterial({color:0xf3808f,transparent:true,opacity:.5,depthWrite:false}),
    lens=new THREE.MeshBasicMaterial({color:0xbfe0ff,transparent:true,opacity:.18,depthWrite:false}),
    ad=(p,geo,m,px,py,pz,r,s)=>{
    const o=new THREE.Mesh(geo,m);
    o.position.set(px,py,pz);
    if(r)o.rotation.set(r[0],r[1],r[2]);
    if(s)o.scale.set(s[0],s[1],s[2]);
    p.add(o);
    return o
  };
  ad(g,new THREE.CylinderGeometry(.19,.33,.78,18),skirt,0,.39,0);
  ad(g,new THREE.TorusGeometry(.325,.02,6,20),M(0x5d4087,.9),0,.05,0,[Math.PI/2,0,0]);
  [-1,1].forEach(s=>ad(g,new THREE.BoxGeometry(.1,.06,.17),shoe,s*.1,.03,.2));
  up.position.y=.74;
  up.rotation.x=.08;
  g.add(up);
  ad(up,new THREE.CylinderGeometry(.2,.23,.5,18),cardi,0,.25,0);
  ad(up,new THREE.BoxGeometry(.15,.42,.02),blouse,0,.27,.205);
  [.1,.22,.34].forEach(y=>ad(up,new THREE.SphereGeometry(.014,8,6),M(0xfff0c8,.4,.3),0,y,.222));
  ad(up,new THREE.TorusGeometry(.2,.055,8,22),shawl,0,.5,0,[Math.PI/2,0,0],[1.05,1,.9]);
  ad(up,new THREE.SphereGeometry(.03,10,8),M(0xff7aa2,.5),-.1,.4,.215);
  ad(up,new THREE.SphereGeometry(.014,8,6),M(0xffe27a,.5),-.1,.4,.238);
  [-1,1].forEach(s=>ad(up,new THREE.SphereGeometry(.07,10,8),cardi,s*.2,.46,0));
 /* brazo izquierdo con un libro; brazo derecho saluda */
  la.position.set(-.2,.46,0);
  la.rotation.x=-1.0;
  up.add(la);
  ad(la,new THREE.CylinderGeometry(.05,.043,.34,10),cardi,0,-.17,0);
  ad(la,new THREE.SphereGeometry(.045,10,8),skin,0,-.36,0);
  arm.position.set(.2,.46,0);
  arm.rotation.z=.12;
  up.add(arm);
  ad(arm,new THREE.CylinderGeometry(.05,.043,.34,10),cardi,0,-.17,0);
  ad(arm,new THREE.SphereGeometry(.045,10,8),skin,0,-.36,0);
  ad(up,new THREE.BoxGeometry(.2,.04,.15),M(0x244a8a,.6),-.1,.3,.31,[.1,.2,0]);
  ad(up,new THREE.BoxGeometry(.185,.034,.14),M(0xfff6dc,.8),-.1,.3,.318,[.1,.2,0]);
 /* cabeza */
  hd.position.set(0,.72,.02);
  up.add(hd);
  ad(hd,new THREE.SphereGeometry(.17,24,18),skin,0,0,0,null,[1,1.08,1]);
  [-1,1].forEach(s=>ad(hd,new THREE.SphereGeometry(.035,8,6),skin,s*.17,-.01,0));
  ad(hd,new THREE.SphereGeometry(.18,24,14,Math.PI/2+.95,Math.PI*2-1.9,0,Math.PI*.55),hairM,0,.015,-.012,null,[1,1.08,1.04]);
  ad(hd,new THREE.SphereGeometry(.18,16,8,Math.PI/2-.95,1.9,0,Math.PI*.3),hairM,0,.015,-.005,null,[1,1.08,1.04]);
  ad(hd,new THREE.SphereGeometry(.085,14,10),hairM,0,.2,-.09);
  ad(hd,new THREE.TorusGeometry(.07,.012,6,14),M(0xff7aa2,.5),0,.15,-.09,[Math.PI/2.4,0,0]);
  [-1,1].forEach(s=>{
    ad(hd,new THREE.SphereGeometry(.05,10,8),hairM,s*.16,-.04,-.03);
    ad(hd,new THREE.SphereGeometry(.042,10,8),hairM,s*.15,-.1,-.01)
  });
  [-1,1].forEach(s=>{
    ad(hd,new THREE.SphereGeometry(.016,8,6),dk,s*.06,.03,.16,null,[1,1.3,.6]);
    ad(hd,new THREE.BoxGeometry(.045,.008,.01),hairM,s*.06,.078,.15,[0,0,-s*.18]);
    ad(hd,new THREE.TorusGeometry(.042,.006,6,18),gl,s*.06,.03,.167);
    ad(hd,new THREE.CircleGeometry(.04,16),lens,s*.06,.03,.168);
    ad(hd,new THREE.BoxGeometry(.006,.006,.16),gl,s*.105,.03,.085);
    ad(hd,new THREE.SphereGeometry(.04,10,8),pink,s*.095,-.035,.135,null,[1,.7,.35])
  });
  ad(hd,new THREE.BoxGeometry(.03,.006,.006),gl,0,.035,.17);
  ad(hd,new THREE.SphereGeometry(.025,8,6),M(0xe9b393,.6),0,-.01,.17,null,[.9,1.2,1]);
  ad(hd,new THREE.TorusGeometry(.04,.0055,6,12,Math.PI),M(0xb5524f,.6),0,-.035,.158,[0,0,Math.PI]);
 /* corazoncito flotante cuando te acercas */
  const hc=document.createElement('canvas');
  hc.width=hc.height=64;
  {
    const c=hc.getContext('2d');
    c.fillStyle='#ff5a8a';
    c.beginPath();
    c.moveTo(32,56);
    c.bezierCurveTo(4,36,6,10,24,10);
    c.bezierCurveTo(30,10,32,16,32,18);
    c.bezierCurveTo(32,16,34,10,40,10);
    c.bezierCurveTo(58,10,60,36,32,56);
    c.fill();
    c.fillStyle='rgba(255,255,255,.5)';
    c.beginPath();
    c.ellipse(21,20,5,3,-.6,0,7);
    c.fill()
  }
  const heart=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(hc),transparent:true,fog:false}));
  heart.scale.set(.3,.3,1);
  heart.position.y=2.05;
  heart.visible=false;
  g.add(heart);

  
  const l=lbl('Profe Odalys',2);
  l.position.y=1.85;
  g.add(l);

/* ===== HALO SUAVE EN LA SILUETA DE ODALYS ===== */

const odHaloMaterial = mkOdalys._haloMaterial ||
  (mkOdalys._haloMaterial = new THREE.ShaderMaterial({

    uniforms: {
      color0: { value: new THREE.Vector4(1, 77/255, 166/255, 0.85) },
      color1: { value: new THREE.Vector4(1, 182/255, 217/255, 0.70) },
      color2: { value: new THREE.Vector4(1, 148/255, 130/255, 0.65) },
      color3: { value: new THREE.Vector4(218/255, 112/255, 214/255, 0.50) },

      uThickness: { value: 0.012 },
      uIntensity: { value: 0.30 }
    },

    vertexShader: `
      varying vec3 vNormalView;
      varying vec3 vViewDirection;
      varying float vHeight;

      uniform float uThickness;

      void main() {

        // Extensión mínima de la silueta
        vec3 expandedPosition =
          position + normal * uThickness;

        vec4 viewPosition =
          modelViewMatrix * vec4(expandedPosition, 1.0);

        vNormalView =
          normalize(normalMatrix * normal);

        vViewDirection =
          normalize(-viewPosition.xyz);

        vec4 worldPosition =
          modelMatrix * vec4(expandedPosition, 1.0);

        vHeight = worldPosition.y;

        gl_Position =
          projectionMatrix * viewPosition;
      }
    `,

    fragmentShader: `
      uniform vec4 color0;
      uniform vec4 color1;
      uniform vec4 color2;
      uniform vec4 color3;

      uniform float uIntensity;

      varying vec3 vNormalView;
      varying vec3 vViewDirection;
      varying float vHeight;

      void main() {

        // Transición vertical de colores
        float h = clamp(vHeight / 2.15, 0.0, 1.0);

        vec4 color;

        if (h < 0.4) {
          color = mix(color0, color1, h / 0.4);
        }
        else if (h < 0.72) {
          color = mix(
            color1,
            color2,
            (h - 0.4) / 0.32
          );
        }
        else {
          color = mix(
            color2,
            color3,
            (h - 0.72) / 0.28
          );
        }

        // Halo concentrado en los bordes
        float facing = abs(dot(
          normalize(vNormalView),
          normalize(vViewDirection)
        ));

        float edge = 1.0 - clamp(facing, 0.0, 1.0);

        // Suaviza la transición del resplandor
        float softEdge = smoothstep(
          0.08,
          0.85,
          edge
        );

        float alpha =
          pow(softEdge, 1.4) *
          color.a *
          uIntensity;

        gl_FragColor = vec4(color.rgb, alpha);
      }
    `,

    transparent: true,
    depthTest: true,
    depthWrite: false,
    side: THREE.BackSide,
    blending: THREE.AdditiveBlending,
    toneMapped: false
  }));

// Aplicar el contorno a las mallas originales
const odHaloParts = [];

g.traverse(obj => {
  if (!obj.isMesh || !obj.geometry || !obj.parent) return;

  if (!obj.geometry.boundingSphere) {
    obj.geometry.computeBoundingSphere();
  }

  if (obj.geometry.boundingSphere.radius < 0.065) return;

  odHaloParts.push(obj);
});

for (const part of odHaloParts) {

  const halo = new THREE.Mesh(
    part.geometry,
    odHaloMaterial
  );

  // Mantener la transformación original
  halo.position.copy(part.position);
  halo.quaternion.copy(part.quaternion);
  halo.scale.copy(part.scale);

  // Evitar que el aura sea demasiado voluminosa
  halo.renderOrder = 10;
  halo.frustumCulled = false;

  part.parent.add(halo);
}

/* ===== FIN DEL HALO ===== */


  g.scale.setScalar(.92);
  g.position.set(x,0,z);
  g.userData={up,hd,arm,heart};


  // Luz ambiental dinámica de la Profe Odalys
  LVIR.push({
    x: g.position.x,
    y: 4,
    z: g.position.z,

    c: 0xff82bd,  // Rosa suave
    i: 0.90,      // Intensidad
    d: 6.4,       // Alcance
    dc: 1,

    fl: 0,
    fi: 0,
    on: 1,

    // Referencia al personaje para seguir sus movimientos
    follow: g,
    baseI: 1
  });

  S.add(g);
  ODS.push(g);
  return g
}
function odTick(dt){
  for(const o of ODS){
    const dx=P.x-o.position.x,dz=P.z-o.position.z,d=Math.hypot(dx,dz);
    if(d>14)continue;
    const u=o.userData,near=d<7;
    let da=((Math.atan2(dx,dz)-o.rotation.y+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;
    o.rotation.y+=da*Math.min(1,dt*3);
    if(ANI){
      u.up.rotation.z=Math.sin(T*1.3)*.025;
      u.hd.rotation.z=Math.sin(T*1.1)*.05;
      u.hd.rotation.x=Math.sin(T*.9)*.03+(near?.05:0)
    }
    const aw=near?2.45+(ANI?Math.sin(T*7)*.28:0):.12;
    u.arm.rotation.z+=(aw-u.arm.rotation.z)*Math.min(1,dt*6);
    u.heart.visible=near&&ANI;
    if(u.heart.visible)u.heart.position.y=2.05+Math.sin(T*3)*.06
  }
}
const DRS=[D.L,D.R];
function mergeStatic(){
  try{
    const keep=new Set([D.L.m,D.R.m,...NBS,...SNS]),gr=new Map(),rm=[];
    S.children.slice().forEach(o=>{
      if(!o.isMesh||!o.userData.bx||o.children.length||keep.has(o))return;
      const k=o.material.uuid+'|'+(o.castShadow?1:0)+'|'+Math.floor(o.position.x/10)+'|'+Math.floor(o.position.z/10);
      let g=gr.get(k);
      if(!g)gr.set(k,g={m:o.material,c:o.castShadow,l:[]});
      g.l.push(o)
    });
    gr.forEach(g=>{
      let nv=0,ni=0;
      g.l.forEach(o=>{
        nv+=o.geometry.attributes.position.count;
        ni+=o.geometry.index.count
      });
      const P=new Float32Array(nv*3),
        N=new Float32Array(nv*3),
        U=new Float32Array(nv*2),
        I=new Uint16Array(ni);
      let vo=0,io=0;
      g.l.forEach(o=>{
        o.updateMatrix();
        const ge=o.geometry.clone();
        ge.applyMatrix4(o.matrix);
        const a=ge.attributes;
        P.set(a.position.array,vo*3);
        N.set(a.normal.array,vo*3);
        U.set(a.uv.array,vo*2);
        const ix=ge.index.array;
        for(let i=0;i<ix.length;i++)I[io+i]=ix[i]+vo;
        vo+=a.position.count;
        io+=ix.length;
        ge.dispose();
        rm.push(o)
      });
      const bg=new THREE.BufferGeometry();
      bg.setAttribute('position',new THREE.BufferAttribute(P,3));
      bg.setAttribute('normal',new THREE.BufferAttribute(N,3));
      bg.setAttribute('uv',new THREE.BufferAttribute(U,2));
      bg.setIndex(new THREE.BufferAttribute(I,1));
      bg.computeBoundingSphere();
      bg.computeBoundingBox();
      const m=new THREE.Mesh(bg,g.m);
      m.castShadow=g.c;
      m.receiveShadow=true;
      m.matrixAutoUpdate=false;
      S.add(m)
    });
    rm.forEach(o=>{
      S.remove(o);
      o.geometry.dispose()
    });
    S.traverse(o=>{
      if(o.isMesh&&!keep.has(o)){
        o.updateMatrix();
        o.matrixAutoUpdate=false
      }
    });
  }catch(e){
    console.warn('merge',e)
  }
}
/* ---------- Pool de luces ----------
 * Antes había ~20 luces puntuales evaluadas en CADA píxel (el mayor coste de GPU).
 * Ahora las luces decorativas son "virtuales" y solo las LP_N más influyentes
 * cerca del jugador se iluminan de verdad. El número de luces reales es constante
 * (no hay recompilación de shaders) y el cambio entre luces se desvanece suavemente. */
const LVIR=[],LPOOL=[],LP_N=matchMedia('(pointer:coarse)').matches?5:6;
let lpF=0;
(function(){
  const sp=new Set([oL,dk,hL,hR,hl,dlL,cl,dL]),dec=[];
  S.children.forEach(o=>{if(o.isPointLight&&!sp.has(o))dec.push(o)});
  dec.forEach(l=>{
    const fi=RL.indexOf(l),fl=fi>=0;
    LVIR.push({x:l.position.x,y:l.position.y,z:l.position.z,c:l.color.getHex(),i:fl?l.userData.b:l.intensity,d:l.distance,dc:l.decay,fl:fl?1:0,fi:fl?fi:0,on:0});
    S.remove(l)
  });
  RL.length=0;
  for(let k=0;k<LP_N;k++){
    const l=new THREE.PointLight(0xffffff,0,10,1.4);
    l.userData={v:-1,b:0,fl:0,fi:0,f:0};
    S.add(l);
    LPOOL.push(l);
    RL.push(l)
  }
})();
function lightPool(dt){
  const rx=cam.position.x-Math.sin(cam.rotation.y)*3,rz=cam.position.z-Math.cos(cam.rotation.y)*3;

  // Actualizar las luces que siguen a NPC itinerantes
  for(const v of LVIR){
    if(!v.follow) continue;

    const o = v.follow;

    v.x = o.position.x;
    v.y = o.position.y + 0.95;
    v.z = o.position.z;

    // Atenuar la luz mientras el NPC desaparece
    const fade = Math.max(
      0,
      Math.min(1, o.scale.x / 0.92)
    );

    v.i = v.baseI * fade * (o.visible ? 1 : 0);
    v.on = v.i > 0 ? 1 : 0;
  }

  if(lpF--<=0){
    lpF=5;
    const ws=LVIR.map((v,i)=>{
      const d=Math.hypot(v.x-rx,v.y-1.5,v.z-rz),a=Math.max(0,1-Math.pow(d/v.d,4));
      return [v.i*a*a/Math.pow(Math.max(.6,d),v.dc)*(v.on?1.35:1),i]
    }).sort((a,b)=>b[0]-a[0]),
      top=ws.slice(0,LPOOL.length).map(a=>a[1]),free=[];
    LPOOL.forEach(l=>{
      const u=l.userData,k=top.indexOf(u.v);
      if(u.v>=0&&k>=0)top.splice(k,1);else free.push(l)
    });
    free.forEach((l,k)=>{
      const u=l.userData,i=top[k];
      if(i==null){u.v=-1;u.b=0;return}
      const v=LVIR[i];
      l.position.set(v.x,v.y,v.z);
      l.color.setHex(v.c);
      l.distance=v.d;
      l.decay=v.dc;
      u.v=i;u.b=v.i;u.fl=v.fl;u.fi=v.fi;u.f=0
    });
    LVIR.forEach(v=>v.on=0);
    LPOOL.forEach(l=>{if(l.userData.v>=0)LVIR[l.userData.v].on=1})
  }
  
for(const l of LPOOL){
  const u=l.userData;

  // Si la luz pertenece a un NPC, seguir su posición
  if(u.v>=0){
    const v=LVIR[u.v];

    if(v && v.follow){
      l.position.set(v.x,v.y,v.z);
      u.b=v.i;
    }
  }

  if(u.f<1)u.f=Math.min(1,u.f+dt*4);

    l.intensity=u.v<0?0:u.f*u.b*(u.fl?(camUp?.5:.7)*(Math.sin(T*(31+u.fi*7)+u.fi)>.992?.35:1):1)
  }
}
const PLS=[];
S.traverse(o=>{
  if(o.isPointLight&&o!==cl&&o!==dL)PLS.push(o)
});
mergeStatic();
buildExtra();
applyCfg();
LV=Math.max(1,Math.min(NIVELES.length,SV.lv|0||1));
menuInfo();
R.shadowMap.autoUpdate=false;
R.shadowMap.needsUpdate=true;
reset();
$('hud').style.display='none';
requestAnimationFrame(loop);

